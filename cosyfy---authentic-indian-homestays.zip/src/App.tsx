import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { LanguageProvider } from './context/LanguageContext';
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { FloatingWhatsApp } from './components/common/FloatingWhatsApp';
import { MobileBottomNav } from './components/common/MobileBottomNav';

// Public Pages
import { Home } from './pages/Home';
import { Properties } from './pages/Properties';
import { PropertyDetail } from './pages/PropertyDetail';
import { BookingRequest } from './pages/BookingRequest';
import { WorkFromMountains } from './pages/WorkFromMountains';
import { About } from './pages/About';
import { Contact } from './pages/Contact';
import { Login } from './pages/Login';
import { SignUp } from './pages/SignUp';
import { ForgotPassword } from './pages/ForgotPassword';
import { Profile } from './pages/Profile';
import { MyBookings } from './pages/MyBookings';
import { SavedStays } from './pages/SavedStays';
import { ListYourProperty } from './pages/ListYourProperty';

// Multi-Tier Admin Panels
import { SuperAdmin } from './pages/SuperAdmin';
import { AdminPortal } from './pages/AdminPortal';
import { EmployeePortal } from './pages/EmployeePortal';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import { UserRole } from './services/auth';
import { initGA } from './services/analytics';

// Scroll to top helper on route change
function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function AppShell() {
  const { pathname } = useLocation();
  const isInternalPortal =
    pathname.startsWith('/superadmin') ||
    pathname.startsWith('/admin') ||
    pathname.startsWith('/employee');

  return (
    <>
      <ScrollToTop />
      {isInternalPortal ? (
        // Dedicated internal admin panels have their own specialized sidebar and topbars
        <div className="min-h-screen bg-[#F8F6F0]">
          <Routes>
            <Route
              path="/superadmin"
              element={
                <ProtectedRoute allowedRoles={[UserRole.SUPER_ADMIN]}>
                  <SuperAdmin />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin"
              element={
                <ProtectedRoute allowedRoles={[UserRole.ADMIN, UserRole.SUPER_ADMIN]}>
                  <AdminPortal />
                </ProtectedRoute>
              }
            />
            <Route
              path="/employee"
              element={
                <ProtectedRoute
                  allowedRoles={[UserRole.EMPLOYEE, UserRole.ADMIN, UserRole.SUPER_ADMIN]}
                >
                  <EmployeePortal />
                </ProtectedRoute>
              }
            />
            <Route path="*" element={<Home />} />
          </Routes>
        </div>
      ) : (
        // Public Consumer Facing Site
        <div className="min-h-screen flex flex-col bg-[#FAF7F2] text-[#1A1A1A]">
          <Navbar />

          <main className="flex-1 pb-16 md:pb-0">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/properties" element={<Properties />} />
              <Route path="/property/:id" element={<PropertyDetail />} />
              <Route path="/booking-request/:propertyId" element={<BookingRequest />} />
              <Route path="/work-from-mountains" element={<WorkFromMountains />} />
              <Route path="/about" element={<About />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<SignUp />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/my-bookings" element={<MyBookings />} />
              <Route path="/saved" element={<SavedStays />} />
              <Route path="/list-your-property" element={<ListYourProperty />} />
              <Route path="*" element={<Home />} />
            </Routes>
          </main>

          <Footer />
          <FloatingWhatsApp />
          <MobileBottomNav />
        </div>
      )}
    </>
  );
}

export default function App() {
  useEffect(() => {
    initGA();
  }, []);

  return (
    <LanguageProvider>
      <AuthProvider>
        <Router>
          <AppShell />
        </Router>
      </AuthProvider>
    </LanguageProvider>
  );
}
