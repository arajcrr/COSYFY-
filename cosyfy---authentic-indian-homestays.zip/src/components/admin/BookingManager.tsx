import React, { useState } from 'react';
import { Booking, BookingStatus } from '../../types';
import { formatPrice, getWhatsAppUrl } from '../../utils';
import { MessageCircle, Check, X, Clock, ExternalLink } from 'lucide-react';

interface BookingManagerProps {
  bookings: Booking[];
  onUpdateStatus: (bookingId: string, ref: string, newStatus: BookingStatus) => Promise<void>;
}

export const BookingManager: React.FC<BookingManagerProps> = ({
  bookings,
  onUpdateStatus,
}) => {
  const [filter, setFilter] = useState<'all' | BookingStatus>('all');
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const filteredBookings = bookings.filter((b) => (filter === 'all' ? true : b.status === filter));

  const handleStatusChange = async (b: Booking, status: BookingStatus) => {
    setUpdatingId(b.id || b.bookingReference);
    await onUpdateStatus(b.id, b.bookingReference, status);
    setUpdatingId(null);
  };

  const getStatusBadge = (status: BookingStatus) => {
    switch (status) {
      case 'confirmed':
        return <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-[#2D5016]">Confirmed</span>;
      case 'declined':
        return <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-100 text-rose-700">Declined</span>;
      case 'contacting_host':
        return <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800">Calling Host</span>;
      default:
        return <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-stone-100 text-stone-700">Pending</span>;
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-sm space-y-4 p-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-lg font-bold text-stone-900 font-display">
            Booking Reservations ({filteredBookings.length})
          </h3>
          <p className="text-xs text-stone-500">
            Real-time synchronization with Airtable & Make.com workflows
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap gap-1.5 text-xs">
          {(['all', 'pending', 'contacting_host', 'confirmed', 'declined'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-3 py-1 rounded-lg font-semibold capitalize transition-colors ${
                filter === tab
                  ? 'bg-[#2D5016] text-white'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              {tab.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-stone-700">
          <thead className="bg-stone-50 uppercase text-[10px] text-stone-500 font-bold tracking-wider border-y border-stone-200">
            <tr>
              <th className="py-3 px-4">Ref #</th>
              <th className="py-3 px-4">Guest Details</th>
              <th className="py-3 px-4">Property & Dates</th>
              <th className="py-3 px-4">Stay Total</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {filteredBookings.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-stone-400 italic">
                  No bookings found in this category.
                </td>
              </tr>
            ) : (
              filteredBookings.map((b) => {
                const customerMsg = `Namaste ${b.guestName}! Regarding your Cosyfy booking request (${b.bookingReference}) for ${b.propertyName}:`;
                const whatsappLink = getWhatsAppUrl(b.guestPhone, customerMsg);

                return (
                  <tr key={b.id || b.bookingReference} className="hover:bg-stone-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-[#C84B31]">
                      {b.bookingReference}
                    </td>

                    <td className="py-3.5 px-4">
                      <strong className="block text-stone-900">{b.guestName}</strong>
                      <span className="text-stone-500">{b.guestPhone}</span>
                      <span className="text-stone-400 block text-[11px]">{b.guestEmail}</span>
                    </td>

                    <td className="py-3.5 px-4">
                      <strong className="block text-stone-900">{b.propertyName}</strong>
                      <span className="text-stone-500">
                        {b.checkIn} to {b.checkOut} ({b.nights}n)
                      </span>
                      <span className="text-stone-400 block text-[11px]">
                        {b.adults} Adults {b.children > 0 ? `, ${b.children} Ch` : ''}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <strong className="block text-stone-900">{formatPrice(b.totalPrice)}</strong>
                      <span className="text-[11px] text-[#2D5016]">
                        Dep: {formatPrice(b.advanceDeposit)}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      {getStatusBadge(b.status)}
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-2">
                      <a
                        href={whatsappLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#25D366] text-white text-[11px] font-semibold hover:bg-[#20ba59]"
                        title="Chat with guest on WhatsApp"
                      >
                        <MessageCircle className="w-3.5 h-3.5 fill-white" />
                        <span className="hidden sm:inline">WhatsApp</span>
                      </a>

                      {b.status !== 'confirmed' && (
                        <button
                          disabled={updatingId === (b.id || b.bookingReference)}
                          onClick={() => handleStatusChange(b, 'confirmed')}
                          className="px-2.5 py-1 rounded-lg bg-[#2D5016] text-white text-[11px] font-semibold hover:bg-[#1F380F] disabled:opacity-50"
                        >
                          Approve
                        </button>
                      )}

                      {b.status !== 'declined' && (
                        <button
                          disabled={updatingId === (b.id || b.bookingReference)}
                          onClick={() => handleStatusChange(b, 'declined')}
                          className="px-2.5 py-1 rounded-lg bg-stone-200 text-stone-700 text-[11px] font-semibold hover:bg-rose-100 hover:text-rose-700 disabled:opacity-50"
                        >
                          Decline
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
