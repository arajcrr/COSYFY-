import React, { useState } from 'react';
import { Save, CheckCircle2, MessageCircle } from 'lucide-react';

export const ContentManager: React.FC = () => {
  const [heroHeading, setHeroHeading] = useState('Stay with local families, savor homecooked meals.');
  const [heroSubheading, setHeroSubheading] = useState('Personally verified homestays across India. Zero service fees. Always.');
  const [whatsappNumber, setWhatsappNumber] = useState(import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210');
  const [bannerText, setBannerText] = useState('100% Personally Verified Indian Homestays • Zero Hidden Service Fees');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('cosyfy_content_heroHeading', heroHeading);
    localStorage.setItem('cosyfy_content_heroSubheading', heroSubheading);
    localStorage.setItem('cosyfy_content_whatsapp', whatsappNumber);
    localStorage.setItem('cosyfy_content_banner', bannerText);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm space-y-6">
      <div>
        <h3 className="text-lg font-bold text-stone-900 font-display">
          Website Content & Brand Settings
        </h3>
        <p className="text-xs text-stone-500">
          Update copy, support hotline, and marketing headlines
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-4 text-xs">
        <div>
          <label className="block font-bold text-stone-700 mb-1">
            Homepage Announcement Micro-Banner
          </label>
          <input
            type="text"
            value={bannerText}
            onChange={(e) => setBannerText(e.target.value)}
            className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:border-[#2D5016]"
          />
        </div>

        <div>
          <label className="block font-bold text-stone-700 mb-1">
            Hero Primary Heading
          </label>
          <input
            type="text"
            value={heroHeading}
            onChange={(e) => setHeroHeading(e.target.value)}
            className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:border-[#2D5016]"
          />
        </div>

        <div>
          <label className="block font-bold text-stone-700 mb-1">
            Hero Subheading & Tagline
          </label>
          <textarea
            rows={2}
            value={heroSubheading}
            onChange={(e) => setHeroSubheading(e.target.value)}
            className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:border-[#2D5016]"
          />
        </div>

        <div>
          <label className="block font-bold text-stone-700 mb-1">
            Support WhatsApp Number (without + or dashes)
          </label>
          <div className="flex items-center gap-2">
            <MessageCircle className="w-4 h-4 text-[#25D366]" />
            <input
              type="text"
              value={whatsappNumber}
              onChange={(e) => setWhatsappNumber(e.target.value)}
              placeholder="919876543210"
              className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:border-[#2D5016]"
            />
          </div>
        </div>

        <div className="pt-2 flex items-center justify-between">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-[#2D5016] text-white font-bold hover:bg-[#1F380F] flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>Save Settings</span>
          </button>

          {savedSuccess && (
            <span className="flex items-center gap-1.5 text-xs text-[#2D5016] font-bold">
              <CheckCircle2 className="w-4 h-4" />
              <span>Settings updated successfully!</span>
            </span>
          )}
        </div>
      </form>
    </div>
  );
};
