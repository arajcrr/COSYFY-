import React from 'react';
import { Booking, Property } from '../../types';
import { formatPrice } from '../../utils';
import { Calendar, DollarSign, Home, Clock, AlertTriangle, ArrowUpRight } from 'lucide-react';

interface DashboardProps {
  bookings: Booking[];
  properties: Property[];
  onSelectTab: (tab: 'bookings' | 'properties' | 'content') => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  bookings,
  properties,
  onSelectTab,
}) => {
  const pendingCount = bookings.filter((b) => b.status === 'pending' || b.status === 'contacting_host').length;
  const activePropsCount = properties.filter((p) => p.isActive !== false).length;
  const totalRevenue = bookings
    .filter((b) => b.status === 'confirmed')
    .reduce((acc, curr) => acc + curr.totalPrice, 0);

  const stats = [
    {
      label: "Pending Requests",
      value: pendingCount,
      sub: 'Need host verification',
      icon: Clock,
      color: 'bg-amber-100 text-amber-800',
      action: () => onSelectTab('bookings'),
    },
    {
      label: 'Confirmed GMV',
      value: formatPrice(totalRevenue),
      sub: 'This month’s stay volume',
      icon: DollarSign,
      color: 'bg-emerald-100 text-[#2D5016]',
      action: () => onSelectTab('bookings'),
    },
    {
      label: 'Active Homestays',
      value: activePropsCount,
      sub: 'Verified Indian properties',
      icon: Home,
      color: 'bg-blue-100 text-blue-800',
      action: () => onSelectTab('properties'),
    },
    {
      label: 'Total Bookings Logged',
      value: bookings.length,
      sub: 'All time inquiries & requests',
      icon: Calendar,
      color: 'bg-orange-100 text-[#C84B31]',
      action: () => onSelectTab('bookings'),
    },
  ];

  return (
    <div className="space-y-8">
      {/* 4 Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div
              key={s.label}
              onClick={s.action}
              className="bg-white rounded-2xl p-6 border border-stone-200/90 shadow-sm hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
                  {s.label}
                </span>
                <div className={`p-2.5 rounded-xl ${s.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
              </div>
              <div>
                <p className="text-2xl font-extrabold text-stone-900 font-display">
                  {s.value}
                </p>
                <p className="text-xs text-stone-500 mt-1 flex items-center justify-between">
                  <span>{s.sub}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-[#2D5016]" />
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Pending Confirmations Needing Attention */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            <h3 className="text-base font-bold text-stone-900 font-display">
              Action Required: Pending Host Confirmations ({pendingCount})
            </h3>
          </div>
          <button
            onClick={() => onSelectTab('bookings')}
            className="text-xs font-semibold text-[#2D5016] hover:underline"
          >
            View all bookings →
          </button>
        </div>

        {pendingCount === 0 ? (
          <p className="text-xs text-stone-500 py-3 italic">
            All booking requests have been answered! Zero pending requests.
          </p>
        ) : (
          <div className="divide-y divide-stone-100">
            {bookings
              .filter((b) => b.status === 'pending' || b.status === 'contacting_host')
              .slice(0, 5)
              .map((b) => (
                <div key={b.id || b.bookingReference} className="py-3 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-mono font-bold text-[#C84B31]">{b.bookingReference}</span>
                    <span className="mx-2 text-stone-300">•</span>
                    <strong className="text-stone-800">{b.propertyName}</strong>
                    <span className="mx-2 text-stone-300">•</span>
                    <span className="text-stone-600">Guest: {b.guestName} ({b.guestPhone})</span>
                  </div>
                  <button
                    onClick={() => onSelectTab('bookings')}
                    className="px-3 py-1 rounded-lg bg-[#2D5016] text-white font-semibold text-[11px]"
                  >
                    Respond
                  </button>
                </div>
              ))}
          </div>
        )}
      </div>
    </div>
  );
};
