import React, { useState } from 'react';
import { Property } from '../../types';
import { formatPrice } from '../../utils';
import { Plus, Check, X, ExternalLink, ShieldCheck, Wifi } from 'lucide-react';

interface PropertyManagerProps {
  properties: Property[];
  onToggleActive?: (id: string, currentState: boolean) => void;
  onAddProperty?: (newProp: Partial<Property>) => void;
}

export const PropertyManager: React.FC<PropertyManagerProps> = ({
  properties,
  onToggleActive,
  onAddProperty,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newProp, setNewProp] = useState<Partial<Property>>({
    name: '',
    location: '',
    destination: 'Manali',
    region: 'Hills',
    weekdayPrice: 2500,
    weekendPrice: 3000,
    maxGuests: 4,
    wfhReady: true,
    wifiSpeedMbps: 100,
    featured: false,
    mainImage: 'https://images.unsplash.com/photo-1587061949409-02df41d5e562?auto=format&fit=crop&w=1200&q=80',
    description: '',
  });

  const handleSubmitNew = (e: React.FormEvent) => {
    e.preventDefault();
    if (onAddProperty) {
      onAddProperty(newProp);
    }
    setShowAddModal(false);
  };

  const airtableBaseId = import.meta.env.VITE_AIRTABLE_BASE_ID;
  const propertiesTableId = import.meta.env.VITE_PROPERTIES_TABLE_ID || 'tblProperties';
  const airtableUrl = airtableBaseId
    ? `https://airtable.com/${airtableBaseId}/${propertiesTableId}`
    : 'https://airtable.com';

  return (
    <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-sm space-y-4 p-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-lg font-bold text-stone-900 font-display">
            Homestay Properties ({properties.length})
          </h3>
          <p className="text-xs text-stone-500">
            Managed via Airtable database & sync layer
          </p>
        </div>

        <div className="flex items-center gap-2">
          <a
            href={airtableUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-stone-300 text-stone-700 hover:bg-stone-50 text-xs font-semibold"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Open in Airtable</span>
          </a>

          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#2D5016] text-white hover:bg-[#1F380F] text-xs font-semibold shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Add Property</span>
          </button>
        </div>
      </div>

      {/* Property rows */}
      <div className="divide-y divide-stone-100">
        {properties.map((p) => (
          <div
            key={p.id}
            className="py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:bg-stone-50/60 p-2 rounded-xl transition-colors"
          >
            <div className="flex items-center gap-3">
              <img
                src={p.mainImage}
                alt={p.name}
                className="w-16 h-12 object-cover rounded-lg border border-stone-200"
              />
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-bold text-stone-900 font-display">{p.name}</h4>
                  {p.featured && (
                    <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
                      Featured
                    </span>
                  )}
                  {p.wfhReady && (
                    <span className="text-[10px] bg-emerald-100 text-[#2D5016] font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5">
                      <Wifi className="w-2.5 h-2.5" /> WFH
                    </span>
                  )}
                </div>
                <p className="text-xs text-stone-500">
                  {p.location} • {formatPrice(p.weekdayPrice)}/night • Max {p.maxGuests} guests
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 self-end sm:self-center">
              <span
                className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                  p.isActive !== false
                    ? 'bg-emerald-100 text-[#2D5016]'
                    : 'bg-stone-100 text-stone-500'
                }`}
              >
                {p.isActive !== false ? 'Active' : 'Hidden'}
              </span>

              {onToggleActive && (
                <button
                  onClick={() => onToggleActive(p.id, p.isActive !== false)}
                  className="px-2.5 py-1 text-xs font-semibold text-stone-600 hover:text-stone-900 border border-stone-300 rounded-lg"
                >
                  {p.isActive !== false ? 'Deactivate' : 'Activate'}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Add Property Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-bold text-stone-900 font-display">
              Add New Verified Homestay
            </h3>

            <form onSubmit={handleSubmitNew} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Property Name</label>
                <input
                  type="text"
                  required
                  value={newProp.name}
                  onChange={(e) => setNewProp({ ...newProp, name: e.target.value })}
                  placeholder="e.g. Parvati Riverside Woodhouse"
                  className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:border-[#2D5016]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Destination</label>
                  <input
                    type="text"
                    required
                    value={newProp.destination}
                    onChange={(e) => setNewProp({ ...newProp, destination: e.target.value })}
                    placeholder="e.g. Kasol"
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:border-[#2D5016]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Region</label>
                  <select
                    value={newProp.region}
                    onChange={(e) => setNewProp({ ...newProp, region: e.target.value as any })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:border-[#2D5016]"
                  >
                    <option value="Hills">Hills</option>
                    <option value="Beach">Beach</option>
                    <option value="Forest">Forest</option>
                    <option value="Heritage">Heritage</option>
                    <option value="Village">Village</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Location Details</label>
                <input
                  type="text"
                  required
                  value={newProp.location}
                  onChange={(e) => setNewProp({ ...newProp, location: e.target.value })}
                  placeholder="e.g. Jibhi, Kullu, Himachal Pradesh"
                  className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:border-[#2D5016]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Weekday Rate (₹)</label>
                  <input
                    type="number"
                    required
                    value={newProp.weekdayPrice}
                    onChange={(e) => setNewProp({ ...newProp, weekdayPrice: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:border-[#2D5016]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Weekend Rate (₹)</label>
                  <input
                    type="number"
                    required
                    value={newProp.weekendPrice}
                    onChange={(e) => setNewProp({ ...newProp, weekendPrice: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:border-[#2D5016]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Main Image URL</label>
                <input
                  type="url"
                  required
                  value={newProp.mainImage}
                  onChange={(e) => setNewProp({ ...newProp, mainImage: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-none focus:border-[#2D5016]"
                />
              </div>

              <div className="flex items-center gap-4 py-1">
                <label className="flex items-center gap-1.5 font-bold text-stone-700">
                  <input
                    type="checkbox"
                    checked={newProp.wfhReady}
                    onChange={(e) => setNewProp({ ...newProp, wfhReady: e.target.checked })}
                  />
                  <span>WFH Ready</span>
                </label>
                <label className="flex items-center gap-1.5 font-bold text-stone-700">
                  <input
                    type="checkbox"
                    checked={newProp.featured}
                    onChange={(e) => setNewProp({ ...newProp, featured: e.target.checked })}
                  />
                  <span>Featured on Homepage</span>
                </label>
              </div>

              <div className="flex gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 font-bold text-stone-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#2D5016] text-white font-bold hover:bg-[#1F380F]"
                >
                  Save & Publish
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
