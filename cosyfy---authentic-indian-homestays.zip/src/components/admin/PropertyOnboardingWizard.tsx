import React, { useState } from 'react';
import {
  X,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  Building,
  User,
  ShieldCheck,
  Upload,
  FileText,
  MapPin,
  Bed,
  Wifi,
  DollarSign,
  Camera,
  FileCheck,
  Plus,
  Trash2,
  Info,
  Sparkles,
  AlertCircle,
  Eye,
  EyeOff,
} from 'lucide-react';
import { AdminPropertyItem, PropertyLead } from '../../services/adminData';
import { logAuditEvent } from '../../services/auth';

interface PropertyOnboardingWizardProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (property: AdminPropertyItem) => void;
  initialData?: AdminPropertyItem | null;
  fromLead?: PropertyLead | null;
}

const INDIAN_STATES = [
  'Himachal Pradesh',
  'Uttarakhand',
  'Jammu & Kashmir',
  'Ladakh',
  'Kerala',
  'Goa',
  'Karnataka',
  'Tamil Nadu',
  'Maharashtra',
  'Rajasthan',
  'Sikkim',
  'Meghalaya',
  'West Bengal',
  'Assam',
  'Arunachal Pradesh',
  'Nagaland',
  'Manipur',
  'Mizoram',
  'Tripura',
  'Andhra Pradesh',
  'Telangana',
  'Madhya Pradesh',
  'Gujarat',
  'Punjab',
  'Haryana',
  'Uttar Pradesh',
  'Bihar',
  'Odisha',
  'Jharkhand',
  'Chhattisgarh',
];

const PROPERTY_TYPES = [
  'Homestay',
  'Villa',
  'Cottage',
  'Farm Stay',
  'Heritage Stay',
  'Treehouse',
  'Mountain Chalet',
  'Orchard Retreat',
];

const ESSENTIAL_AMENITIES = [
  'High-Speed WiFi',
  'Power Backup / Inverter',
  'Hot Water / Geyser',
  'Mountain View',
  'Valley View',
  'Apple Orchard / Garden',
  'Bonfire Setup',
  'Indoor Fireplace',
  'Pet Friendly',
  'Free Parking',
  'Homecooked Meals',
  'Dedicated Work Desk & Ergonomic Chair',
  'Balcony / Sit-out',
  'Heater on Request',
  'Kitchen Access',
  'Filtered RO Drinking Water',
];

const SAMPLE_PHOTO_PRESETS = [
  'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=1200&q=80',
];

export const PropertyOnboardingWizard: React.FC<PropertyOnboardingWizardProps> = ({
  isOpen,
  onClose,
  onSave,
  initialData,
  fromLead,
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);

  // STEP 1: Owner & Business Details
  const [ownerName, setOwnerName] = useState(
    initialData?.ownerName || fromLead?.ownerName || ''
  );
  const [ownerPhone, setOwnerPhone] = useState(
    initialData?.ownerPhone || initialData?.ownerWhatsapp || fromLead?.mobile || ''
  );
  const [ownerWhatsapp, setOwnerWhatsapp] = useState(
    initialData?.ownerWhatsapp || fromLead?.whatsapp || ''
  );
  const [ownerEmail, setOwnerEmail] = useState(
    initialData?.ownerEmail || fromLead?.email || ''
  );
  const [ownerAadhaar, setOwnerAadhaar] = useState(
    initialData?.ownerAadhaar || '4582 9182 3918'
  );
  const [showAadhaar, setShowAadhaar] = useState(false);
  const [ownerPan, setOwnerPan] = useState(initialData?.ownerPan || 'ABCDE1234F');
  const [businessType, setBusinessType] = useState(
    initialData?.businessType || 'Individual'
  );
  const [isGstRegistered, setIsGstRegistered] = useState(
    Boolean(initialData?.isGstRegistered)
  );
  const [businessGstNumber, setBusinessGstNumber] = useState(
    initialData?.businessGstNumber || ''
  );
  const [bankAccountHolder, setBankAccountHolder] = useState(
    initialData?.bankAccountHolder || ownerName || ''
  );
  const [bankAccountNumber, setBankAccountNumber] = useState(
    initialData?.bankAccountNumber || '309182746192'
  );
  const [showBankAcc, setShowBankAcc] = useState(false);
  const [bankIfsc, setBankIfsc] = useState(initialData?.bankIfsc || 'SBIN0001234');
  const [upiId, setUpiId] = useState(initialData?.upiId || 'host@upi');

  // Documents
  const [aadhaarDoc, setAadhaarDoc] = useState(
    initialData?.documents?.aadhaarDoc || 'aadhaar_card_verified.pdf'
  );
  const [propertyProof, setPropertyProof] = useState(
    initialData?.documents?.propertyProof || 'electricity_bill_latest.pdf'
  );
  const [businessRegDoc, setBusinessRegDoc] = useState(
    initialData?.documents?.businessRegDoc || ''
  );
  const [gstDoc, setGstDoc] = useState(initialData?.documents?.gstDoc || '');
  const [cancelledCheque, setCancelledCheque] = useState(
    initialData?.documents?.cancelledCheque || 'cancelled_cheque_sbi.jpg'
  );

  // STEP 2: Property Basic Info & Location
  const [propertyName, setPropertyName] = useState(
    initialData?.name || fromLead?.propertyName || ''
  );
  const [propertyType, setPropertyType] = useState(
    initialData?.propertyType || fromLead?.propertyType || 'Homestay'
  );
  const [tagline, setTagline] = useState(
    initialData?.tagline || 'Tranquil Himalayan hideaway with majestic valley panorama'
  );
  const [state, setState] = useState(
    initialData?.state || fromLead?.state || 'Himachal Pradesh'
  );
  const [district, setDistrict] = useState(
    initialData?.district || fromLead?.district || 'Kullu'
  );
  const [nearestTown, setNearestTown] = useState(
    initialData?.nearestTown || fromLead?.approxLocation || 'Naggar / Manali'
  );
  const [googleMapsUrl, setGoogleMapsUrl] = useState(
    initialData?.googleMapsUrl || 'https://maps.google.com/?q=32.18,77.16'
  );
  const [directionsAir, setDirectionsAir] = useState(
    initialData?.directionsAir || 'Kullu Bhuntar Airport (KUU) - 34 km via NH3'
  );
  const [directionsTrain, setDirectionsTrain] = useState(
    initialData?.directionsTrain || 'Chandigarh Junction - 260 km'
  );
  const [directionsRoad, setDirectionsRoad] = useState(
    initialData?.directionsRoad || 'Well-paved private road 800m off the main Naggar highway'
  );
  const [airportDistance, setAirportDistance] = useState('34');
  const [railwayDistance, setRailwayDistance] = useState('260');
  const [busStopDistance, setBusStopDistance] = useState('1.5');
  const [isRemoteProperty, setIsRemoteProperty] = useState(
    Boolean(initialData?.isRemoteProperty)
  );

  // STEP 3: Rooms & Capacity
  const [totalRooms, setTotalRooms] = useState(
    initialData?.totalRooms || fromLead?.roomsCount || 4
  );
  const [maxGuests, setMaxGuests] = useState(initialData?.maxGuests || 10);
  const [roomConfigs, setRoomConfigs] = useState([
    { id: '1', name: 'Deluxe Valley View Room', bedType: 'King Bed', attachedBathroom: true, count: 2 },
    { id: '2', name: 'Pine Orchard Attic Suite', bedType: 'Queen + Single', attachedBathroom: true, count: 1 },
    { id: '3', name: 'Cosy Mountain Balcony Room', bedType: 'Queen Bed', attachedBathroom: true, count: 1 },
  ]);
  const [totalBathrooms, setTotalBathrooms] = useState(initialData?.totalBathrooms || 4);
  const [kitchenAccess, setKitchenAccess] = useState(
    initialData?.kitchenAccess || 'Fully equipped'
  );

  // STEP 4: Amenities & Workation Readiness
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>(
    initialData?.amenities || [
      'High-Speed WiFi',
      'Power Backup / Inverter',
      'Hot Water / Geyser',
      'Mountain View',
      'Homecooked Meals',
      'Dedicated Work Desk & Ergonomic Chair',
    ]
  );
  const [isWfhReady, setIsWfhReady] = useState(
    initialData?.isWfhReady ?? true
  );
  const [wifiSpeedMbps, setWifiSpeedMbps] = useState(initialData?.wifiSpeedMbps || 120);
  const [powerBackupHours, setPowerBackupHours] = useState(
    initialData?.powerBackupHours || 8
  );
  const [mobileNetworks, setMobileNetworks] = useState<string[]>(
    initialData?.mobileNetworks || ['Jio (4G/5G)', 'Airtel (4G/5G)']
  );

  // STEP 5: Pricing, Commission & Payout Terms
  const [weekdayPrice, setWeekdayPrice] = useState(initialData?.weekdayPrice || 2800);
  const [weekendPrice, setWeekendPrice] = useState(initialData?.weekendPrice || 3400);
  const [weeklyDiscountPercent, setWeeklyDiscountPercent] = useState(
    initialData?.weeklyDiscountPercent || 15
  );
  const [monthlyDiscountPercent, setMonthlyDiscountPercent] = useState(
    initialData?.monthlyDiscountPercent || 35
  );
  const [commissionPercent, setCommissionPercent] = useState(
    initialData?.commissionPercent || 10
  );
  const [extraGuestCharge, setExtraGuestCharge] = useState(
    initialData?.extraGuestCharge || 700
  );
  const [childPolicy, setChildPolicy] = useState(
    initialData?.childPolicy || 'Children under 6 stay free with existing bedding'
  );

  // STEP 6: Media & Visuals
  const [mainImage, setMainImage] = useState(
    initialData?.mainImage ||
      fromLead?.description?.includes('villa')
        ? SAMPLE_PHOTO_PRESETS[1]
        : SAMPLE_PHOTO_PRESETS[0]
  );
  const [galleryImages, setGalleryImages] = useState<string[]>(
    initialData?.galleryImages || [
      SAMPLE_PHOTO_PRESETS[1],
      SAMPLE_PHOTO_PRESETS[2],
      SAMPLE_PHOTO_PRESETS[3],
    ]
  );
  const [videoTourUrl, setVideoTourUrl] = useState(
    initialData?.videoTourUrl || 'https://youtube.com/watch?v=sample-walkthrough'
  );
  const [virtualTour360Url, setVirtualTour360Url] = useState(
    initialData?.virtualTour360Url || ''
  );
  const [description, setDescription] = useState(
    initialData?.description ||
      fromLead?.description ||
      'Nestled amidst tranquil pine groves, this traditional mountain homestay offers authentic local hospitality, warm wood interiors, and wholesome organic meals.'
  );

  // STEP 7: House Rules, Policies & Submission
  const [checkInTime, setCheckInTime] = useState(initialData?.checkInTime || '1:00 PM');
  const [checkOutTime, setCheckOutTime] = useState(initialData?.checkOutTime || '11:00 AM');
  const [smokingAllowed, setSmokingAllowed] = useState(
    Boolean(initialData?.smokingAllowed)
  );
  const [alcoholAllowed, setAlcoholAllowed] = useState(
    initialData?.alcoholAllowed ?? true
  );
  const [quietHours, setQuietHours] = useState(
    initialData?.quietHours || '10:00 PM to 7:00 AM'
  );
  const [cancellationPolicy, setCancellationPolicy] = useState(
    initialData?.cancellationPolicy ||
      (isRemoteProperty ? 'remote_upfront' : 'standard_7day')
  );
  const [agreeConduct, setAgreeConduct] = useState(true);
  const [agreeCommission, setAgreeCommission] = useState(true);
  const [agreePhotos, setAgreePhotos] = useState(true);

  if (!isOpen) return null;

  // Masking helpers
  const maskAadhaar = (val: string) => {
    const clean = val.replace(/\s+/g, '');
    if (clean.length < 4) return val;
    return `•••• •••• ${clean.slice(-4)}`;
  };

  const maskBank = (val: string) => {
    if (val.length < 4) return val;
    return `•••• •••• ${val.slice(-4)}`;
  };

  const toggleAmenity = (item: string) => {
    if (selectedAmenities.includes(item)) {
      setSelectedAmenities(selectedAmenities.filter((a) => a !== item));
    } else {
      setSelectedAmenities([...selectedAmenities, item]);
    }
  };

  const toggleNetwork = (net: string) => {
    if (mobileNetworks.includes(net)) {
      setMobileNetworks(mobileNetworks.filter((n) => n !== net));
    } else {
      setMobileNetworks([...mobileNetworks, net]);
    }
  };

  const addRoomConfig = () => {
    setRoomConfigs([
      ...roomConfigs,
      {
        id: String(Date.now()),
        name: 'New Room Category',
        bedType: 'Double Bed',
        attachedBathroom: true,
        count: 1,
      },
    ]);
  };

  const removeRoomConfig = (id: string) => {
    setRoomConfigs(roomConfigs.filter((r) => r.id !== id));
  };

  const handleNext = () => {
    if (currentStep === 1) {
      if (!ownerName.trim() || !ownerPhone.trim()) {
        alert('Please provide Owner Full Name and Mobile Number.');
        return;
      }
    } else if (currentStep === 2) {
      if (!propertyName.trim() || !state.trim()) {
        alert('Please provide Property Name and State.');
        return;
      }
    }
    setCurrentStep((prev) => Math.min(prev + 1, 7));
  };

  const handlePrev = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
  };

  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreeConduct || !agreeCommission || !agreePhotos) {
      alert('Please agree to all verification checkboxes to complete onboarding.');
      return;
    }

    const newSlug =
      initialData?.slug ||
      propertyName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

    const finalItem: AdminPropertyItem = {
      id: initialData?.id || `CSF-${String(Math.floor(100 + Math.random() * 900))}`,
      slug: newSlug,
      name: propertyName.trim(),
      state: state.trim(),
      district: district.trim(),
      location: `${district.trim()}, ${state.trim()}`,
      ownerName: ownerName.trim(),
      ownerWhatsapp: ownerWhatsapp.trim() || ownerPhone.trim(),
      ownerPhone: ownerPhone.trim(),
      ownerEmail: ownerEmail.trim(),
      ownerAadhaar: ownerAadhaar.trim(),
      ownerPan: ownerPan.trim(),
      businessType,
      businessGstNumber: isGstRegistered ? businessGstNumber : undefined,
      isGstRegistered,
      bankAccountHolder: bankAccountHolder.trim(),
      bankAccountNumber: bankAccountNumber.trim(),
      bankIfsc: bankIfsc.trim(),
      upiId: upiId.trim(),
      propertyType,
      tagline: tagline.trim(),
      nearestTown: nearestTown.trim(),
      googleMapsUrl: googleMapsUrl.trim(),
      directionsAir: directionsAir.trim(),
      directionsTrain: directionsTrain.trim(),
      directionsRoad: directionsRoad.trim(),
      totalRooms: Number(totalRooms),
      maxGuests: Number(maxGuests),
      totalBathrooms: Number(totalBathrooms),
      kitchenAccess,
      wifiSpeedMbps: Number(wifiSpeedMbps),
      powerBackupHours: Number(powerBackupHours),
      mobileNetworks,
      weeklyDiscountPercent: Number(weeklyDiscountPercent),
      monthlyDiscountPercent: Number(monthlyDiscountPercent),
      extraGuestCharge: Number(extraGuestCharge),
      childPolicy: childPolicy.trim(),
      galleryImages,
      videoTourUrl: videoTourUrl.trim(),
      virtualTour360Url: virtualTour360Url.trim(),
      checkInTime,
      checkOutTime,
      smokingAllowed,
      alcoholAllowed,
      quietHours,
      cancellationPolicy,
      documents: {
        aadhaarDoc,
        propertyProof,
        businessRegDoc,
        gstDoc,
        cancelledCheque,
      },
      weekdayPrice: Number(weekdayPrice),
      weekendPrice: Number(weekendPrice),
      commissionPercent: Number(commissionPercent) || 10,
      isActive: true,
      isAirbnbListed: true,
      isWfhReady: Boolean(isWfhReady),
      isRemoteProperty: Boolean(isRemoteProperty),
      enquiriesThisMonth: initialData?.enquiriesThisMonth || 0,
      bookingsThisMonth: initialData?.bookingsThisMonth || 0,
      mainImage: mainImage.trim(),
      description: description.trim(),
      amenities: selectedAmenities,
    };

    logAuditEvent(
      'PROPERTY_ONBOARDING_COMPLETED',
      `Full onboarding wizard finished for property "${finalItem.name}" (${finalItem.id}) in ${finalItem.location}. Commission set at ${finalItem.commissionPercent}%.`,
      {
        propertyId: finalItem.id,
        owner: finalItem.ownerName,
        wfhReady: finalItem.isWfhReady,
        remote: finalItem.isRemoteProperty,
      }
    );

    onSave(finalItem);
    onClose();
  };

  const stepsMeta = [
    { num: 1, label: 'Owner & KYC', icon: User },
    { num: 2, label: 'Location & Info', icon: MapPin },
    { num: 3, label: 'Rooms & Bedding', icon: Bed },
    { num: 4, label: 'Amenities & WFH', icon: Wifi },
    { num: 5, label: 'Pricing & Payout', icon: DollarSign },
    { num: 6, label: 'Photos & Media', icon: Camera },
    { num: 7, label: 'Policies & Done', icon: FileCheck },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full my-auto shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[95vh] animate-in zoom-in-95">
        {/* MODAL HEADER */}
        <div className="p-5 sm:p-6 bg-[#182a12] text-white flex items-center justify-between border-b border-emerald-900 shrink-0">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-900 border border-emerald-700 text-emerald-300 text-[10px] font-bold uppercase tracking-wider">
                7-Step Verified Onboarding
              </span>
              {fromLead && (
                <span className="px-2 py-0.5 rounded-full bg-amber-900/80 text-amber-300 text-[10px] font-bold">
                  From Lead {fromLead.id}
                </span>
              )}
            </div>
            <h2 className="text-lg sm:text-xl font-bold font-display text-white">
              {initialData ? `Edit Listing: ${initialData.name}` : 'Onboard New Verified Homestay'}
            </h2>
            <p className="text-xs text-stone-300">
              Complete host details, verify documents, set room configuration, and launch on Cosyfy.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/10 text-stone-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* STEP PROGRESS TRACKER */}
        <div className="bg-[#FAF7F2] border-b border-stone-200 px-4 py-3 shrink-0 overflow-x-auto">
          <div className="flex items-center justify-between min-w-[650px] gap-2">
            {stepsMeta.map((s) => {
              const Icon = s.icon;
              const isCurrent = currentStep === s.num;
              const isPast = currentStep > s.num;
              return (
                <button
                  type="button"
                  key={s.num}
                  onClick={() => setCurrentStep(s.num)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    isCurrent
                      ? 'bg-[#2D5016] text-white shadow-xs'
                      : isPast
                      ? 'bg-emerald-100 text-[#2D5016]'
                      : 'text-stone-500 hover:text-stone-800'
                  }`}
                >
                  <span
                    className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      isCurrent
                        ? 'bg-white text-[#2D5016]'
                        : isPast
                        ? 'bg-[#2D5016] text-white'
                        : 'bg-stone-200 text-stone-600'
                    }`}
                  >
                    {isPast ? '✓' : s.num}
                  </span>
                  <span>{s.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* WIZARD BODY */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-8 space-y-6 text-xs sm:text-sm">
          {/* STEP 1: Owner & Business Details */}
          {currentStep === 1 && (
            <div className="space-y-6 animate-in fade-in">
              <div className="border-b border-stone-200 pb-3">
                <h3 className="text-base sm:text-lg font-bold font-display text-stone-900">
                  Step 1: Owner & Business Verification Details
                </h3>
                <p className="text-xs text-stone-500">
                  Contact details, government identity verification, bank account, and KYC documents.
                </p>
              </div>

              {/* Personal Contact */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Owner Full Name <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={ownerName}
                    onChange={(e) => setOwnerName(e.target.value)}
                    placeholder="e.g. Rameshwar Singh Thakur"
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold text-stone-800"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Owner Mobile Phone <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={ownerPhone}
                    onChange={(e) => setOwnerPhone(e.target.value)}
                    placeholder="e.g. +91 98160 54321"
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold text-stone-800"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Owner WhatsApp</label>
                  <input
                    type="tel"
                    value={ownerWhatsapp}
                    onChange={(e) => setOwnerWhatsapp(e.target.value)}
                    placeholder="e.g. +91 98160 54321"
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold text-stone-800"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Owner Email</label>
                  <input
                    type="email"
                    value={ownerEmail}
                    onChange={(e) => setOwnerEmail(e.target.value)}
                    placeholder="e.g. host.orchard@gmail.com"
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold text-stone-800"
                  />
                </div>
              </div>

              {/* Identity & Legal Entity */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Aadhaar Number (Masked)
                  </label>
                  <div className="relative">
                    <input
                      type={showAadhaar ? 'text' : 'password'}
                      value={ownerAadhaar}
                      onChange={(e) => setOwnerAadhaar(e.target.value)}
                      placeholder="12 digit Aadhaar"
                      className="w-full p-2.5 pr-9 rounded-xl border border-stone-300 font-mono font-semibold text-stone-800"
                    />
                    <button
                      type="button"
                      onClick={() => setShowAadhaar(!showAadhaar)}
                      className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-700"
                    >
                      {showAadhaar ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-[10px] text-stone-400 mt-1">
                    Display preview: {maskAadhaar(ownerAadhaar)}
                  </p>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    PAN Number (Optional)
                  </label>
                  <input
                    type="text"
                    value={ownerPan}
                    onChange={(e) => setOwnerPan(e.target.value.toUpperCase())}
                    placeholder="e.g. ABCDE1234F"
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-mono uppercase font-semibold text-stone-800"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Business Type</label>
                  <select
                    value={businessType}
                    onChange={(e) => setBusinessType(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold text-stone-800"
                  >
                    <option value="Individual">Individual</option>
                    <option value="Proprietorship">Proprietorship</option>
                    <option value="Partnership Firm">Partnership Firm</option>
                    <option value="LLP">LLP</option>
                    <option value="Private Limited">Private Limited</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              {/* GST Toggle */}
              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-stone-800">GST Registered?</span>
                    <p className="text-[11px] text-stone-500">
                      Most small rural homestays do not require GST registration.
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isGstRegistered}
                      onChange={(e) => setIsGstRegistered(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#2D5016]"></div>
                  </label>
                </div>

                {isGstRegistered && (
                  <div className="pt-2 animate-in fade-in">
                    <label className="block font-bold text-stone-700 mb-1">
                      GSTIN Registration Number
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 02AAAAA0000A1Z5"
                      value={businessGstNumber}
                      onChange={(e) => setBusinessGstNumber(e.target.value.toUpperCase())}
                      className="w-full p-2.5 rounded-xl border border-stone-300 font-mono font-semibold"
                    />
                  </div>
                )}
              </div>

              {/* Bank & Payout Information */}
              <div className="space-y-3">
                <h4 className="font-bold text-stone-800 text-xs uppercase tracking-wider text-emerald-800">
                  Bank Account & Payout Details
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">
                      Account Holder Name
                    </label>
                    <input
                      type="text"
                      value={bankAccountHolder}
                      onChange={(e) => setBankAccountHolder(e.target.value)}
                      placeholder="As per passbook"
                      className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">
                      Account Number (Masked)
                    </label>
                    <div className="relative">
                      <input
                        type={showBankAcc ? 'text' : 'password'}
                        value={bankAccountNumber}
                        onChange={(e) => setBankAccountNumber(e.target.value)}
                        placeholder="e.g. 11-16 digits"
                        className="w-full p-2.5 pr-9 rounded-xl border border-stone-300 font-mono font-semibold"
                      />
                      <button
                        type="button"
                        onClick={() => setShowBankAcc(!showBankAcc)}
                        className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-700"
                      >
                        {showBankAcc ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <span className="text-[10px] text-stone-400">
                      Display: {maskBank(bankAccountNumber)}
                    </span>
                  </div>
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">IFSC Code</label>
                    <input
                      type="text"
                      value={bankIfsc}
                      onChange={(e) => setBankIfsc(e.target.value.toUpperCase())}
                      placeholder="e.g. SBIN0001234"
                      className="w-full p-2.5 rounded-xl border border-stone-300 font-mono uppercase font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">UPI ID</label>
                    <input
                      type="text"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      placeholder="e.g. owner@okhdfcbank"
                      className="w-full p-2.5 rounded-xl border border-stone-300 font-mono font-semibold"
                    />
                  </div>
                </div>
              </div>

              {/* Document Uploads Section */}
              <div className="space-y-3 pt-2">
                <h4 className="font-bold text-stone-800 text-xs uppercase tracking-wider text-emerald-800">
                  KYC & Property Document Uploads
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 rounded-2xl border border-stone-200 bg-stone-50 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <FileText className="w-5 h-5 text-[#2D5016]" />
                      <div>
                        <p className="font-bold text-stone-800">Aadhaar Card (Front + Back)</p>
                        <p className="text-[10px] text-stone-500 font-mono truncate max-w-[180px]">
                          {aadhaarDoc || 'No document selected'}
                        </p>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-[#2D5016] text-[10px] font-bold">
                      Verified
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl border border-stone-200 bg-stone-50 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <FileText className="w-5 h-5 text-[#2D5016]" />
                      <div>
                        <p className="font-bold text-stone-800">Ownership Proof (Electricity/Tax)</p>
                        <p className="text-[10px] text-stone-500 font-mono truncate max-w-[180px]">
                          {propertyProof || 'No document selected'}
                        </p>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-[#2D5016] text-[10px] font-bold">
                      Verified
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl border border-stone-200 bg-stone-50 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <FileText className="w-5 h-5 text-[#2D5016]" />
                      <div>
                        <p className="font-bold text-stone-800">Cancelled Cheque / Passbook</p>
                        <p className="text-[10px] text-stone-500 font-mono truncate max-w-[180px]">
                          {cancelledCheque || 'No document selected'}
                        </p>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-[#2D5016] text-[10px] font-bold">
                      Verified
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl border border-stone-200 bg-stone-50 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <FileText className="w-5 h-5 text-stone-400" />
                      <div>
                        <p className="font-bold text-stone-800">Business / GST Certificate</p>
                        <p className="text-[10px] text-stone-400">Optional for homestays</p>
                      </div>
                    </div>
                    <span className="text-[10px] text-stone-400">Optional</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: Property Basic Info & Location */}
          {currentStep === 2 && (
            <div className="space-y-6 animate-in fade-in">
              <div className="border-b border-stone-200 pb-3">
                <h3 className="text-base sm:text-lg font-bold font-display text-stone-900">
                  Step 2: Property Basic Info & Detailed Location
                </h3>
                <p className="text-xs text-stone-500">
                  Listing branding, geographic coordinates, and transportation transit points.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Property Name <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={propertyName}
                    onChange={(e) => setPropertyName(e.target.value)}
                    placeholder="e.g. Chandi Apple Orchard Retreat"
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold text-stone-800"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Property Type</label>
                  <select
                    value={propertyType}
                    onChange={(e) => setPropertyType(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold text-stone-800"
                  >
                    {PROPERTY_TYPES.map((pt) => (
                      <option key={pt} value={pt}>
                        {pt}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Tagline / Subtitle</label>
                <input
                  type="text"
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  placeholder="e.g. 100-year traditional wooden villa nestled among organic apple trees"
                  className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold text-stone-800"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">State</label>
                  <select
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold text-stone-800"
                  >
                    {INDIAN_STATES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">District</label>
                  <input
                    type="text"
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    placeholder="e.g. Kullu, Nainital"
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold text-stone-800"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Nearest Town / Area</label>
                  <input
                    type="text"
                    value={nearestTown}
                    onChange={(e) => setNearestTown(e.target.value)}
                    placeholder="e.g. Naggar Castle Road"
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold text-stone-800"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">
                  Google Maps Link / GPS Pin
                </label>
                <input
                  type="url"
                  value={googleMapsUrl}
                  onChange={(e) => setGoogleMapsUrl(e.target.value)}
                  placeholder="https://maps.app.goo.gl/..."
                  className="w-full p-2.5 rounded-xl border border-stone-300 font-mono text-xs font-medium text-stone-800"
                />
              </div>

              {/* Transit Distances */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Airport Distance (km)</label>
                  <input
                    type="text"
                    value={airportDistance}
                    onChange={(e) => setAirportDistance(e.target.value)}
                    placeholder="e.g. 34 km"
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Railway Distance (km)
                  </label>
                  <input
                    type="text"
                    value={railwayDistance}
                    onChange={(e) => setRailwayDistance(e.target.value)}
                    placeholder="e.g. 140 km"
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Bus Stop Distance (km)</label>
                  <input
                    type="text"
                    value={busStopDistance}
                    onChange={(e) => setBusStopDistance(e.target.value)}
                    placeholder="e.g. 1 km"
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                  />
                </div>
              </div>

              {/* Remote Property Flag */}
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <span className="font-bold text-amber-950 flex items-center gap-1.5">
                    <span>🏔️ Remote Property Designation</span>
                  </span>
                  <p className="text-[11px] text-amber-900 leading-relaxed">
                    Check this if the homestay is located in remote, off-grid Himalayan valleys (e.g.
                    Spiti, Zanskar, Kalpa, interior Tirthan). Requires 100% advance payment upfront by
                    guests and 15-day non-refundable lock.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-1">
                  <input
                    type="checkbox"
                    checked={isRemoteProperty}
                    onChange={(e) => setIsRemoteProperty(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                </label>
              </div>
            </div>
          )}

          {/* STEP 3: Rooms & Capacity */}
          {currentStep === 3 && (
            <div className="space-y-6 animate-in fade-in">
              <div className="border-b border-stone-200 pb-3">
                <h3 className="text-base sm:text-lg font-bold font-display text-stone-900">
                  Step 3: Rooms, Bed Configurations & Capacity
                </h3>
                <p className="text-xs text-stone-500">
                  Define total guest capacity and specify room configurations.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Total Rooms for Guests
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={totalRooms}
                    onChange={(e) => setTotalRooms(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Max Guest Capacity</label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={maxGuests}
                    onChange={(e) => setMaxGuests(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Total Bathrooms</label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={totalBathrooms}
                    onChange={(e) => setTotalBathrooms(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Kitchen Access for Guests</label>
                <select
                  value={kitchenAccess}
                  onChange={(e) => setKitchenAccess(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                >
                  <option value="Fully equipped">Fully equipped guest kitchen with stove & fridge</option>
                  <option value="Basic kitchenette">Basic kitchenette (kettle, induction, microwave)</option>
                  <option value="No kitchen access">No kitchen access (host provides all meals)</option>
                </select>
              </div>

              {/* Dynamic Room Configurations List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-stone-800 text-xs uppercase tracking-wider text-emerald-800">
                    Room Categories & Bedding
                  </h4>
                  <button
                    type="button"
                    onClick={addRoomConfig}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-emerald-100 text-[#2D5016] text-xs font-bold hover:bg-emerald-200"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Room Type</span>
                  </button>
                </div>

                <div className="space-y-2">
                  {roomConfigs.map((rc, idx) => (
                    <div
                      key={rc.id}
                      className="p-3.5 rounded-2xl border border-stone-200 bg-stone-50 grid grid-cols-1 sm:grid-cols-12 gap-3 items-center text-xs"
                    >
                      <div className="sm:col-span-5">
                        <label className="block text-[10px] text-stone-500 font-bold mb-0.5">
                          Room Title
                        </label>
                        <input
                          type="text"
                          value={rc.name}
                          onChange={(e) => {
                            const updated = [...roomConfigs];
                            updated[idx].name = e.target.value;
                            setRoomConfigs(updated);
                          }}
                          className="w-full p-2 rounded-lg border border-stone-300 bg-white font-semibold"
                        />
                      </div>
                      <div className="sm:col-span-3">
                        <label className="block text-[10px] text-stone-500 font-bold mb-0.5">
                          Bed Type
                        </label>
                        <select
                          value={rc.bedType}
                          onChange={(e) => {
                            const updated = [...roomConfigs];
                            updated[idx].bedType = e.target.value;
                            setRoomConfigs(updated);
                          }}
                          className="w-full p-2 rounded-lg border border-stone-300 bg-white font-semibold"
                        >
                          <option value="King Bed">King Bed</option>
                          <option value="Queen Bed">Queen Bed</option>
                          <option value="Twin Single Beds">Twin Single Beds</option>
                          <option value="Queen + Single">Queen + Single</option>
                        </select>
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-[10px] text-stone-500 font-bold mb-0.5">
                          Quantity
                        </label>
                        <input
                          type="number"
                          min="1"
                          max="20"
                          value={rc.count}
                          onChange={(e) => {
                            const updated = [...roomConfigs];
                            updated[idx].count = Number(e.target.value);
                            setRoomConfigs(updated);
                          }}
                          className="w-full p-2 rounded-lg border border-stone-300 bg-white font-semibold"
                        />
                      </div>
                      <div className="sm:col-span-2 text-right">
                        {roomConfigs.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeRoomConfig(rc.id)}
                            className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: Amenities & Workation Readiness */}
          {currentStep === 4 && (
            <div className="space-y-6 animate-in fade-in">
              <div className="border-b border-stone-200 pb-3">
                <h3 className="text-base sm:text-lg font-bold font-display text-stone-900">
                  Step 4: Amenities & Remote Work Verification
                </h3>
                <p className="text-xs text-stone-500">
                  Select available property features and certify high-speed workation specs.
                </p>
              </div>

              {/* Amenities Grid */}
              <div className="space-y-3">
                <h4 className="font-bold text-stone-800 text-xs uppercase tracking-wider text-emerald-800">
                  Available Amenities & Property Features
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {ESSENTIAL_AMENITIES.map((amenity) => {
                    const isSelected = selectedAmenities.includes(amenity);
                    return (
                      <button
                        type="button"
                        key={amenity}
                        onClick={() => toggleAmenity(amenity)}
                        className={`p-3 rounded-xl border text-left text-xs font-semibold transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-emerald-50 border-[#2D5016] text-[#2D5016]'
                            : 'bg-white border-stone-200 text-stone-700 hover:bg-stone-50'
                        }`}
                      >
                        <span className="truncate">{amenity}</span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-[#2D5016] shrink-0 ml-1" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* WFH Verification Section */}
              <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-[#2D5016]" />
                    <span className="font-bold text-stone-900 text-sm">
                      Verified "Work From Mountains" Badge Checklist
                    </span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isWfhReady}
                      onChange={(e) => setIsWfhReady(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#2D5016]"></div>
                  </label>
                </div>

                {isWfhReady && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">
                        Verified WiFi Speed (Mbps)
                      </label>
                      <input
                        type="number"
                        min="20"
                        max="1000"
                        value={wifiSpeedMbps}
                        onChange={(e) => setWifiSpeedMbps(Number(e.target.value))}
                        className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold bg-white"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">
                        Power Backup Duration (Hours)
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="48"
                        value={powerBackupHours}
                        onChange={(e) => setPowerBackupHours(Number(e.target.value))}
                        className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold bg-white"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block font-bold text-stone-700 mb-1.5">
                        Active Mobile Cellular Networks (On-site signal verified)
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {['Jio (4G/5G)', 'Airtel (4G/5G)', 'Vi (Vodafone Idea)', 'BSNL 4G'].map(
                          (net) => {
                            const hasNet = mobileNetworks.includes(net);
                            return (
                              <button
                                type="button"
                                key={net}
                                onClick={() => toggleNetwork(net)}
                                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border ${
                                  hasNet
                                    ? 'bg-[#2D5016] text-white border-[#2D5016]'
                                    : 'bg-white text-stone-700 border-stone-300'
                                }`}
                              >
                                {hasNet ? `✓ ${net}` : net}
                              </button>
                            );
                          }
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 5: Pricing, Commission & Payout Terms */}
          {currentStep === 5 && (
            <div className="space-y-6 animate-in fade-in">
              <div className="border-b border-stone-200 pb-3">
                <h3 className="text-base sm:text-lg font-bold font-display text-stone-900">
                  Step 5: Pricing, Commission & Host Payout Terms
                </h3>
                <p className="text-xs text-stone-500">
                  Set baseline rates, long-stay workation discounts, and transparent commission fee.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Weekday Price (₹/night)
                  </label>
                  <input
                    type="number"
                    min="500"
                    step="100"
                    value={weekdayPrice}
                    onChange={(e) => setWeekdayPrice(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-bold text-stone-900"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Weekend Price (₹/night)
                  </label>
                  <input
                    type="number"
                    min="500"
                    step="100"
                    value={weekendPrice}
                    onChange={(e) => setWeekendPrice(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-bold text-stone-900"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Weekly Discount % (7+ nights)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="50"
                    value={weeklyDiscountPercent}
                    onChange={(e) => setWeeklyDiscountPercent(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-bold text-stone-900"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Monthly Discount % (30+ nights)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="70"
                    value={monthlyDiscountPercent}
                    onChange={(e) => setMonthlyDiscountPercent(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-bold text-stone-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Cosyfy Host Commission %
                  </label>
                  <input
                    type="number"
                    min="5"
                    max="25"
                    value={commissionPercent}
                    onChange={(e) => setCommissionPercent(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-bold text-[#2D5016]"
                  />
                  <p className="text-[10px] text-stone-500 mt-1">Default is 10% standard.</p>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Extra Guest Charge (₹/night)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="100"
                    value={extraGuestCharge}
                    onChange={(e) => setExtraGuestCharge(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold text-stone-900"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Child Policy</label>
                  <input
                    type="text"
                    value={childPolicy}
                    onChange={(e) => setChildPolicy(e.target.value)}
                    placeholder="e.g. Free under 6 years"
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold text-stone-900"
                  />
                </div>
              </div>

              {/* Commission Summary Card */}
              <div className="p-4 rounded-2xl bg-stone-100 border border-stone-200 text-xs space-y-1">
                <span className="font-bold text-stone-900">Example Payout Projection:</span>
                <p className="text-stone-600">
                  On a 5-night weekday booking of ₹{(weekdayPrice * 5).toLocaleString('en-IN')}:
                  Cosyfy commission ({commissionPercent}%) = ₹
                  {Math.round(weekdayPrice * 5 * (commissionPercent / 100)).toLocaleString('en-IN')}.
                  Host receives = ₹
                  {Math.round(weekdayPrice * 5 * (1 - commissionPercent / 100)).toLocaleString('en-IN')}.
                </p>
              </div>
            </div>
          )}

          {/* STEP 6: Media & Visuals */}
          {currentStep === 6 && (
            <div className="space-y-6 animate-in fade-in">
              <div className="border-b border-stone-200 pb-3">
                <h3 className="text-base sm:text-lg font-bold font-display text-stone-900">
                  Step 6: High-Definition Media & Property Photos
                </h3>
                <p className="text-xs text-stone-500">
                  Add cover photo, gallery images, video walkthrough links, and description.
                </p>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">
                  Main Cover Image URL <span className="text-rose-600">*</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    required
                    value={mainImage}
                    onChange={(e) => setMainImage(e.target.value)}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-mono text-xs"
                  />
                </div>
                {mainImage && (
                  <div className="mt-3 relative h-48 sm:h-64 rounded-2xl overflow-hidden border border-stone-200 shadow-inner">
                    <img
                      src={mainImage}
                      alt="Cover Preview"
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute bottom-2 left-2 px-2.5 py-1 rounded-lg bg-black/70 text-white text-[10px] font-bold">
                      Cover Photo Preview
                    </span>
                  </div>
                )}
              </div>

              {/* Preset Gallery Suggestions */}
              <div className="space-y-2">
                <label className="block font-bold text-stone-700">
                  Quick Photo Presets (Click to set):
                </label>
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {SAMPLE_PHOTO_PRESETS.map((url, i) => (
                    <button
                      type="button"
                      key={i}
                      onClick={() => setMainImage(url)}
                      className="w-20 h-14 rounded-xl overflow-hidden border-2 border-transparent hover:border-[#2D5016] shrink-0"
                    >
                      <img src={url} alt={`Preset ${i}`} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Video Walkthrough Link (YouTube / Drive)
                  </label>
                  <input
                    type="url"
                    value={videoTourUrl}
                    onChange={(e) => setVideoTourUrl(e.target.value)}
                    placeholder="https://youtube.com/watch?v=..."
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    360° Virtual Tour Link (Optional)
                  </label>
                  <input
                    type="url"
                    value={virtualTour360Url}
                    onChange={(e) => setVirtualTour360Url(e.target.value)}
                    placeholder="https://my.matterport.com/..."
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-mono text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">
                  Detailed Listing Description
                </label>
                <textarea
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full p-3 rounded-xl border border-stone-300 font-medium"
                />
              </div>
            </div>
          )}

          {/* STEP 7: House Rules, Policies & Submission */}
          {currentStep === 7 && (
            <div className="space-y-6 animate-in fade-in">
              <div className="border-b border-stone-200 pb-3">
                <h3 className="text-base sm:text-lg font-bold font-display text-stone-900">
                  Step 7: House Rules, Cancellation Policy & Host Declaration
                </h3>
                <p className="text-xs text-stone-500">
                  Finalize guest guidelines, cancellation terms, and publish the verified listing.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Check-in Time</label>
                  <input
                    type="text"
                    value={checkInTime}
                    onChange={(e) => setCheckInTime(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Check-out Time</label>
                  <input
                    type="text"
                    value={checkOutTime}
                    onChange={(e) => setCheckOutTime(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Quiet Hours</label>
                  <input
                    type="text"
                    value={quietHours}
                    onChange={(e) => setQuietHours(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                  />
                </div>
              </div>

              {/* Cancellation Policy Selection */}
              <div>
                <label className="block font-bold text-stone-700 mb-2">
                  Cancellation & Refund Policy
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setCancellationPolicy('standard_7day')}
                    className={`p-4 rounded-2xl border text-left space-y-1 transition-all ${
                      cancellationPolicy === 'standard_7day'
                        ? 'border-[#2D5016] bg-emerald-50/60 ring-2 ring-[#2D5016]/20'
                        : 'border-stone-200 bg-white'
                    }`}
                  >
                    <span className="font-bold text-stone-900 block text-xs">
                      Standard Cosyfy Policy (Recommended)
                    </span>
                    <p className="text-[11px] text-stone-600">
                      100% refundable if cancelled 7+ days before check-in. 10% advance collected
                      online; 90% balance paid directly to host on arrival.
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCancellationPolicy('remote_upfront')}
                    className={`p-4 rounded-2xl border text-left space-y-1 transition-all ${
                      cancellationPolicy === 'remote_upfront'
                        ? 'border-amber-600 bg-amber-50/60 ring-2 ring-amber-600/20'
                        : 'border-stone-200 bg-white'
                    }`}
                  >
                    <span className="font-bold text-amber-950 block text-xs">
                      Remote Property Policy
                    </span>
                    <p className="text-[11px] text-stone-600">
                      100% full payment upfront online due to remote logistics. 100% refundable up to
                      15 days before check-in. Non-refundable thereafter.
                    </p>
                  </button>
                </div>
              </div>

              {/* Host Code of Conduct & Agreements */}
              <div className="space-y-3 p-5 rounded-2xl bg-[#FAF7F2] border border-stone-200">
                <h4 className="font-bold text-stone-800 text-xs uppercase tracking-wider text-emerald-800">
                  Host Code of Conduct & Declarations
                </h4>

                <div className="space-y-2.5">
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={agreeConduct}
                      onChange={(e) => setAgreeConduct(e.target.checked)}
                      className="w-4 h-4 mt-0.5 rounded accent-[#2D5016]"
                    />
                    <span className="text-xs text-stone-700 leading-relaxed">
                      Host agrees to provide clean rooms, fresh linens, hot water, and authentic Indian
                      hospitality in accordance with Cosyfy standards.
                    </span>
                  </label>

                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={agreeCommission}
                      onChange={(e) => setAgreeCommission(e.target.checked)}
                      className="w-4 h-4 mt-0.5 rounded accent-[#2D5016]"
                    />
                    <span className="text-xs text-stone-700 leading-relaxed">
                      Host acknowledges the {commissionPercent}% Cosyfy commission fee charged only
                      upon successfully confirmed guest stays.
                    </span>
                  </label>

                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={agreePhotos}
                      onChange={(e) => setAgreePhotos(e.target.checked)}
                      className="w-4 h-4 mt-0.5 rounded accent-[#2D5016]"
                    />
                    <span className="text-xs text-stone-700 leading-relaxed">
                      All uploaded photos, amenities, and WiFi speed tests accurately represent the
                      physical property as verified by our operations team.
                    </span>
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* MODAL FOOTER CONTROLS */}
        <div className="p-4 sm:p-5 bg-stone-50 border-t border-stone-200 flex items-center justify-between shrink-0">
          <div>
            {currentStep > 1 && (
              <button
                type="button"
                onClick={handlePrev}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-stone-300 bg-white font-bold text-xs text-stone-700 hover:bg-stone-100"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-stone-500 font-semibold text-xs hover:bg-stone-200"
            >
              Cancel
            </button>

            {currentStep < 7 ? (
              <button
                type="button"
                onClick={handleNext}
                className="inline-flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-[#2D5016] text-white font-bold text-xs hover:bg-[#1f380f] shadow-sm"
              >
                <span>Continue to Step {currentStep + 1}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleFinalSubmit}
                className="inline-flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-[#C84B31] text-white font-bold text-xs hover:bg-[#b03f27] shadow-md hover:shadow-lg transition-all"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Publish & Onboard Homestay</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
