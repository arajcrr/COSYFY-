import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { getActiveSession, getRedirectPathForRole, UserRole } from '../../services/auth';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: UserRole[];
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, allowedRoles }) => {
  const location = useLocation();
  const session = getActiveSession();

  if (!session) {
    // Save current location so we can redirect after login if appropriate
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // If specific roles are required and user's role isn't authorized
  if (allowedRoles && allowedRoles.length > 0 && !allowedRoles.includes(session.user.role)) {
    // Redirect to user's authorized role dashboard
    const correctPath = getRedirectPathForRole(session.user.role);
    return <Navigate to={correctPath} replace />;
  }

  return <>{children}</>;
};
