import React from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle, MessageCircle } from 'lucide-react';
import { Property, Booking } from '../../types';
import { PropertyCard } from '../common/PropertyCard';
import { getWhatsAppUrl } from '../../utils';

interface AlternativesScreenProps {
  booking: Booking;
  alternatives: Property[];
}

export const AlternativesScreen: React.FC<AlternativesScreenProps> = ({
  booking,
  alternatives,
}) => {
  const whatsappNum = import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210';
  const whatsappUrl = getWhatsAppUrl(
    whatsappNum,
    `Hi Cosyfy! My request ${booking.bookingReference} for ${booking.propertyName} wasn't available. Can you help me find another verified stay nearby for ${booking.checkIn}?`
  );

  return (
    <div className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
      {/* Notice Header */}
      <div className="bg-amber-50 rounded-3xl p-6 sm:p-8 border border-amber-200 text-center max-w-2xl mx-auto space-y-4">
        <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
          <AlertCircle className="w-6 h-6" />
        </div>
        <h2 className="text-2xl font-bold text-stone-900 font-display">
          {booking.propertyName} is Fully Booked for Your Dates
        </h2>
        <p className="text-sm text-stone-600 leading-relaxed">
          The host family already had a direct booking for those dates. But don’t worry — zero fees were charged, and here are 3 verified homestays in the same region and price tier.
        </p>
        <div className="pt-2">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#25D366] text-white font-bold text-xs hover:bg-[#20ba59] shadow-md transition-all"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>Chat With Concierge to Find Stays</span>
          </a>
        </div>
      </div>

      {/* 3 Similar Alternative Properties */}
      <div>
        <h3 className="text-xl font-bold text-[#1A1A1A] font-display mb-6">
          Recommended Alternative Homestays:
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {alternatives.slice(0, 3).map((prop) => (
            <PropertyCard key={prop.id} property={prop} />
          ))}
        </div>
      </div>
    </div>
  );
};
