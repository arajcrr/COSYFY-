import React, { useState } from 'react';
import {
  CreditCard,
  Smartphone,
  Building,
  Wallet,
  CheckCircle2,
  Lock,
  X,
  ShieldCheck,
  Loader2,
} from 'lucide-react';
import { formatPrice } from '../../utils';
import { isRazorpayLive, openLiveRazorpayCheckout } from '../../services/razorpay';

interface PaymentModalProps {
  amount: number;
  propertyName: string;
  guestName: string;
  guestEmail: string;
  guestPhone: string;
  onPaymentSuccess: (paymentId: string) => void;
  onClose: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  amount,
  propertyName,
  guestName,
  guestEmail,
  guestPhone,
  onPaymentSuccess,
  onClose,
}) => {
  const [tab, setTab] = useState<'upi' | 'card' | 'netbanking' | 'wallet'>('upi');
  const [upiId, setUpiId] = useState('user@okaxis');
  const [cardNumber, setCardNumber] = useState('4532 •••• •••• 8910');
  const [cardExpiry, setCardExpiry] = useState('11/28');
  const [cardCvv, setCardCvv] = useState('•••');
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    if (isRazorpayLive()) {
      const opened = await openLiveRazorpayCheckout({
        amount,
        propertyName,
        guestName,
        guestEmail,
        guestPhone,
        onSuccess: (paymentId) => {
          setIsProcessing(false);
          setIsSuccess(true);
          setTimeout(() => {
            onPaymentSuccess(paymentId);
          }, 1000);
        },
        onFailure: () => {
          setIsProcessing(false);
        },
        onDismiss: () => {
          setIsProcessing(false);
        },
      });
      if (opened) return;
    }

    // Demo Mode: Simulate Razorpay secure payment gateway confirmation after 2 seconds
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);

      setTimeout(() => {
        const dummyPayId = `pay_cosy_${Math.random().toString(36).substring(2, 10).toUpperCase()}`;
        onPaymentSuccess(dummyPayId);
      }, 1500);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95 flex flex-col">
        {/* Razorpay Gateway Header */}
        <div className="bg-[#0c2340] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600/30 flex items-center justify-center border border-blue-400/30">
              <span className="font-bold text-xs tracking-wider text-blue-300">RZP</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold tracking-wider uppercase text-blue-200">
                  Razorpay Checkout
                </span>
                <span className="text-[10px] bg-amber-400 text-stone-900 font-extrabold px-1.5 py-0.2 rounded">
                  DEMO MODE
                </span>
              </div>
              <h3 className="text-sm font-bold text-white truncate max-w-[240px]">
                {propertyName}
              </h3>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-blue-200 block">Amount to Pay</span>
            <span className="text-lg font-extrabold text-white">{formatPrice(amount)}</span>
          </div>
        </div>

        {isSuccess ? (
          /* Payment Successful State */
          <div className="p-8 text-center space-y-4 my-auto">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-[#2D5016] flex items-center justify-center mx-auto animate-bounce">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h4 className="text-xl font-bold text-stone-900 font-display">
              Payment Successful!
            </h4>
            <p className="text-xs text-stone-600">
              Received {formatPrice(amount)} via Razorpay. Recording your reservation request...
            </p>
          </div>
        ) : (
          <form onSubmit={handlePay} className="p-6 space-y-5">
            {/* Payment Method Tabs */}
            <div className="grid grid-cols-4 gap-1.5 p-1 bg-stone-100 rounded-2xl text-xs font-semibold">
              <button
                type="button"
                onClick={() => setTab('upi')}
                className={`py-2 px-1 rounded-xl flex flex-col items-center gap-1 transition-all ${
                  tab === 'upi' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <Smartphone className="w-4 h-4 text-[#2D5016]" />
                <span className="text-[11px]">UPI / QR</span>
              </button>

              <button
                type="button"
                onClick={() => setTab('card')}
                className={`py-2 px-1 rounded-xl flex flex-col items-center gap-1 transition-all ${
                  tab === 'card' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <CreditCard className="w-4 h-4 text-[#C84B31]" />
                <span className="text-[11px]">Card</span>
              </button>

              <button
                type="button"
                onClick={() => setTab('netbanking')}
                className={`py-2 px-1 rounded-xl flex flex-col items-center gap-1 transition-all ${
                  tab === 'netbanking' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <Building className="w-4 h-4 text-blue-700" />
                <span className="text-[11px]">Netbanking</span>
              </button>

              <button
                type="button"
                onClick={() => setTab('wallet')}
                className={`py-2 px-1 rounded-xl flex flex-col items-center gap-1 transition-all ${
                  tab === 'wallet' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <Wallet className="w-4 h-4 text-purple-700" />
                <span className="text-[11px]">Wallets</span>
              </button>
            </div>

            {/* Tab Form Bodies */}
            {tab === 'upi' && (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Enter UPI ID (GPay / PhonePe / Paytm / BHIM)
                  </label>
                  <input
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    placeholder="yourname@okhdfcbank"
                    className="w-full p-3 rounded-xl border border-stone-300 text-stone-800 font-medium focus:outline-none focus:border-blue-600"
                    required
                  />
                </div>
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between text-[11px] text-stone-600">
                  <span>Fast UPI Auto-Verification</span>
                  <span className="font-bold text-[#2D5016]">Ready</span>
                </div>
              </div>
            )}

            {tab === 'card' && (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Card Number</label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    placeholder="16-digit card number"
                    className="w-full p-3 rounded-xl border border-stone-300 text-stone-800 font-medium focus:outline-none focus:border-blue-600"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">Valid Thru</label>
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      placeholder="MM/YY"
                      className="w-full p-3 rounded-xl border border-stone-300 text-stone-800 font-medium focus:outline-none focus:border-blue-600"
                      required
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">CVV</label>
                    <input
                      type="password"
                      maxLength={4}
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value)}
                      placeholder="•••"
                      className="w-full p-3 rounded-xl border border-stone-300 text-stone-800 font-medium focus:outline-none focus:border-blue-600"
                      required
                    />
                  </div>
                </div>
              </div>
            )}

            {tab === 'netbanking' && (
              <div className="space-y-3 text-xs">
                <label className="block font-bold text-stone-700">Select Bank</label>
                <div className="grid grid-cols-2 gap-2">
                  {['HDFC Bank', 'State Bank of India', 'ICICI Bank', 'Axis Bank'].map((bank) => (
                    <button
                      key={bank}
                      type="button"
                      onClick={() => setSelectedBank(bank)}
                      className={`p-2.5 rounded-xl border text-left font-semibold transition-all ${
                        selectedBank === bank
                          ? 'border-blue-600 bg-blue-50/50 text-blue-900'
                          : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                      }`}
                    >
                      {bank}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {tab === 'wallet' && (
              <div className="space-y-2 text-xs">
                <label className="block font-bold text-stone-700">Select Digital Wallet</label>
                {['Paytm Wallet', 'Amazon Pay', 'Mobikwik'].map((wallet) => (
                  <div
                    key={wallet}
                    className="p-3 rounded-xl border border-stone-200 flex items-center justify-between text-stone-800 font-medium"
                  >
                    <span>{wallet}</span>
                    <span className="text-[10px] text-stone-400">Linked</span>
                  </div>
                ))}
              </div>
            )}

            {/* Demo Notice */}
            <div className="bg-amber-50 p-2.5 rounded-xl border border-amber-200 text-[11px] text-amber-900 flex items-center justify-between">
              <span>Demo Mode — No real bank charges will occur.</span>
              <span className="font-bold">Test Sandbox</span>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-3 pt-1">
              <button
                type="button"
                onClick={onClose}
                disabled={isProcessing}
                className="flex-1 py-3.5 rounded-xl border border-stone-300 text-xs font-bold text-stone-700 hover:bg-stone-50 transition-colors"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={isProcessing}
                className="flex-2 py-3.5 rounded-xl bg-[#0c2340] hover:bg-[#07172b] text-white text-xs font-bold shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Processing Payment...</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3.5 h-3.5 text-blue-300" />
                    <span>Pay {formatPrice(amount)} Now</span>
                  </>
                )}
              </button>
            </div>

            <div className="flex items-center justify-center gap-1 text-[10px] text-stone-400 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>256-bit Encrypted • 100% Refundable according to Cancellation Policy</span>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
