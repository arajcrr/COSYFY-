import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, MessageCircle, ShieldCheck, CreditCard, Sparkles } from 'lucide-react';
import { Booking } from '../../types';
import { formatPrice, getWhatsAppUrl } from '../../utils';
import { useLanguage } from '../../context/LanguageContext';
import { LanguageSwitcher } from '../common/LanguageSwitcher';

interface SuccessScreenProps {
  booking: Booking;
}

export const SuccessScreen: React.FC<SuccessScreenProps> = ({ booking }) => {
  const { tagline } = useLanguage();
  const whatsappNum = import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210';
  const whatsappUrl = getWhatsAppUrl(
    whatsappNum,
    `Hi Cosyfy! My booking ${booking.bookingReference} for ${booking.propertyName} is confirmed. Can I get the host contact card?`
  );

  const isRemote = Boolean(booking.isRemoteProperty || booking.paymentStatus === 'full_paid');
  const paidAmount = booking.paymentAmount || (isRemote ? booking.totalPrice : booking.advanceDeposit);
  const remainingDue = isRemote ? 0 : Math.max(0, booking.totalPrice - paidAmount);

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4 sm:p-6">
      <div className="max-w-2xl w-full bg-white rounded-3xl p-6 sm:p-10 border border-stone-200 shadow-2xl text-center space-y-8 animate-in fade-in zoom-in-95">
        {/* Confirmed Icon */}
        <div className="w-20 h-20 rounded-full bg-emerald-100 text-[#2D5016] flex items-center justify-center mx-auto shadow-inner">
          <CheckCircle2 className="w-12 h-12 text-[#2D5016]" />
        </div>

        <div className="space-y-2">
          <span className="text-xs uppercase font-bold tracking-widest text-[#2D5016] bg-[#2D5016]/10 px-3.5 py-1.5 rounded-full inline-block">
            Reservation Confirmed!
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] font-display">
            Pack Your Bags for {booking.propertyName}!
          </h1>
          <p className="text-sm text-stone-600 max-w-md mx-auto">
            The host family has confirmed availability for your dates. We have dispatched full host address and check-in instructions to your WhatsApp.
          </p>

          {/* Regional Tagline & Indicator */}
          <div className="pt-2 space-y-1.5">
            <p className="text-xs font-semibold text-[#C84B31] font-serif italic max-w-md mx-auto">
              &ldquo;{tagline}&rdquo;
            </p>
            <div className="flex items-center justify-center gap-1.5 text-[11px] text-stone-400">
              <span>Language:</span>
              <LanguageSwitcher />
            </div>
          </div>
        </div>

        {/* Stay Summary Card */}
        <div className="bg-stone-50 rounded-2xl p-6 border border-stone-200 text-left space-y-4">
          <div className="flex justify-between items-start border-b border-stone-200 pb-3">
            <div>
              <span className="text-[10px] text-stone-400 font-mono block">BOOKING REFERENCE:</span>
              <span className="text-lg font-bold text-[#C84B31] font-mono">{booking.bookingReference}</span>
            </div>
            <div className="text-right">
              <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-emerald-100 text-[#2D5016] inline-block">
                Confirmed
              </span>
              {booking.paymentId && (
                <span className="block text-[10px] font-mono text-stone-400 mt-1">
                  Razorpay ID: {booking.paymentId}
                </span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-stone-400 block">Homestay</span>
              <strong className="text-stone-800">{booking.propertyName}</strong>
            </div>
            <div>
              <span className="text-stone-400 block">Location</span>
              <strong className="text-stone-800">{booking.propertyLocation}</strong>
            </div>
            <div>
              <span className="text-stone-400 block">Dates</span>
              <strong className="text-stone-800">
                {booking.checkIn} to {booking.checkOut} ({booking.nights} nights)
              </strong>
            </div>
            <div>
              <span className="text-stone-400 block">Guests</span>
              <strong className="text-stone-800">
                {booking.adults} Adults {booking.children > 0 ? `, ${booking.children} Kids` : ''}
              </strong>
            </div>
          </div>

          <div className="border-t border-stone-200 pt-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs">
            <div>
              <span className="text-stone-500">
                {isRemote ? 'Full Payment Paid (100%):' : 'Advance Deposit Paid (10%):'}
              </span>{' '}
              <strong className="text-[#2D5016] font-bold">{formatPrice(paidAmount)}</strong>
            </div>
            <div>
              <span className="text-stone-500">Remaining to Pay on Arrival:</span>{' '}
              <strong className="text-stone-900 font-bold">{formatPrice(remainingDue)}</strong>
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row justify-center gap-3">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-[#2D5016] hover:bg-[#1F380F] text-white font-bold text-sm shadow-md"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>Open WhatsApp Details</span>
          </a>

          <Link
            to="/my-bookings"
            className="inline-flex items-center justify-center px-6 py-3.5 rounded-full border border-stone-300 text-stone-700 font-semibold text-sm hover:bg-stone-50"
          >
            View in My Reservations
          </Link>
        </div>
      </div>
    </div>
  );
};
