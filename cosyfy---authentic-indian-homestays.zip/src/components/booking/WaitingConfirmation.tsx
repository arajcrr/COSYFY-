import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  CheckCircle2,
  Clock,
  MessageCircle,
  Home,
  RefreshCw,
  PhoneCall,
  Sparkles,
} from 'lucide-react';
import { Booking, Property } from '../../types';
import { getWhatsAppUrl, formatPrice } from '../../utils';
import { useLanguage } from '../../context/LanguageContext';

interface WaitingConfirmationProps {
  booking: Booking;
}

export const WaitingConfirmation: React.FC<WaitingConfirmationProps> = ({
  booking,
}) => {
  const { tagline } = useLanguage();
  const [secondsElapsed, setSecondsElapsed] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsElapsed((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const whatsappNum = import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210';
  const whatsappUrl = getWhatsAppUrl(
    whatsappNum,
    `Hi Cosyfy! I submitted booking request ${booking.bookingReference} for ${booking.propertyName}. Can you update me?`
  );

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4 sm:p-6">
      <div className="max-w-2xl w-full bg-white rounded-3xl p-6 sm:p-10 border border-stone-200/90 shadow-2xl text-center space-y-8 animate-in fade-in zoom-in-95">
        {/* Pulsing Animated House Icon */}
        <div className="relative inline-flex items-center justify-center">
          <div className="w-24 h-24 rounded-full bg-[#2D5016]/10 flex items-center justify-center animate-pulse">
            <Home className="w-12 h-12 text-[#2D5016]" />
          </div>
          <span className="absolute -top-1 -right-1 flex h-6 w-6">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#C84B31] opacity-75" />
            <span className="relative inline-flex rounded-full h-6 w-6 bg-[#C84B31] text-white text-[10px] font-bold items-center justify-center">
              ✓
            </span>
          </span>
        </div>

        {/* Reference Number */}
        <div className="space-y-2">
          <span className="text-xs uppercase font-bold tracking-widest text-[#2D5016] bg-[#2D5016]/10 px-3.5 py-1.5 rounded-full inline-block">
            Booking Request Submitted
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] font-display">
            Checking With Host Family
          </h1>
          <div className="inline-block bg-stone-100 px-4 py-2 rounded-xl border border-stone-200 mt-2">
            <span className="text-xs text-stone-500 font-mono block">YOUR REFERENCE CODE:</span>
            <span className="text-lg sm:text-xl font-extrabold tracking-widest text-[#C84B31] font-mono">
              {booking.bookingReference}
            </span>
          </div>
        </div>

        {/* Status Timeline Animation */}
        <div className="bg-stone-50 rounded-2xl p-6 border border-stone-200 text-left space-y-4">
          <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">
            Live Status Timeline
          </h4>

          {/* Step 1 */}
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-[#2D5016] text-white flex items-center justify-center text-xs shrink-0 mt-0.5">
              ✓
            </div>
            <div>
              <p className="text-xs font-bold text-stone-900">Request Received</p>
              <p className="text-[11px] text-stone-500">
                Your reservation details for {booking.propertyName} are recorded.
              </p>
            </div>
          </div>

          {/* Step 2 */}
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center text-xs shrink-0 mt-0.5 animate-spin">
              <RefreshCw className="w-3.5 h-3.5" />
            </div>
            <div>
              <p className="text-xs font-bold text-amber-900">
                Contacting Property Owner
              </p>
              <p className="text-[11px] text-stone-500">
                We are actively calling the host family in {booking.propertyLocation} to verify room availability.
              </p>
            </div>
          </div>

          {/* Step 3 */}
          <div className="flex items-start gap-3 opacity-60">
            <div className="w-6 h-6 rounded-full border-2 border-stone-300 flex items-center justify-center text-xs shrink-0 mt-0.5">
              3
            </div>
            <div>
              <p className="text-xs font-bold text-stone-700">Awaiting Confirmation</p>
              <p className="text-[11px] text-stone-500">
                Host confirms meal preferences and check-in preparation.
              </p>
            </div>
          </div>

          {/* Step 4 */}
          <div className="flex items-start gap-3 opacity-60">
            <div className="w-6 h-6 rounded-full border-2 border-stone-300 flex items-center justify-center text-xs shrink-0 mt-0.5">
              4
            </div>
            <div>
              <p className="text-xs font-bold text-stone-700">WhatsApp Update Coming</p>
              <p className="text-[11px] text-stone-500">
                Direct WhatsApp message to {booking.guestPhone} with payment link & host details.
              </p>
            </div>
          </div>
        </div>

        {/* Reassurance text */}
        <div className="space-y-1 max-w-lg mx-auto">
          <p className="text-sm text-stone-600 leading-relaxed">
            We’re checking availability with <strong className="text-stone-900">{booking.propertyName}</strong> right now. You’ll hear from us on WhatsApp at <strong className="text-[#2D5016]">{booking.guestPhone}</strong> within 2 hours.
          </p>
          <p className="text-xs font-semibold text-[#C84B31] font-serif italic pt-1">
            &ldquo;{tagline}&rdquo;
          </p>
        </div>

        {/* WhatsApp Direct Connect */}
        <div className="pt-2 flex flex-col sm:flex-row gap-3 justify-center">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-sm shadow-md transition-transform hover:scale-105"
          >
            <MessageCircle className="w-5 h-5 fill-white" />
            <span>Need Faster Update? WhatsApp Us</span>
          </a>

          <Link
            to="/properties"
            className="inline-flex items-center justify-center px-6 py-3.5 rounded-full border border-stone-300 text-stone-700 font-semibold text-sm hover:bg-stone-50"
          >
            Browse More Stays
          </Link>
        </div>
      </div>
    </div>
  );
};
