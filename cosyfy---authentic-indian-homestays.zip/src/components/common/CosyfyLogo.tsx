import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showTagline?: boolean;
  isNavbar?: boolean;
}

export const CosyfyLogo: React.FC<LogoProps> = ({
  className = '',
  size = 'md',
  showTagline = false,
  isNavbar = false,
}) => {
  const { tagline } = useLanguage();
  const [imageError, setImageError] = useState(false);

  // Logo URL from env var or default brand SVG asset
  const logoUrl = import.meta.env.VITE_LOGO_URL || '/cosyfy-logo.svg';

  // Determine sizing classes
  const navbarClasses = 'h-9 md:h-10 w-auto object-contain p-1 bg-white rounded-lg shadow-2xs transition-transform duration-300 group-hover:scale-102';
  
  const standardImageSizes = {
    sm: 'h-8 w-auto object-contain p-1 bg-white rounded-md shadow-2xs',
    md: 'h-11 w-auto object-contain p-1 bg-white rounded-lg shadow-2xs',
    lg: 'h-16 w-auto object-contain p-1 bg-white rounded-xl shadow-2xs',
  };

  return (
    <Link to="/" className={`inline-flex flex-col group ${className}`} aria-label="COSYFY Home">
      <div className="inline-flex items-center gap-2">
        {/* If image URL is configured or default brand image exists, render image */}
        {logoUrl && !imageError ? (
          <img
            src={logoUrl}
            alt="COSYFY Logo"
            className={isNavbar ? navbarClasses : standardImageSizes[size]}
            onError={() => setImageError(true)}
          />
        ) : (
          /* SVG Logo Fallback */
          <div className="inline-flex items-center gap-2 p-1 bg-white rounded-lg">
            <div className="relative flex items-center justify-center">
              <svg
                className="w-7 h-7 text-[#2D5016] transition-transform duration-300 group-hover:scale-105"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                <path d="M9 21v-6a3 3 0 0 1 6 0v6" />
              </svg>
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-[#C84B31] animate-pulse" />
            </div>

            <div className="flex items-baseline tracking-tight">
              <span className="text-xl md:text-2xl font-bold tracking-wider text-[#2D5016] font-display">
                COSYFY
              </span>
              <span className="text-xl md:text-2xl font-extrabold text-[#C84B31]">
                .in
              </span>
            </div>
          </div>
        )}
      </div>

      {showTagline && (
        <span className="text-[11px] text-[#2D5016]/90 font-medium tracking-normal mt-1 italic">
          {tagline}
        </span>
      )}
    </Link>
  );
};
