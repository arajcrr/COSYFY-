import React from 'react';
import { MessageCircle } from 'lucide-react';
import { getWhatsAppUrl } from '../../utils';

export const FloatingWhatsApp: React.FC = () => {
  const whatsappNum = import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210';
  const url = getWhatsAppUrl(
    whatsappNum,
    "Namaste Cosyfy team! I'm looking for an authentic homestay in India. Can you help me find one?"
  );

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with Cosyfy on WhatsApp"
      className="fixed bottom-20 md:bottom-8 right-5 z-40 flex items-center gap-2.5 px-4 py-3 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-full shadow-xl transition-all duration-300 hover:scale-105 group border-2 border-white"
    >
      <div className="relative">
        <MessageCircle className="w-6 h-6 fill-white text-[#25D366]" />
        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#C84B31] rounded-full animate-ping" />
        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#C84B31] rounded-full" />
      </div>
      <div className="hidden sm:flex flex-col text-left leading-none">
        <span className="text-[11px] opacity-90">Quick WhatsApp</span>
        <span className="text-xs font-bold tracking-wide">Reply in ~2 hrs</span>
      </div>
    </a>
  );
};
