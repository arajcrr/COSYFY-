import React from 'react';
import { Link } from 'react-router-dom';
import { MessageCircle, ShieldCheck, Heart, Sparkles, ArrowRight } from 'lucide-react';
import { CosyfyLogo } from './CosyfyLogo';
import { LanguageSwitcher } from './LanguageSwitcher';
import { useLanguage } from '../../context/LanguageContext';
import { getWhatsAppUrl } from '../../utils';

export const Footer: React.FC = () => {
  const { tagline } = useLanguage();
  const whatsappNum = import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210';
  const whatsappUrl = getWhatsAppUrl(
    whatsappNum,
    'Namaste! I would like to enquire about homestays on Cosyfy.'
  );

  return (
    <footer className="bg-[#1A1A1A] text-stone-300 pt-16 pb-24 md:pb-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Banner inside Footer */}
        <div className="bg-[#2D5016]/80 rounded-2xl p-6 sm:p-8 mb-12 border border-[#2D5016] flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-950/80 text-emerald-300 mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Real Humans, Zero Service Fees</span>
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-white font-display">
              Unsure which homestay fits your journey?
            </h3>
            <p className="text-sm text-emerald-100/90 mt-1">
              Drop us a WhatsApp message. Our Kullu and Bangalore team will personally match you within 2 hours.
            </p>
          </div>
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="shrink-0 inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-[#C84B31] hover:bg-[#AF3E25] text-white font-semibold text-sm shadow-lg transition-transform hover:scale-105"
          >
            <MessageCircle className="w-5 h-5 fill-white" />
            <span>Chat on WhatsApp (7am - 10pm)</span>
          </a>
        </div>

        {/* 4 Column Links */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 lg:gap-12 mb-12">
          {/* Brand Col */}
          <div className="col-span-2 space-y-4">
            <div className="bg-white/10 p-3 rounded-2xl inline-block">
              <CosyfyLogo size="md" />
            </div>
            <p className="text-sm text-stone-400 max-w-sm leading-relaxed">
              &ldquo;{tagline}&rdquo;
              <br />
              Personally verified homestays across India with homecooked meals, authentic local hosts, and zero platform service fees.
            </p>
            <div className="flex items-center gap-2 text-xs text-stone-400">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Every property ID and address inspected</span>
            </div>
          </div>

          {/* Stays Col */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Explore Stays
            </h4>
            <ul className="space-y-2.5 text-xs text-stone-400">
              <li>
                <Link to="/properties?region=Hills" className="hover:text-white transition-colors">
                  Himalayan Orchard Stays
                </Link>
              </li>
              <li>
                <Link to="/properties?destination=Kasol" className="hover:text-white transition-colors">
                  Parvati Valley Cottages
                </Link>
              </li>
              <li>
                <Link to="/properties?destination=Coorg" className="hover:text-white transition-colors">
                  Coorg Coffee Plantations
                </Link>
              </li>
              <li>
                <Link to="/properties?destination=Goa" className="hover:text-white transition-colors">
                  Old Portuguese Mansions
                </Link>
              </li>
              <li>
                <Link to="/work-from-mountains" className="hover:text-white transition-colors text-amber-400 font-medium">
                  Work From Mountains
                </Link>
              </li>
              <li>
                <Link to="/properties" className="hover:text-white transition-colors">
                  All Homestays
                </Link>
              </li>
            </ul>
          </div>

          {/* Company Col */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Company
            </h4>
            <ul className="space-y-2.5 text-xs text-stone-400">
              <li>
                <Link to="/about" className="hover:text-white transition-colors">
                  About Cosyfy
                </Link>
              </li>
              <li>
                <Link to="/about#founder-story" className="hover:text-white transition-colors">
                  Why We Built This
                </Link>
              </li>
              <li>
                <Link to="/about#verification" className="hover:text-white transition-colors">
                  5-Step Verification
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-white transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Support & Legal Col */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Support & Host
            </h4>
            <ul className="space-y-2.5 text-xs text-stone-400">
              <li>
                <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                  WhatsApp Support (2h reply)
                </a>
              </li>
              <li>
                <Link to="/work-from-mountains#faq" className="hover:text-white transition-colors">
                  Guest FAQs
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-white transition-colors">
                  Host Your Homestay
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Dedicated Homestay Owner Banner */}
        <div className="my-10 p-6 sm:p-8 rounded-3xl bg-[#1f380f]/70 border border-emerald-800/60 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-900/80 border border-emerald-700/60 text-emerald-300 text-xs font-bold">
              <span>🏡 Are you a homestay owner?</span>
            </div>
            <h3 className="text-lg sm:text-xl font-bold font-display text-white">
              List your property on Cosyfy for free.
            </h3>
            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
              Pay only when you get confirmed bookings.
              <br className="hidden sm:inline" />
              <span className="text-emerald-400 font-semibold"> No upfront fees. No monthly charges. Just bookings.</span>
            </p>
          </div>
          <Link
            to="/list-your-property"
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-white text-[#2D5016] font-bold text-xs sm:text-sm shadow-md hover:bg-emerald-50 transition-all hover:scale-[1.02] shrink-0"
          >
            <span>List Your Property Free →</span>
          </Link>
        </div>

        {/* Bottom Copyright */}
        <div className="pt-8 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <p>© 2024 COSYFY (cosyfy.in). Authentic Indian Homestay Platform. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-stone-400">Language:</span>
              <LanguageSwitcher />
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
