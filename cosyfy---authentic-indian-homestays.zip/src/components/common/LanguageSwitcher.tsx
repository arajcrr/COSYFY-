import React, { useState, useRef, useEffect } from 'react';
import { Globe, ChevronDown, Check, Sparkles } from 'lucide-react';
import { useLanguage, LANGUAGE_LABELS } from '../../context/LanguageContext';

export const LanguageSwitcher: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { currentLang, detectedLang, isManuallySelected, setLanguage, resetToDetected } = useLanguage();
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const currentLabel = LANGUAGE_LABELS[currentLang] || LANGUAGE_LABELS.default;

  return (
    <div ref={menuRef} className="relative inline-block text-left z-30">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold text-stone-700 bg-stone-100/90 hover:bg-stone-200/80 transition-colors border border-stone-200/80 shadow-2xs"
        title="Change Regional Language"
      >
        <Globe className="w-3.5 h-3.5 text-[#2D5016]" />
        <span>{currentLabel.nativeName}</span>
        <span className="text-[10px] text-stone-400 font-normal">
          ({currentLabel.name})
        </span>
        <ChevronDown className="w-3 h-3 text-stone-400" />
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-stone-200 py-2.5 z-50 animate-in fade-in slide-in-from-top-2">
          <div className="px-3.5 py-1.5 border-b border-stone-100">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-stone-900 uppercase tracking-wider">
                Regional Tagline
              </span>
              <span className="text-[10px] bg-emerald-50 text-[#2D5016] px-1.5 py-0.5 rounded font-bold">
                {isManuallySelected ? 'Custom' : 'Auto-detected'}
              </span>
            </div>
            <p className="text-[11px] text-stone-500 mt-0.5">
              Detected: {LANGUAGE_LABELS[detectedLang]?.name}
            </p>
          </div>

          <div className="max-h-60 overflow-y-auto py-1 divide-y divide-stone-50">
            {Object.entries(LANGUAGE_LABELS).map(([code, label]) => {
              const active = currentLang === code;
              return (
                <button
                  key={code}
                  type="button"
                  onClick={() => {
                    setLanguage(code);
                    setOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3.5 py-2 text-xs text-left transition-colors ${
                    active ? 'bg-[#2D5016]/10 text-[#2D5016] font-bold' : 'text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  <div>
                    <span className="font-semibold">{label.nativeName}</span>
                    <span className="text-stone-400 text-[11px] ml-1.5">({label.name})</span>
                  </div>
                  {active && <Check className="w-4 h-4 text-[#2D5016]" />}
                </button>
              );
            })}
          </div>

          {isManuallySelected && (
            <div className="px-3.5 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => {
                  resetToDetected();
                  setOpen(false);
                }}
                className="text-[11px] text-[#C84B31] font-semibold hover:underline"
              >
                Reset to browser auto-detect
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
