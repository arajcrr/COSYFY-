import React from 'react';

export const PropertyCardSkeleton: React.FC = () => {
  return (
    <div className="bg-white rounded-2xl overflow-hidden border border-stone-200/80 shadow-sm animate-pulse flex flex-col">
      <div className="aspect-[4/3] bg-stone-200 w-full" />
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <div className="space-y-2">
          <div className="h-4 bg-stone-200 rounded w-1/3" />
          <div className="h-6 bg-stone-200 rounded w-4/5" />
          <div className="h-3 bg-stone-200 rounded w-2/3" />
        </div>
        <div className="flex gap-2">
          <div className="h-6 w-16 bg-stone-100 rounded-md" />
          <div className="h-6 w-16 bg-stone-100 rounded-md" />
          <div className="h-6 w-16 bg-stone-100 rounded-md" />
        </div>
        <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
          <div className="h-6 w-24 bg-stone-200 rounded" />
          <div className="h-9 w-28 bg-stone-200 rounded-xl" />
        </div>
      </div>
    </div>
  );
};

export const PropertyGridSkeleton: React.FC<{ count?: number }> = ({ count = 6 }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array.from({ length: count }).map((_, i) => (
        <PropertyCardSkeleton key={i} />
      ))}
    </div>
  );
};
