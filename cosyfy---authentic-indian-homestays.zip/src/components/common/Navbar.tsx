import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Menu,
  X,
  MessageCircle,
  User as UserIcon,
  Heart,
  Calendar,
  LogOut,
  Shield,
  ChevronDown,
} from 'lucide-react';
import { CosyfyLogo } from './CosyfyLogo';
import { LanguageSwitcher } from './LanguageSwitcher';
import { useAuth } from '../../context/AuthContext';
import { getWhatsAppUrl } from '../../utils';

export const Navbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const { user, profile, isAdmin, savedPropertyIds, logout } = useAuth();
  const location = useLocation();

  const whatsappNum = import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210';
  const whatsappUrl = getWhatsAppUrl(
    whatsappNum,
    "Namaste Cosyfy team! I'm planning a homestay trip in India and need assistance."
  );

  const navLinks = [
    { label: 'All Stays', href: '/properties' },
    { label: 'Work From Mountains', href: '/work-from-mountains', badge: 'Popular' },
    { label: 'About', href: '/about' },
    { label: 'Contact', href: '/contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="sticky top-0 z-50 bg-[#FAF7F2]/95 backdrop-blur-md border-b border-stone-200/80 transition-all">
      {/* Top micro banner */}
      <div className="bg-[#2D5016] text-[#FAF7F2] text-xs py-1.5 px-4 text-center font-medium flex items-center justify-center gap-2">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
        <span>100% Personally Verified Indian Homestays • Zero Hidden Service Fees</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo Left */}
          <div className="shrink-0 flex items-center">
            <CosyfyLogo isNavbar={true} />
          </div>

          {/* Navigation Center (Desktop) */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={`relative px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isActive(link.href)
                    ? 'text-[#2D5016] bg-[#2D5016]/10 font-semibold'
                    : 'text-stone-700 hover:text-[#2D5016] hover:bg-stone-200/40'
                }`}
              >
                <span>{link.label}</span>
                {link.badge && (
                  <span className="ml-1.5 px-1.5 py-0.5 text-[10px] uppercase font-bold tracking-wider bg-[#C84B31] text-white rounded-full">
                    {link.badge}
                  </span>
                )}
              </Link>
            ))}
          </nav>

          {/* Right Action Buttons */}
          <div className="hidden md:flex items-center space-x-3">
            {/* Regional Language Switcher */}
            <LanguageSwitcher />

            {/* Wishlist Icon */}
            <Link
              to="/saved"
              aria-label="Wishlist"
              className="relative p-2.5 rounded-full text-stone-700 hover:text-[#C84B31] hover:bg-stone-200/50 transition-colors"
            >
              <Heart className="w-5 h-5" />
              {savedPropertyIds.length > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-[#C84B31] text-white text-[10px] font-bold flex items-center justify-center">
                  {savedPropertyIds.length}
                </span>
              )}
            </Link>

            {/* List Your Property Free Link in Forest Green */}
            <Link
              to="/list-your-property"
              className="text-[#2D5016] hover:text-[#1e380f] font-bold text-xs lg:text-sm px-2.5 py-1.5 rounded-lg hover:bg-emerald-50 transition-colors inline-flex items-center gap-1.5"
            >
              <span>List Your Property</span>
              <span className="px-1.5 py-0.2 rounded bg-emerald-100 text-[#2D5016] text-[10px] font-bold">
                Free
              </span>
            </Link>

            {/* WhatsApp CTA Button in Terracotta Orange */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full text-xs font-semibold bg-[#C84B31] hover:bg-[#AF3E25] text-white shadow-sm transition-all duration-200 hover:shadow-md"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>WhatsApp Us</span>
            </a>

            {/* User Account / Profile Menu */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 pr-2.5 rounded-full border border-stone-300 hover:border-[#2D5016] transition-all bg-white shadow-sm"
                >
                  <div className="w-8 h-8 rounded-full bg-[#2D5016] text-white flex items-center justify-center font-bold text-xs uppercase">
                    {profile?.fullName ? profile.fullName.charAt(0) : 'U'}
                  </div>
                  <span className="text-xs font-semibold text-stone-800 max-w-[100px] truncate">
                    {profile?.fullName?.split(' ')[0] || 'My Account'}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-stone-500" />
                </button>

                {/* Dropdown popup */}
                {userDropdownOpen && (
                  <div
                    className="absolute right-0 mt-2 w-56 rounded-2xl bg-white shadow-xl border border-stone-200 py-2 z-50 animate-in fade-in slide-in-from-top-2"
                    onMouseLeave={() => setUserDropdownOpen(false)}
                  >
                    <div className="px-4 py-2 border-b border-stone-100">
                      <p className="text-xs font-semibold text-stone-900 truncate">
                        {profile?.fullName || 'Cosyfy Guest'}
                      </p>
                      <p className="text-[11px] text-stone-500 truncate">{user.email}</p>
                    </div>

                    <Link
                      to="/profile"
                      onClick={() => setUserDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2 text-xs text-stone-700 hover:bg-stone-50 hover:text-[#2D5016]"
                    >
                      <UserIcon className="w-4 h-4" />
                      <span>My Profile</span>
                    </Link>

                    <Link
                      to="/my-bookings"
                      onClick={() => setUserDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2 text-xs text-stone-700 hover:bg-stone-50 hover:text-[#2D5016]"
                    >
                      <Calendar className="w-4 h-4" />
                      <span>My Reservations</span>
                    </Link>

                    <Link
                      to="/saved"
                      onClick={() => setUserDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2 text-xs text-stone-700 hover:bg-stone-50 hover:text-[#2D5016]"
                    >
                      <Heart className="w-4 h-4 text-[#C84B31]" />
                      <span>Wishlist ({savedPropertyIds.length})</span>
                    </Link>

                    <div className="border-t border-stone-100 mt-1 pt-1">
                      <button
                        onClick={() => {
                          setUserDropdownOpen(false);
                          logout();
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-rose-600 hover:bg-rose-50 font-medium"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Log Out</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Link
                  to="/login"
                  className="px-3 py-2 text-xs font-semibold text-stone-700 hover:text-[#2D5016]"
                >
                  Log In
                </Link>
                <Link
                  to="/signup"
                  className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-[#2D5016] text-white hover:bg-[#1F380F] shadow-sm transition-colors"
                >
                  Sign Up
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex md:hidden items-center space-x-2">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="WhatsApp"
              className="p-2 text-white bg-[#C84B31] rounded-full"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-stone-700 hover:text-[#2D5016] hover:bg-stone-200/50"
              aria-label="Open navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#FAF7F2] border-b border-stone-300 px-4 pt-2 pb-6 space-y-3 animate-in fade-in slide-in-from-top-4">
          <div className="flex flex-col space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium ${
                  isActive(link.href)
                    ? 'bg-[#2D5016] text-white'
                    : 'text-stone-800 hover:bg-stone-200/60'
                }`}
              >
                <span>{link.label}</span>
                {link.badge && (
                  <span className="px-2 py-0.5 text-[10px] bg-[#C84B31] text-white rounded-full">
                    {link.badge}
                  </span>
                )}
              </Link>
            ))}
            <Link
              to="/list-your-property"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-bold text-[#2D5016] bg-emerald-50 border border-emerald-200 hover:bg-emerald-100 transition-colors"
            >
              <div className="flex items-center gap-2">
                <span>🏡 List Your Property Free</span>
              </div>
              <span className="px-2 py-0.5 text-[10px] bg-[#2D5016] text-white rounded-full font-bold">
                Join Hosts
              </span>
            </Link>
          </div>

          <div className="pt-3 border-t border-stone-200 flex items-center justify-between px-2">
            <span className="text-xs font-semibold text-stone-600">Language:</span>
            <LanguageSwitcher />
          </div>

          <div className="pt-2 border-t border-stone-200 flex flex-col space-y-2">
            {user ? (
              <>
                <div className="px-3 py-1">
                  <p className="text-xs font-bold text-stone-900">{profile?.fullName}</p>
                  <p className="text-[11px] text-stone-500">{user.email}</p>
                </div>
                <Link
                  to="/profile"
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2 text-sm text-stone-700 flex items-center gap-2"
                >
                  <UserIcon className="w-4 h-4" /> My Profile
                </Link>
                <Link
                  to="/my-bookings"
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2 text-sm text-stone-700 flex items-center gap-2"
                >
                  <Calendar className="w-4 h-4" /> My Reservations
                </Link>
                <Link
                  to="/saved"
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2 text-sm text-stone-700 flex items-center gap-2"
                >
                  <Heart className="w-4 h-4 text-[#C84B31]" /> Saved Stays ({savedPropertyIds.length})
                </Link>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    logout();
                  }}
                  className="px-3 py-2 text-sm text-rose-600 font-semibold flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4" /> Log Out
                </button>
              </>
            ) : (
              <div className="grid grid-cols-2 gap-2 pt-2">
                <Link
                  to="/login"
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-4 py-2.5 text-center text-xs font-semibold rounded-xl border border-stone-300 text-stone-800 bg-white"
                >
                  Log In
                </Link>
                <Link
                  to="/signup"
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-4 py-2.5 text-center text-xs font-semibold rounded-xl bg-[#2D5016] text-white"
                >
                  Sign Up
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
