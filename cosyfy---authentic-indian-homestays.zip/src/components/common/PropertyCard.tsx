import React from 'react';
import { Link } from 'react-router-dom';
import {
  MapPin,
  Star,
  ShieldCheck,
  Video,
  Wifi,
  Coffee,
  Mountain,
  Users,
  Heart,
  Flame,
  Briefcase,
} from 'lucide-react';
import { Property, Amenity } from '../../types';
import { formatPrice } from '../../utils';
import { useAuth } from '../../context/AuthContext';

interface PropertyCardProps {
  property: Property;
  showWfmHighlight?: boolean;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ property, showWfmHighlight = false }) => {
  const { isSaved, toggleSaveProperty } = useAuth();
  const saved = isSaved(property.id);

  // Map amenities to icons
  const renderAmenityIcon = (amenity: Amenity) => {
    switch (amenity) {
      case 'WiFi':
        return <Wifi key={amenity} className="w-3.5 h-3.5 text-stone-600" />;
      case 'Meals':
        return <Coffee key={amenity} className="w-3.5 h-3.5 text-stone-600" />;
      case 'Mountain View':
        return <Mountain key={amenity} className="w-3.5 h-3.5 text-stone-600" />;
      case 'Bonfire':
        return <Flame key={amenity} className="w-3.5 h-3.5 text-stone-600" />;
      case 'Work Desk':
        return <Briefcase key={amenity} className="w-3.5 h-3.5 text-stone-600" />;
      default:
        return null;
    }
  };

  return (
    <div className="group bg-white rounded-2xl overflow-hidden border border-stone-200/90 shadow-sm hover:shadow-xl hover:border-[#2D5016]/30 transition-all duration-300 flex flex-col relative">
      {/* Image Container */}
      <div className="relative aspect-[4/3] overflow-hidden bg-stone-100">
        <img
          src={property.mainImage}
          alt={property.name}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 pointer-events-none" />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2 z-10">
          <div className="flex flex-wrap items-center gap-1.5">
            {/* Cosyfy Verified Badge */}
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-[#2D5016] text-white shadow-md backdrop-blur-md">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
              <span>Cosyfy Verified</span>
            </span>

            {/* Video Tour Badge */}
            {property.videoUrl && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-black/70 text-white backdrop-blur-md">
                <Video className="w-3 h-3 text-red-400" />
                <span>Video Tour</span>
              </span>
            )}

            {/* Not on Airbnb Exclusive Badge */}
            {property.notOnAirbnb && (
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#C84B31] text-white shadow-sm">
                Cosyfy Exclusive
              </span>
            )}
          </div>

          {/* Wishlist Heart Button */}
          <button
            onClick={(e) => {
              e.preventDefault();
              toggleSaveProperty(property.id);
            }}
            aria-label={saved ? 'Remove from wishlist' : 'Add to wishlist'}
            className="w-8 h-8 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center text-stone-700 hover:text-[#C84B31] hover:scale-110 transition-transform shadow-md"
          >
            <Heart className={`w-4 h-4 ${saved ? 'fill-[#C84B31] text-[#C84B31]' : ''}`} />
          </button>
        </div>

        {/* WFM Speed Highlight on Image */}
        {showWfmHighlight && property.wfhReady && (
          <div className="absolute bottom-3 left-3 z-10">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium bg-black/80 text-emerald-400 backdrop-blur-md border border-emerald-500/30">
              <Wifi className="w-3.5 h-3.5" />
              <span>{property.wifiSpeedMbps} Mbps Tested Speed</span>
            </span>
          </div>
        )}

        {/* Rating Floating Bottom Right */}
        <div className="absolute bottom-3 right-3 z-10 flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/95 text-xs font-bold text-stone-900 shadow-sm backdrop-blur-md">
          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
          <span>{property.rating.toFixed(1)}</span>
          <span className="text-stone-400 font-normal">({property.reviewCount})</span>
        </div>
      </div>

      {/* Details Container */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <div>
          {/* Location & Guest Capacity */}
          <div className="flex items-center justify-between text-xs text-stone-500 mb-1.5">
            <div className="flex items-center gap-1 font-medium text-[#2D5016]">
              <MapPin className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate max-w-[180px]">{property.location}</span>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <Users className="w-3.5 h-3.5" />
              <span>Max {property.maxGuests} guests</span>
            </div>
          </div>

          {/* Property Name */}
          <h3 className="text-lg font-bold text-[#1A1A1A] group-hover:text-[#2D5016] transition-colors leading-snug font-display line-clamp-1">
            <Link to={`/property/${property.id}`} className="hover:underline">
              {property.name}
            </Link>
          </h3>

          {/* Tagline */}
          <p className="text-xs text-stone-600 line-clamp-2 mt-1 leading-relaxed">
            {property.tagline || property.description}
          </p>

          {/* Key Amenities */}
          <div className="flex items-center gap-2.5 mt-3 pt-3 border-t border-stone-100">
            {property.amenities.slice(0, 4).map((amenity) => (
              <span
                key={amenity}
                className="inline-flex items-center gap-1 text-[11px] font-medium text-stone-600 bg-stone-100/80 px-2 py-0.5 rounded-md"
              >
                {renderAmenityIcon(amenity)}
                <span className="hidden sm:inline">{amenity}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Pricing & CTA */}
        <div className="pt-3 border-t border-stone-100 flex items-center justify-between gap-2">
          <div>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-extrabold text-[#1A1A1A]">
                {formatPrice(property.weekdayPrice)}
              </span>
              <span className="text-xs text-stone-500">/night</span>
            </div>
            {property.weekendPrice !== property.weekdayPrice && (
              <span className="text-[10px] text-stone-400 block">
                {formatPrice(property.weekendPrice)} on weekends
              </span>
            )}
          </div>

          <Link
            to={`/property/${property.id}`}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-[#2D5016] text-white hover:bg-[#1F380F] shadow-sm transition-all duration-200 group-hover:scale-[1.02] text-center"
          >
            View Details
          </Link>
        </div>
      </div>
    </div>
  );
};
