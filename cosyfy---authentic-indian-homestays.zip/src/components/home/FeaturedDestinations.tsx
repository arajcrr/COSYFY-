import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { POPULAR_DESTINATIONS } from '../../data/staticData';

export const FeaturedDestinations: React.FC = () => {
  return (
    <section className="py-20 bg-stone-100/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <span className="text-xs uppercase font-bold tracking-widest text-[#2D5016] bg-[#2D5016]/10 px-3 py-1 rounded-full">
            Regions We Love
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#1A1A1A] font-display">
            Explore By Destination
          </h2>
          <p className="text-base text-stone-600">
            Every region in India has distinct architecture, indigenous recipes, and family customs waiting to be shared.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {POPULAR_DESTINATIONS.map((dest) => (
            <Link
              key={dest.name}
              to={`/properties?destination=${encodeURIComponent(dest.name)}`}
              className="group relative h-64 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-end p-4 hover:-translate-y-1"
            >
              {/* Image */}
              <img
                src={dest.image}
                alt={dest.name}
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              {/* Gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

              {/* Text */}
              <div className="relative z-10 text-white space-y-0.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold font-display group-hover:text-amber-200 transition-colors">
                    {dest.name}
                  </h3>
                  <div className="w-6 h-6 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:bg-[#C84B31] transition-colors">
                    <ArrowUpRight className="w-3.5 h-3.5 text-white" />
                  </div>
                </div>
                <p className="text-[11px] text-stone-300 line-clamp-1">{dest.state}</p>
                <p className="text-[10px] text-emerald-300 font-semibold">{dest.count}+ Verified Stays</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};
