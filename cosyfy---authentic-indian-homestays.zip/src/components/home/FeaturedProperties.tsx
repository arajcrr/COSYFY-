import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Property } from '../../types';
import { PropertyCard } from '../common/PropertyCard';
import { PropertyGridSkeleton } from '../common/LoadingSkeleton';

interface FeaturedPropertiesProps {
  properties: Property[];
  loading?: boolean;
}

export const FeaturedProperties: React.FC<FeaturedPropertiesProps> = ({ properties, loading }) => {
  const featuredList = properties.filter((p) => p.featured).slice(0, 6);

  return (
    <section className="py-20 bg-[#FAF7F2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 gap-4">
          <div className="space-y-2">
            <span className="inline-flex items-center gap-1.5 text-xs uppercase font-bold tracking-widest text-[#2D5016] bg-[#2D5016]/10 px-3 py-1 rounded-full">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Handpicked Homestays</span>
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#1A1A1A] font-display">
              Featured Stays Across India
            </h2>
            <p className="text-sm sm:text-base text-stone-600 max-w-xl">
              From apple orchards in Naggar to 140-year-old Goan village manors. Inspected for clean bathrooms, warmth, and quietude.
            </p>
          </div>

          <Link
            to="/properties"
            className="inline-flex items-center gap-2 text-sm font-bold text-[#2D5016] hover:text-[#1F380F] group"
          >
            <span>View All Homestays ({properties.length})</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>

        {loading ? (
          <PropertyGridSkeleton count={6} />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredList.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
