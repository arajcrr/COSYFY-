import React from 'react';
import { MessageCircle, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';
import { getWhatsAppUrl } from '../../utils';

import { useLanguage } from '../../context/LanguageContext';
import { LanguageSwitcher } from '../common/LanguageSwitcher';

interface HeroSectionProps {
  onExploreClick?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onExploreClick }) => {
  const { tagline } = useLanguage();
  const whatsappNum = import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210';
  const whatsappUrl = getWhatsAppUrl(
    whatsappNum,
    'Namaste Cosyfy! I want to find a peaceful homestay with homecooked food.'
  );

  return (
    <section className="relative min-h-[82vh] lg:min-h-[88vh] flex items-center justify-center overflow-hidden">
      {/* Background Hero Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=2000&q=85"
          alt="Himalayan Valley Homestay Sunrise"
          className="w-full h-full object-cover object-center scale-105 transition-transform duration-1000 ease-out"
        />
        {/* Dark warm overlay with gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/65 via-black/50 to-black/80" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center text-white space-y-6">
        {/* Top Tag */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/15 backdrop-blur-md border border-white/25 text-xs sm:text-sm font-medium tracking-wide animate-in fade-in slide-in-from-bottom-2">
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>India’s Most Personal Homestay Booking Experience</span>
          <span className="hidden sm:inline text-white/60">•</span>
          <span className="hidden sm:inline text-emerald-300 font-semibold">Zero Hidden Fees</span>
        </div>

        {/* Main Heading */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-white font-display leading-[1.12]">
          Stay with local families, <br className="hidden sm:inline" />
          <span className="italic font-normal text-amber-200">savor homecooked meals.</span>
        </h1>

        {/* Subheading */}
        <p className="max-w-2xl mx-auto text-base sm:text-xl text-stone-200 font-normal leading-relaxed">
          Personally verified homestays across Himachal, Uttarakhand, Coorg & Goa.
          <br className="hidden sm:inline" />
          Zero service fees. Always.{' '}
          <span className="text-amber-300 font-medium font-serif italic">"{tagline}"</span>
        </p>

        {/* Subtle regional language indicator & switcher */}
        <div className="flex items-center justify-center gap-2 pt-1">
          <div className="bg-black/40 backdrop-blur-md px-3 py-1 rounded-full border border-white/15 flex items-center gap-2">
            <span className="text-[11px] text-stone-300">Regional tagline:</span>
            <LanguageSwitcher />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto">
          <button
            onClick={() => {
              if (onExploreClick) {
                onExploreClick();
              } else {
                const el = document.getElementById('search-and-properties');
                el?.scrollIntoView({ behavior: 'smooth' });
              }
            }}
            className="w-full sm:w-auto px-8 py-4 rounded-full bg-[#FAF7F2] text-[#2D5016] hover:bg-white font-bold text-sm sm:text-base shadow-xl hover:shadow-2xl transition-all duration-200 hover:scale-105 flex items-center justify-center gap-2 group cursor-pointer"
          >
            <span>Explore Stays</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </button>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto px-8 py-4 rounded-full bg-[#C84B31] hover:bg-[#AF3E25] text-white font-bold text-sm sm:text-base shadow-xl hover:shadow-2xl transition-all duration-200 hover:scale-105 flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-5 h-5 fill-white" />
            <span>Chat With Us</span>
          </a>
        </div>

        {/* Trust Badges */}
        <div className="pt-8 flex flex-wrap items-center justify-center gap-6 text-xs text-stone-300">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>ID & Address Verified</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Direct WhatsApp Host Connect</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span>Fast Hindi & English Support</span>
          </div>
        </div>
      </div>
    </section>
  );
};
