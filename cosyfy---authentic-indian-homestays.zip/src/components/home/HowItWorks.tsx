import React from 'react';
import { MessageSquare, Search, Home } from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'Tell Us Your Dream',
      desc: 'Send a message with your dates, destination, and who is traveling. Whether you want snow peaks, apple orchards, or river banks, we take notes.',
      icon: MessageSquare,
      color: 'bg-emerald-100 text-[#2D5016]',
    },
    {
      num: '02',
      title: 'We Match & Verify',
      desc: 'We speak directly with our host families on WhatsApp to confirm room readiness, verified WiFi, and meal options. No double bookings ever.',
      icon: Search,
      color: 'bg-amber-100 text-amber-800',
    },
    {
      num: '03',
      title: 'Just Show Up',
      desc: 'Arrive to fresh cardamom chai, hot homecooked meals, and real conversations. Lock your stay with a small 10% advance deposit with zero platform fee.',
      icon: Home,
      color: 'bg-orange-100 text-[#C84B31]',
    },
  ];

  return (
    <section className="py-20 bg-[#FAF7F2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-xs uppercase font-bold tracking-widest text-[#2D5016] bg-[#2D5016]/10 px-3 py-1 rounded-full">
            Simple 3-Step Journey
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#1A1A1A] font-display">
            How Cosyfy Works
          </h2>
          <p className="text-base text-stone-600">
            Booking an authentic Indian homestay should be as personal as staying with an old college friend.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {/* Connector line for desktop */}
          <div className="hidden md:block absolute top-1/3 left-1/6 right-1/6 h-0.5 border-t-2 border-dashed border-stone-300 -z-0" />

          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div
                key={step.num}
                className="relative z-10 bg-white rounded-3xl p-8 border border-stone-200/90 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col items-center text-center group hover:-translate-y-1"
              >
                <div className="absolute -top-4 px-3 py-1 rounded-full bg-[#1A1A1A] text-white text-xs font-bold font-mono">
                  STEP {step.num}
                </div>

                <div
                  className={`w-16 h-16 rounded-2xl ${step.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}
                >
                  <Icon className="w-8 h-8" />
                </div>

                <h3 className="text-xl font-bold text-[#1A1A1A] mb-3 font-display">
                  {step.title}
                </h3>
                <p className="text-sm text-stone-600 leading-relaxed">
                  {step.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
