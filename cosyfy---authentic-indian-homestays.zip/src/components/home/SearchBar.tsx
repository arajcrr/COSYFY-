import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, MapPin, Calendar, Users, ChevronDown, Plus, Minus } from 'lucide-react';
import { format, addDays } from 'date-fns';
import { POPULAR_DESTINATIONS } from '../../data/staticData';

interface SearchBarProps {
  initialDestination?: string;
  onSearch?: (params: { destination: string; checkIn: string; checkOut: string; guests: number }) => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({ initialDestination = '', onSearch }) => {
  const navigate = useNavigate();
  const [destination, setDestination] = useState(initialDestination);
  const [showDestSuggestions, setShowDestSuggestions] = useState(false);
  const [checkIn, setCheckIn] = useState<string>(format(addDays(new Date(), 2), 'yyyy-MM-dd'));
  const [checkOut, setCheckOut] = useState<string>(format(addDays(new Date(), 5), 'yyyy-MM-dd'));

  const [adults, setAdults] = useState<number>(2);
  const [children, setChildren] = useState<number>(0);
  const [showGuestMenu, setShowGuestMenu] = useState(false);

  const guestMenuRef = useRef<HTMLDivElement>(null);
  const destInputRef = useRef<HTMLDivElement>(null);

  // Available autocomplete suggestions
  const destinationsList = [
    'Manali, Himachal Pradesh',
    'Kasol, Himachal Pradesh',
    'Tirthan Valley, Himachal Pradesh',
    'Mussoorie, Uttarakhand',
    'Landour, Uttarakhand',
    'Nainital, Uttarakhand',
    'Bhimtal, Uttarakhand',
    'Coorg, Karnataka',
    'Aldona, Goa',
    'Bir Billing, Himachal Pradesh',
    'Jibhi, Himachal Pradesh',
  ];

  const filteredDestinations = destinationsList.filter((d) =>
    d.toLowerCase().includes(destination.toLowerCase())
  );

  // Close menus on outside click
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (guestMenuRef.current && !guestMenuRef.current.contains(e.target as Node)) {
        setShowGuestMenu(false);
      }
      if (destInputRef.current && !destInputRef.current.contains(e.target as Node)) {
        setShowDestSuggestions(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const totalGuests = adults + children;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) {
      onSearch({ destination, checkIn, checkOut, guests: totalGuests });
    } else {
      const query = new URLSearchParams();
      if (destination) query.set('destination', destination);
      if (checkIn) query.set('checkIn', checkIn);
      if (checkOut) query.set('checkOut', checkOut);
      if (totalGuests > 1) query.set('guests', totalGuests.toString());
      navigate(`/properties?${query.toString()}`);
    }
  };

  return (
    <div id="search-and-properties" className="relative z-20 max-w-5xl mx-auto px-4 -mt-10 sm:-mt-12">
      <form
        onSubmit={handleSearchSubmit}
        className="bg-white rounded-3xl p-3 sm:p-4 shadow-2xl border border-stone-200/90 flex flex-col lg:flex-row items-stretch lg:items-center gap-3"
      >
        {/* 1. Destination Autocomplete */}
        <div ref={destInputRef} className="relative flex-1 px-4 py-2 hover:bg-stone-50 rounded-2xl transition-colors">
          <label className="block text-[11px] font-bold uppercase tracking-wider text-stone-500 mb-0.5">
            Where in India?
          </label>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[#2D5016] shrink-0" />
            <input
              type="text"
              placeholder="Search Manali, Coorg, Goa, Landour..."
              value={destination}
              onChange={(e) => {
                setDestination(e.target.value);
                setShowDestSuggestions(true);
              }}
              onFocus={() => setShowDestSuggestions(true)}
              className="w-full text-sm font-semibold text-stone-800 placeholder-stone-400 bg-transparent focus:outline-none"
            />
          </div>

          {/* Autocomplete Dropdown */}
          {showDestSuggestions && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl border border-stone-200 py-2 z-50 max-h-64 overflow-y-auto">
              <div className="px-3 py-1.5 text-[10px] uppercase font-bold tracking-wider text-stone-400">
                Suggested Destinations
              </div>
              {filteredDestinations.length > 0 ? (
                filteredDestinations.map((dest) => (
                  <button
                    key={dest}
                    type="button"
                    onClick={() => {
                      setDestination(dest.split(',')[0]);
                      setShowDestSuggestions(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-medium text-stone-700 hover:bg-[#2D5016]/10 hover:text-[#2D5016] flex items-center gap-2"
                  >
                    <MapPin className="w-3.5 h-3.5 text-[#2D5016]" />
                    <span>{dest}</span>
                  </button>
                ))
              ) : (
                <div className="px-4 py-2 text-xs text-stone-500">
                  No exact location match, press search to browse all stays.
                </div>
              )}
            </div>
          )}
        </div>

        <div className="hidden lg:block w-px h-10 bg-stone-200" />

        {/* 2. Check-in Date */}
        <div className="flex-1 px-4 py-2 hover:bg-stone-50 rounded-2xl transition-colors">
          <label className="block text-[11px] font-bold uppercase tracking-wider text-stone-500 mb-0.5">
            Check-in
          </label>
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#2D5016] shrink-0" />
            <input
              type="date"
              value={checkIn}
              min={format(new Date(), 'yyyy-MM-dd')}
              onChange={(e) => setCheckIn(e.target.value)}
              className="w-full text-sm font-semibold text-stone-800 bg-transparent focus:outline-none cursor-pointer"
            />
          </div>
        </div>

        <div className="hidden lg:block w-px h-10 bg-stone-200" />

        {/* 3. Check-out Date */}
        <div className="flex-1 px-4 py-2 hover:bg-stone-50 rounded-2xl transition-colors">
          <label className="block text-[11px] font-bold uppercase tracking-wider text-stone-500 mb-0.5">
            Check-out
          </label>
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#2D5016] shrink-0" />
            <input
              type="date"
              value={checkOut}
              min={checkIn || format(new Date(), 'yyyy-MM-dd')}
              onChange={(e) => setCheckOut(e.target.value)}
              className="w-full text-sm font-semibold text-stone-800 bg-transparent focus:outline-none cursor-pointer"
            />
          </div>
        </div>

        <div className="hidden lg:block w-px h-10 bg-stone-200" />

        {/* 4. Guests Selector (Adults + Children) */}
        <div ref={guestMenuRef} className="relative flex-1 px-4 py-2 hover:bg-stone-50 rounded-2xl transition-colors">
          <label className="block text-[11px] font-bold uppercase tracking-wider text-stone-500 mb-0.5">
            Who's traveling?
          </label>
          <button
            type="button"
            onClick={() => setShowGuestMenu(!showGuestMenu)}
            className="w-full flex items-center justify-between text-left text-sm font-semibold text-stone-800"
          >
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-[#2D5016] shrink-0" />
              <span>
                {totalGuests} {totalGuests === 1 ? 'Guest' : 'Guests'}
                {children > 0 && ` (${adults} ad, ${children} ch)`}
              </span>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-stone-400" />
          </button>

          {/* Guest selection menu dropdown */}
          {showGuestMenu && (
            <div className="absolute top-full right-0 mt-2 w-72 bg-white rounded-2xl shadow-xl border border-stone-200 p-4 z-50 space-y-4">
              {/* Adults */}
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-stone-800">Adults</p>
                  <p className="text-[11px] text-stone-500">Ages 13 or above</p>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    disabled={adults <= 1}
                    onClick={() => setAdults((prev) => Math.max(1, prev - 1))}
                    className="w-7 h-7 rounded-full border border-stone-300 flex items-center justify-center text-stone-600 disabled:opacity-30 disabled:cursor-not-allowed hover:border-stone-500"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-sm font-bold text-stone-800 w-4 text-center">{adults}</span>
                  <button
                    type="button"
                    disabled={adults >= 12}
                    onClick={() => setAdults((prev) => prev + 1)}
                    className="w-7 h-7 rounded-full border border-stone-300 flex items-center justify-center text-stone-600 disabled:opacity-30 hover:border-stone-500"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Children */}
              <div className="flex items-center justify-between pt-3 border-t border-stone-100">
                <div>
                  <p className="text-xs font-bold text-stone-800">Children</p>
                  <p className="text-[11px] text-stone-500">Ages 2–12</p>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    disabled={children <= 0}
                    onClick={() => setChildren((prev) => Math.max(0, prev - 1))}
                    className="w-7 h-7 rounded-full border border-stone-300 flex items-center justify-center text-stone-600 disabled:opacity-30 disabled:cursor-not-allowed hover:border-stone-500"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-sm font-bold text-stone-800 w-4 text-center">{children}</span>
                  <button
                    type="button"
                    disabled={children >= 8}
                    onClick={() => setChildren((prev) => prev + 1)}
                    className="w-7 h-7 rounded-full border border-stone-300 flex items-center justify-center text-stone-600 hover:border-stone-500"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setShowGuestMenu(false)}
                  className="w-full py-1.5 text-xs font-semibold rounded-lg bg-[#2D5016] text-white hover:bg-[#1F380F]"
                >
                  Done
                </button>
              </div>
            </div>
          )}
        </div>

        {/* 5. Search Button */}
        <button
          type="submit"
          className="lg:w-auto w-full px-7 py-4 rounded-2xl bg-[#C84B31] hover:bg-[#AF3E25] text-white font-bold text-sm shadow-md transition-all duration-200 hover:shadow-lg flex items-center justify-center gap-2 cursor-pointer"
        >
          <Search className="w-4 h-4" />
          <span>Find Stays</span>
        </button>
      </form>
    </div>
  );
};
