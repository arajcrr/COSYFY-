import React from 'react';
import { Star, Quote } from 'lucide-react';
import { TESTIMONIALS } from '../../data/staticData';

export const Testimonials: React.FC = () => {
  return (
    <section className="py-20 bg-[#FAF7F2] border-t border-stone-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-xs uppercase font-bold tracking-widest text-[#C84B31] bg-[#C84B31]/10 px-3 py-1 rounded-full">
            Real Travelers, Real Stories
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#1A1A1A] font-display">
            Memories Made With Local Hosts
          </h2>
          <p className="text-base text-stone-600">
            Read what solo professionals, couples, and mountain remote workers have to say about their Cosyfy stays.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.id}
              className="bg-white rounded-3xl p-8 border border-stone-200/90 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between relative group hover:-translate-y-1"
            >
              <div>
                {/* Quote Icon & Stars */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1">
                    {Array.from({ length: t.rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <Quote className="w-8 h-8 text-stone-200 group-hover:text-[#2D5016]/20 transition-colors" />
                </div>

                {/* Story text */}
                <p className="text-sm text-stone-700 leading-relaxed italic mb-6">
                  &ldquo;{t.story}&rdquo;
                </p>
              </div>

              {/* Author & Stay */}
              <div className="pt-4 border-t border-stone-100 flex items-center gap-3">
                <img
                  src={t.image}
                  alt={t.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-[#2D5016]/20"
                />
                <div>
                  <h4 className="text-sm font-bold text-[#1A1A1A] font-display">
                    {t.name}
                  </h4>
                  <p className="text-xs text-stone-500">
                    {t.role} • {t.city}
                  </p>
                  <p className="text-[11px] font-semibold text-[#2D5016] mt-0.5">
                    Stayed at {t.stay}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
