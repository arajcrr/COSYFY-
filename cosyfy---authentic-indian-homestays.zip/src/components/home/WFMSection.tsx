import React from 'react';
import { Link } from 'react-router-dom';
import { Wifi, Laptop, Signal, Calendar, ArrowRight, Sparkles } from 'lucide-react';
import { Property } from '../../types';
import { PropertyCard } from '../common/PropertyCard';

interface WFMSectionProps {
  properties: Property[];
}

export const WFMSection: React.FC<WFMSectionProps> = ({ properties }) => {
  const wfmProperties = properties.filter((p) => p.wfhReady).slice(0, 3);

  const features = [
    { label: 'WiFi Speed Tested', desc: '100+ Mbps verified with live speed tests', icon: Wifi },
    { label: 'Dedicated Desk & Chair', desc: 'Ergonomic table, silent room & power backup', icon: Laptop },
    { label: 'Airtel & Jio 5G Verified', desc: 'Flawless hotspot failover for important calls', icon: Signal },
    { label: 'Flexible 7–30 Day Stays', desc: 'Exclusive workation pricing with no hidden markups', icon: Calendar },
  ];

  return (
    <section className="py-20 bg-[#2D5016] text-white overflow-hidden relative">
      {/* Decorative background glows */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-400/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#C84B31]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-xs font-semibold text-emerald-300">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Mountain Workations for Tech & Creative Folks</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-bold font-display text-white tracking-tight">
              Work From Mountains.
            </h2>
            <p className="text-xl text-stone-200 italic font-serif">
              Same deadlines. Insane views.
            </p>
            <p className="text-sm text-stone-300 max-w-xl">
              Escape the city pollution and cramped desks. Take client calls overlooking snow-dusted pine valleys, with freshly brewed mountain chai brought to your desk.
            </p>
          </div>

          <Link
            to="/work-from-mountains"
            className="self-start md:self-end inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-[#C84B31] hover:bg-[#AF3E25] text-white font-bold text-sm shadow-xl transition-all duration-200 hover:scale-105"
          >
            <span>Find My Mountain Office</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {/* 4 Features Bar */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {features.map((f) => {
            const Icon = f.icon;
            return (
              <div
                key={f.label}
                className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-white/15 flex items-start gap-3"
              >
                <div className="p-2 rounded-xl bg-white/15 text-emerald-300 shrink-0">
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-white leading-tight">
                    {f.label}
                  </h4>
                  <p className="text-[11px] text-stone-300 mt-0.5 leading-snug">
                    {f.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* 3 WFH Property Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {wfmProperties.map((property) => (
            <div key={property.id} className="text-stone-900">
              <PropertyCard property={property} showWfmHighlight={true} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
