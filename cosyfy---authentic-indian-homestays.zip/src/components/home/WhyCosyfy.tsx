import React from 'react';
import { ShieldCheck, Percent, Languages, Zap } from 'lucide-react';

export const WhyCosyfy: React.FC = () => {
  const cards = [
    {
      title: 'Zero Service Fees',
      desc: 'What you see is what you pay. Big international travel apps add 14% to 22% guest fees at checkout. At Cosyfy, 100% of your rate goes toward genuine host hospitality.',
      icon: Percent,
      highlight: '₹0 Platform Fee',
    },
    {
      title: 'Personally Verified',
      desc: 'We do not scrape listings or auto-approve anyone with a camera. Every homestay has been vetted by our team for clean bathrooms, genuine hosts, and working hot water.',
      icon: ShieldCheck,
      highlight: 'Inspected In-Person',
    },
    {
      title: 'Hindi & Regional Support',
      desc: 'Talk to real humans who understand Indian travel needs. No robot scripts or international call centers. We speak Hindi, English, Kannada, and Pahadi dialects.',
      icon: Languages,
      highlight: 'Apne Log',
    },
    {
      title: 'Instant Response',
      desc: 'Drop us a WhatsApp query anytime between 7am and 10pm IST. You will receive real assistance, availability checks, and host contact within 2 hours guaranteed.',
      icon: Zap,
      highlight: 'Under 2 Hours',
    },
  ];

  return (
    <section className="py-20 bg-stone-100/60 border-y border-stone-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-xs uppercase font-bold tracking-widest text-[#C84B31] bg-[#C84B31]/10 px-3 py-1 rounded-full">
            The Cosyfy Difference
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#1A1A1A] font-display">
            Why India Books With Us
          </h2>
          <p className="text-base text-stone-600">
            We built Cosyfy because we were tired of soulless aggregator apps charging high fees for subpar homestays.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {cards.map((c) => {
            const Icon = c.icon;
            return (
              <div
                key={c.title}
                className="bg-white rounded-2xl p-6 border border-stone-200/90 shadow-sm hover:shadow-lg transition-all duration-200 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-[#2D5016]/10 text-[#2D5016] flex items-center justify-center">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-bold text-[#C84B31] bg-[#C84B31]/10 px-2.5 py-1 rounded-md">
                      {c.highlight}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-[#1A1A1A] mb-2 font-display">
                    {c.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                    {c.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
