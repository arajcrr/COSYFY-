import React from 'react';
import {
  Wifi,
  Wind,
  Flame,
  Coffee,
  Car,
  Dog,
  Mountain,
  Briefcase,
  Bath,
  Zap,
  UtensilsCrossed,
  CheckCircle2,
} from 'lucide-react';
import { Amenity } from '../../types';

interface AmenitiesGridProps {
  amenities: Amenity[];
}

export const AmenitiesGrid: React.FC<AmenitiesGridProps> = ({ amenities }) => {
  const getIcon = (amenity: Amenity) => {
    switch (amenity) {
      case 'WiFi':
        return <Wifi className="w-5 h-5 text-[#2D5016]" />;
      case 'AC':
        return <Wind className="w-5 h-5 text-[#2D5016]" />;
      case 'Heater':
        return <Flame className="w-5 h-5 text-[#C84B31]" />;
      case 'Meals':
        return <Coffee className="w-5 h-5 text-[#2D5016]" />;
      case 'Parking':
        return <Car className="w-5 h-5 text-[#2D5016]" />;
      case 'Pet Friendly':
        return <Dog className="w-5 h-5 text-[#2D5016]" />;
      case 'Mountain View':
        return <Mountain className="w-5 h-5 text-[#2D5016]" />;
      case 'Bonfire':
        return <Flame className="w-5 h-5 text-[#C84B31]" />;
      case 'Work Desk':
        return <Briefcase className="w-5 h-5 text-[#2D5016]" />;
      case 'Private Bathroom':
        return <Bath className="w-5 h-5 text-[#2D5016]" />;
      case 'Power Backup':
        return <Zap className="w-5 h-5 text-amber-600" />;
      case 'Kitchen Access':
        return <UtensilsCrossed className="w-5 h-5 text-[#2D5016]" />;
      default:
        return <CheckCircle2 className="w-5 h-5 text-[#2D5016]" />;
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-bold text-[#1A1A1A] font-display">
        What this homestay offers
      </h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
        {amenities.map((amenity) => (
          <div
            key={amenity}
            className="flex items-center gap-3 p-3.5 rounded-2xl bg-white border border-stone-200/80 shadow-xs"
          >
            <div className="p-2 rounded-xl bg-stone-100/80 shrink-0">
              {getIcon(amenity)}
            </div>
            <span className="text-xs sm:text-sm font-medium text-stone-800">
              {amenity}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
