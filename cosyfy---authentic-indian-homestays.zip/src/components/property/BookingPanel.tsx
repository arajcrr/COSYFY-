import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { differenceInDays, parseISO, format, addDays } from 'date-fns';
import {
  ShieldCheck,
  MessageCircle,
  Info,
  Calendar,
  Users,
  Lock,
  CreditCard,
  ChevronDown,
  ChevronUp,
  ShieldAlert,
} from 'lucide-react';
import { Property } from '../../types';
import { formatPrice, getWhatsAppUrl } from '../../utils';

interface BookingPanelProps {
  property: Property;
}

export const BookingPanel: React.FC<BookingPanelProps> = ({ property }) => {
  const navigate = useNavigate();
  const [checkIn, setCheckIn] = useState<string>(format(addDays(new Date(), 2), 'yyyy-MM-dd'));
  const [checkOut, setCheckOut] = useState<string>(format(addDays(new Date(), 5), 'yyyy-MM-dd'));
  const [guests, setGuests] = useState<number>(2);
  const [showCancellationPolicy, setShowCancellationPolicy] = useState(false);

  // Calculate nights
  let nights = 3;
  try {
    const diff = differenceInDays(parseISO(checkOut), parseISO(checkIn));
    nights = diff > 0 ? diff : 1;
  } catch {
    nights = 3;
  }

  const isRemote = Boolean(property.remoteProperty);
  const ratePerNight = property.weekdayPrice;
  const stayCost = ratePerNight * nights;
  const cleaningFee = property.cleaningFee || 0;
  const totalCost = stayCost + cleaningFee;

  // Remote properties collect 100% full payment; standard collects 10%
  const advanceDeposit = isRemote ? totalCost : Math.round(totalCost * 0.1);
  const remainingBalance = totalCost - advanceDeposit;

  const whatsappNum = import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210';
  const whatsappUrl = getWhatsAppUrl(
    whatsappNum,
    `Hi! I have a question about booking "${property.name}" in ${property.location} from ${checkIn} to ${checkOut}.`
  );

  const handleRequestClick = () => {
    const searchParams = new URLSearchParams({
      checkIn,
      checkOut,
      guests: guests.toString(),
      nights: nights.toString(),
    });
    navigate(`/booking-request/${property.id}?${searchParams.toString()}`);
  };

  return (
    <div className="sticky top-28 bg-white rounded-3xl p-6 sm:p-7 border border-stone-200/90 shadow-xl space-y-5">
      {/* Price Header */}
      <div className="flex items-baseline justify-between">
        <div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A]">
              {formatPrice(property.weekdayPrice)}
            </span>
            <span className="text-sm text-stone-500">/ night</span>
          </div>
          {property.weekendPrice !== property.weekdayPrice && (
            <p className="text-xs text-stone-400 mt-0.5">
              {formatPrice(property.weekendPrice)} on weekends
            </p>
          )}
        </div>

        {/* Zero Fee Badge */}
        <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-[#2D5016]/10 text-[#2D5016]">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Zero Service Fee</span>
        </span>
      </div>

      {/* Remote Property Badge if applicable */}
      {isRemote && (
        <div className="bg-orange-50 border border-orange-200/90 rounded-xl p-2.5 flex items-center gap-2 text-[11px] text-[#C84B31] font-semibold">
          <ShieldAlert className="w-4 h-4 shrink-0 text-[#C84B31]" />
          <span>Remote Mountain Location • Full Payment Collected at Booking</span>
        </div>
      )}

      {/* Date & Guest Pickers Form */}
      <div className="rounded-2xl border border-stone-200 overflow-hidden divide-y divide-stone-200 text-xs">
        <div className="grid grid-cols-2 divide-x divide-stone-200 bg-stone-50/50">
          <div className="p-3">
            <label className="block text-[10px] font-bold uppercase tracking-wider text-stone-500 mb-1">
              Check-in
            </label>
            <input
              type="date"
              value={checkIn}
              min={format(new Date(), 'yyyy-MM-dd')}
              onChange={(e) => setCheckIn(e.target.value)}
              className="w-full font-semibold text-stone-800 bg-transparent focus:outline-none cursor-pointer"
            />
          </div>
          <div className="p-3">
            <label className="block text-[10px] font-bold uppercase tracking-wider text-stone-500 mb-1">
              Check-out
            </label>
            <input
              type="date"
              value={checkOut}
              min={checkIn || format(new Date(), 'yyyy-MM-dd')}
              onChange={(e) => setCheckOut(e.target.value)}
              className="w-full font-semibold text-stone-800 bg-transparent focus:outline-none cursor-pointer"
            />
          </div>
        </div>

        <div className="p-3 bg-stone-50/50">
          <label className="block text-[10px] font-bold uppercase tracking-wider text-stone-500 mb-1">
            Guests
          </label>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-[#2D5016]" />
              <select
                value={guests}
                onChange={(e) => setGuests(Number(e.target.value))}
                className="font-semibold text-stone-800 bg-transparent focus:outline-none cursor-pointer"
              >
                {Array.from({ length: property.maxGuests }, (_, i) => i + 1).map((num) => (
                  <option key={num} value={num}>
                    {num} {num === 1 ? 'Guest' : 'Guests'} (Max {property.maxGuests})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Price Breakdown */}
      <div className="space-y-2 pt-1 text-xs text-stone-600">
        <div className="flex justify-between">
          <span>
            {formatPrice(ratePerNight)} × {nights} {nights === 1 ? 'night' : 'nights'}
          </span>
          <span className="font-semibold text-stone-900">{formatPrice(stayCost)}</span>
        </div>

        <div className="flex justify-between">
          <span className="flex items-center gap-1">
            <span>Cosyfy Service Fee</span>
            <span className="text-[10px] bg-emerald-100 text-[#2D5016] px-1.5 py-0.5 rounded font-bold">FREE</span>
          </span>
          <span className="font-semibold text-[#2D5016]">₹0</span>
        </div>

        {cleaningFee > 0 && (
          <div className="flex justify-between">
            <span>Cleaning & Linen Fee</span>
            <span className="font-semibold text-stone-900">{formatPrice(cleaningFee)}</span>
          </div>
        )}

        <div className="border-t border-stone-200 pt-2.5 flex justify-between text-sm font-bold text-stone-900">
          <span>Total Stay Amount</span>
          <span>{formatPrice(totalCost)}</span>
        </div>

        {/* Advance Deposit Highlighted Box */}
        <div className="bg-[#FAF7F2] rounded-xl p-3 border-2 border-[#C84B31]/30 flex items-start gap-2 text-[11px] mt-2">
          <Info className="w-4 h-4 text-[#C84B31] shrink-0 mt-0.5" />
          <div className="text-stone-800">
            {isRemote ? (
              <>
                <span className="font-bold text-[#C84B31]">100% Advance Payment ({formatPrice(advanceDeposit)})</span>
                <span className="block text-stone-600">Full payment required due to remote connectivity.</span>
              </>
            ) : (
              <>
                <span className="font-bold text-[#C84B31]">Pay only 10% ({formatPrice(advanceDeposit)})</span> to secure your booking.
                <span className="block text-stone-600">Remaining 90% ({formatPrice(remainingBalance)}) paid directly to host on arrival.</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Action Button */}
      <div className="space-y-2.5 pt-1">
        <button
          onClick={handleRequestClick}
          className="w-full py-4 rounded-2xl bg-[#C84B31] hover:bg-[#AF3E25] text-white font-bold text-sm sm:text-base shadow-lg transition-all duration-200 hover:shadow-xl hover:scale-[1.01] flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>Request This Stay</span>
        </button>

        {/* Two Trust Signals directly below button */}
        <div className="space-y-1.5 pt-1 text-[11px] text-stone-600 bg-stone-50/70 p-3 rounded-xl border border-stone-200/60">
          <div className="flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-[#2D5016] shrink-0" />
            <span>
              {isRemote
                ? '80% refundable if cancelled 15+ days before check-in'
                : '100% refundable if cancelled 7+ days before check-in'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <CreditCard className="w-3.5 h-3.5 text-[#2D5016] shrink-0" />
            <span>Secure payment via Razorpay — UPI, Cards, Netbanking accepted</span>
          </div>
        </div>

        {/* BONUS CHANGE: Cosyfy Booking Protection Section */}
        <div className="bg-emerald-50/70 rounded-xl p-3 border border-emerald-200/80 space-y-1 text-[11px]">
          <div className="font-bold text-[#2D5016] flex items-center gap-1.5">
            <span>🛡️ Cosyfy Booking Protection</span>
          </div>
          <ul className="space-y-0.5 text-stone-700 pl-1">
            <li className="flex items-center gap-1.5">
              <span className="text-[#2D5016] font-bold">✓</span>
              <span>Owner confirmed before you pay balance</span>
            </li>
            <li className="flex items-center gap-1.5">
              <span className="text-[#2D5016] font-bold">✓</span>
              <span>Alternative property if anything goes wrong</span>
            </li>
            <li className="flex items-center gap-1.5">
              <span className="text-[#2D5016] font-bold">✓</span>
              <span>Direct WhatsApp support 7am-10pm</span>
            </li>
            <li className="flex items-center gap-1.5">
              <span className="text-[#2D5016] font-bold">✓</span>
              <span>Zero booking fees charged to you</span>
            </li>
          </ul>
        </div>

        {/* WhatsApp Questions Link */}
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full py-2.5 rounded-xl text-xs font-semibold text-stone-600 hover:text-[#2D5016] hover:bg-stone-50 transition-colors flex items-center justify-center gap-2 border border-stone-200"
        >
          <MessageCircle className="w-4 h-4 text-[#25D366]" />
          <span>Have questions? WhatsApp our team</span>
        </a>
      </div>

      {/* Collapsible Cancellation Policy */}
      <div className="pt-2 border-t border-stone-200">
        <button
          type="button"
          onClick={() => setShowCancellationPolicy(!showCancellationPolicy)}
          className="w-full flex items-center justify-between text-left text-xs font-bold text-stone-700 hover:text-[#2D5016]"
        >
          <span>Cancellation Policy Details</span>
          {showCancellationPolicy ? (
            <ChevronUp className="w-3.5 h-3.5 text-stone-500" />
          ) : (
            <ChevronDown className="w-3.5 h-3.5 text-stone-500" />
          )}
        </button>

        {showCancellationPolicy && (
          <div className="mt-2.5 p-3 rounded-xl bg-stone-50 border border-stone-200 text-[11px] text-stone-600 space-y-1.5 animate-in fade-in">
            {isRemote ? (
              <>
                <p className="font-bold text-[#C84B31]">REMOTE PROPERTY POLICY</p>
                <p>✅ Cancel 15+ days before check-in: 80% refund</p>
                <p>⚡ Cancel 7-15 days before check-in: 50% refund</p>
                <p>❌ Cancel less than 7 days: No refund</p>
                <p className="text-[10px] text-stone-500 pt-1">
                  Protects host families in remote regions who cannot re-book at short notice.
                </p>
              </>
            ) : (
              <>
                <p className="font-bold text-[#2D5016]">STANDARD POLICY</p>
                <p>✅ Cancel 7+ days before check-in: Full refund of advance</p>
                <p>⚡ Cancel 3-7 days before check-in: 50% refund of advance</p>
                <p>❌ Cancel less than 3 days: No refund of advance</p>
                <p className="text-[10px] text-stone-500 pt-1">
                  All refunds processed within 5-7 business days to original payment method.
                </p>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
