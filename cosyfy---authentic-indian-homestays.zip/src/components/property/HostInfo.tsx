import React from 'react';
import { ShieldCheck, MessageCircle, Clock, Calendar } from 'lucide-react';
import { HostInfo as HostType } from '../../types';
import { getWhatsAppUrl } from '../../utils';

interface HostInfoProps {
  host: HostType;
  propertyName: string;
}

export const HostInfo: React.FC<HostInfoProps> = ({ host, propertyName }) => {
  const whatsappNum = import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210';
  const prefilledMessage = `Hi, I'm interested in ${propertyName} on Cosyfy. Can you tell me more about host availability and meals?`;
  const whatsappUrl = getWhatsAppUrl(whatsappNum, prefilledMessage);

  return (
    <div className="bg-stone-50 rounded-3xl p-6 sm:p-8 border border-stone-200/90 space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl overflow-hidden bg-stone-200 border-2 border-[#2D5016]/20 shrink-0">
            {host.avatar ? (
              <img src={host.avatar} alt={host.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center font-bold text-xl text-[#2D5016] bg-[#2D5016]/10">
                {host.name.charAt(0)}
              </div>
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg sm:text-xl font-bold text-[#1A1A1A] font-display">
                Hosted by {host.name}
              </h3>
              <span title="Cosyfy Verified Host">
                <ShieldCheck className="w-4 h-4 text-[#2D5016]" />
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-stone-500 mt-1">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                <span>Host on Cosyfy since {host.memberSince}</span>
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-emerald-600" />
                <span>Responds {host.responseTime}</span>
              </span>
            </div>
          </div>
        </div>

        {/* WhatsApp Host Button */}
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full text-xs font-semibold bg-[#2D5016] hover:bg-[#1F380F] text-white shadow-sm transition-all"
        >
          <MessageCircle className="w-4 h-4 fill-white" />
          <span>Chat with host about this property</span>
        </a>
      </div>

      <p className="text-sm text-stone-700 leading-relaxed italic border-t border-stone-200 pt-4">
        &ldquo;{host.bio}&rdquo;
      </p>
    </div>
  );
};
