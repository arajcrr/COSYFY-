import React, { useState, useEffect, useRef } from 'react';
import { Video, X, ChevronLeft, ChevronRight, Maximize2, Play } from 'lucide-react';

interface ImageGalleryProps {
  images: string[];
  videoUrl?: string;
  propertyName: string;
}

export const ImageGallery: React.FC<ImageGalleryProps> = ({ images, videoUrl, propertyName }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [activeModalIndex, setActiveModalIndex] = useState<number | null>(null);
  const [showVideoModal, setShowVideoModal] = useState<boolean>(false);

  // Touch gesture tracking for mobile swipe
  const touchStartX = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);

  // Resume timer ref
  const resumeTimerRef = useRef<NodeJS.Timeout | null>(null);

  const totalPhotos = images.length;

  // Auto-slide effect (advances every 4 seconds)
  useEffect(() => {
    if (isPaused || totalPhotos <= 1) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % totalPhotos);
    }, 4000);

    return () => clearInterval(interval);
  }, [isPaused, totalPhotos]);

  // Pause on manual user action and resume after 6 seconds of inactivity
  const handleUserInteraction = () => {
    setIsPaused(true);
    if (resumeTimerRef.current) {
      clearTimeout(resumeTimerRef.current);
    }
    resumeTimerRef.current = setTimeout(() => {
      setIsPaused(false);
    }, 6000);
  };

  const goToNext = () => {
    handleUserInteraction();
    setCurrentIndex((prev) => (prev + 1) % totalPhotos);
  };

  const goToPrev = () => {
    handleUserInteraction();
    setCurrentIndex((prev) => (prev - 1 + totalPhotos) % totalPhotos);
  };

  const goToIndex = (index: number) => {
    handleUserInteraction();
    setCurrentIndex(index);
  };

  // Mobile Touch Swipe Handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (touchStartX.current === null || touchEndX.current === null) return;
    const distance = touchStartX.current - touchEndX.current;
    const minSwipeDistance = 45;

    if (distance > minSwipeDistance) {
      // Swiped Left -> Next
      goToNext();
    } else if (distance < -minSwipeDistance) {
      // Swiped Right -> Prev
      goToPrev();
    }

    touchStartX.current = null;
    touchEndX.current = null;
  };

  return (
    <div className="space-y-3">
      {/* Action Header: Walkthrough Video Button */}
      {videoUrl && (
        <div className="flex items-center justify-between pb-1">
          <button
            type="button"
            onClick={() => setShowVideoModal(true)}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-[#C84B31] hover:bg-[#AF3E25] text-white shadow-sm transition-transform hover:scale-102"
          >
            <Play className="w-3.5 h-3.5 fill-white" />
            <span>Walkthrough Video Tour</span>
          </button>

          <span className="text-[11px] text-stone-500 hidden sm:inline">
            Swipe or tap dots to explore all {totalPhotos} rooms & views
          </span>
        </div>
      )}

      {/* Main Auto-sliding Carousel Container */}
      <div
        className="relative aspect-[16/10] sm:aspect-[16/9] w-full rounded-3xl overflow-hidden bg-stone-900 shadow-md group select-none"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Images with smooth fade/slide transition */}
        {images.map((img, idx) => (
          <div
            key={idx}
            className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
              idx === currentIndex ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
            }`}
          >
            <img
              src={img}
              alt={`${propertyName} photo ${idx + 1}`}
              className="w-full h-full object-cover"
              loading={idx === 0 ? 'eager' : 'lazy'}
            />
          </div>
        ))}

        {/* Gradient Scrims */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/30 pointer-events-none z-10" />

        {/* Photo Count in Top Right Corner (e.g. "2/5") */}
        <div className="absolute top-4 right-4 z-20 px-3 py-1 rounded-full text-xs font-bold text-white bg-black/60 backdrop-blur-md border border-white/20 shadow-sm">
          {currentIndex + 1} / {totalPhotos}
        </div>

        {/* Fullscreen Expand Trigger (Top Left) */}
        <button
          type="button"
          onClick={() => setActiveModalIndex(currentIndex)}
          className="absolute top-4 left-4 z-20 p-2 rounded-full text-white bg-black/50 hover:bg-black/70 backdrop-blur-md transition-colors"
          title="Open Fullscreen Gallery"
          aria-label="Open Fullscreen Gallery"
        >
          <Maximize2 className="w-4 h-4" />
        </button>

        {/* Navigation Arrows (Desktop hover / visible) */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            goToPrev();
          }}
          className="absolute left-3 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white/80 hover:bg-white text-stone-800 backdrop-blur-md flex items-center justify-center shadow-lg transition-transform hover:scale-110 focus:outline-none"
          aria-label="Previous photo"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            goToNext();
          }}
          className="absolute right-3 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white/80 hover:bg-white text-stone-800 backdrop-blur-md flex items-center justify-center shadow-lg transition-transform hover:scale-110 focus:outline-none"
          aria-label="Next photo"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* Dot Indicators at Bottom */}
        <div className="absolute bottom-4 left-0 right-0 z-20 flex items-center justify-center gap-2">
          {images.map((_, idx) => (
            <button
              key={idx}
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                goToIndex(idx);
              }}
              className={`transition-all duration-300 rounded-full ${
                idx === currentIndex
                  ? 'w-7 h-2.5 bg-white shadow-md'
                  : 'w-2.5 h-2.5 bg-white/50 hover:bg-white/80'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>
      </div>

      {/* Thumbnails strip */}
      <div className="hidden sm:grid grid-cols-5 gap-2 pt-1">
        {images.slice(0, 5).map((img, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => goToIndex(idx)}
            className={`relative aspect-[4/3] rounded-xl overflow-hidden border-2 transition-all ${
              idx === currentIndex
                ? 'border-[#2D5016] ring-2 ring-[#2D5016]/30 shadow-md'
                : 'border-transparent opacity-70 hover:opacity-100'
            }`}
          >
            <img src={img} alt={`Thumb ${idx + 1}`} className="w-full h-full object-cover" />
            {idx === 4 && totalPhotos > 5 && (
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveModalIndex(4);
                }}
                className="absolute inset-0 bg-black/60 flex items-center justify-center text-white text-xs font-bold"
              >
                +{totalPhotos - 5} More
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Fullscreen Video Tour Modal */}
      {showVideoModal && videoUrl && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4">
          <button
            type="button"
            onClick={() => setShowVideoModal(false)}
            className="absolute top-5 right-5 p-2.5 rounded-full bg-white/20 hover:bg-white/40 text-white transition-colors z-50"
            aria-label="Close video tour"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="max-w-4xl w-full aspect-video rounded-2xl overflow-hidden bg-black shadow-2xl">
            <video
              src={videoUrl}
              controls
              autoPlay
              className="w-full h-full object-contain"
            />
          </div>
        </div>
      )}

      {/* Fullscreen Photo Lightbox Modal */}
      {activeModalIndex !== null && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4">
          <button
            type="button"
            onClick={() => setActiveModalIndex(null)}
            className="absolute top-5 right-5 p-2.5 rounded-full bg-white/20 hover:bg-white/40 text-white transition-colors z-50"
            aria-label="Close image gallery"
          >
            <X className="w-6 h-6" />
          </button>

          <button
            type="button"
            onClick={() =>
              setActiveModalIndex((activeModalIndex - 1 + totalPhotos) % totalPhotos)
            }
            className="absolute left-5 p-3 rounded-full bg-white/20 hover:bg-white/40 text-white transition-colors z-50"
            aria-label="Previous image"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <div className="max-w-5xl max-h-[85vh] flex flex-col items-center">
            <img
              src={images[activeModalIndex]}
              alt={`${propertyName} fullscreen ${activeModalIndex + 1}`}
              className="max-h-[80vh] w-auto object-contain rounded-xl shadow-2xl"
            />
            <p className="text-stone-300 text-xs mt-3">
              Photo {activeModalIndex + 1} of {totalPhotos} • {propertyName}
            </p>
          </div>

          <button
            type="button"
            onClick={() =>
              setActiveModalIndex((activeModalIndex + 1) % totalPhotos)
            }
            className="absolute right-5 p-3 rounded-full bg-white/20 hover:bg-white/40 text-white transition-colors z-50"
            aria-label="Next image"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      )}
    </div>
  );
};
