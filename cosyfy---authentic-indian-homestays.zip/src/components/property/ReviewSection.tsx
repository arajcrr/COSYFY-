import React, { useState } from 'react';
import { Star, MessageSquareQuote, CheckCircle2, User } from 'lucide-react';
import { PropertyReview } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface ReviewSectionProps {
  rating: number;
  reviewCount: number;
  reviews?: PropertyReview[];
  propertyName: string;
}

export const ReviewSection: React.FC<ReviewSectionProps> = ({
  rating,
  reviewCount,
  reviews = [],
  propertyName,
}) => {
  const { user } = useAuth();
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [submittedReview, setSubmittedReview] = useState(false);
  const [reviewText, setReviewText] = useState('');
  const [userRating, setUserRating] = useState(5);

  const breakdown = [
    { label: 'Cleanliness', score: 4.9 },
    { label: 'Hospitality & Host Care', score: 5.0 },
    { label: 'Location & Surroundings', score: 4.9 },
    { label: 'Value for Money', score: 5.0 },
  ];

  const handlePostReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewText.trim()) return;
    setSubmittedReview(true);
    setTimeout(() => {
      setShowReviewModal(false);
      setReviewText('');
    }, 1500);
  };

  return (
    <div className="space-y-8 pt-8 border-t border-stone-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 text-stone-900 border border-amber-200">
            <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
            <span className="text-xl font-bold">{rating.toFixed(2)}</span>
          </div>
          <div>
            <h3 className="text-xl font-bold text-[#1A1A1A] font-display">
              Guest Experiences ({reviewCount})
            </h3>
            <p className="text-xs text-stone-500">100% verified homestay guest stays</p>
          </div>
        </div>

        {user ? (
          <button
            onClick={() => setShowReviewModal(true)}
            className="px-4 py-2 rounded-xl text-xs font-semibold bg-white border border-stone-300 text-stone-800 hover:border-[#2D5016] hover:text-[#2D5016] transition-colors self-start sm:self-auto"
          >
            Write a Review
          </button>
        ) : (
          <span className="text-xs text-stone-400 italic">
            Log in to write a review after your stay
          </span>
        )}
      </div>

      {/* Ratings Breakdown Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-5 rounded-2xl bg-white border border-stone-200/80 shadow-xs">
        {breakdown.map((item) => (
          <div key={item.label} className="space-y-1">
            <div className="flex justify-between text-xs font-semibold text-stone-700">
              <span>{item.label}</span>
              <span className="text-[#2D5016]">{item.score}</span>
            </div>
            <div className="w-full h-1.5 bg-stone-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-[#2D5016] rounded-full"
                style={{ width: `${(item.score / 5) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Reviews Cards List */}
      <div className="space-y-4">
        {reviews.length > 0 ? (
          reviews.map((rev) => (
            <div
              key={rev.id}
              className="p-5 rounded-2xl bg-white border border-stone-200/80 shadow-xs space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-stone-100 text-[#2D5016] font-bold text-xs flex items-center justify-center">
                    {rev.guestName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-stone-900">{rev.guestName}</h4>
                    <span className="text-[11px] text-stone-400">{rev.date}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  {Array.from({ length: rev.rating }).map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  ))}
                </div>
              </div>

              <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
                {rev.text}
              </p>

              {rev.hostResponse && (
                <div className="bg-stone-50 rounded-xl p-3 border-l-2 border-[#2D5016] text-xs text-stone-600 mt-2">
                  <span className="font-bold text-stone-800 block mb-0.5">Response from host:</span>
                  {rev.hostResponse}
                </div>
              )}
            </div>
          ))
        ) : (
          <p className="text-xs text-stone-500 italic py-2">
            No public reviews written yet. Be the first to stay and share your experience!
          </p>
        )}
      </div>

      {/* Review Modal */}
      {showReviewModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            <h3 className="text-lg font-bold text-stone-900 font-display">
              Review your stay at {propertyName}
            </h3>

            {submittedReview ? (
              <div className="py-6 text-center space-y-2">
                <CheckCircle2 className="w-12 h-12 text-[#2D5016] mx-auto animate-bounce" />
                <p className="text-sm font-bold text-stone-900">Thank you for your review!</p>
                <p className="text-xs text-stone-500">Your feedback helps local Indian families thrive.</p>
              </div>
            ) : (
              <form onSubmit={handlePostReview} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Overall Rating</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setUserRating(star)}
                        className="p-1"
                      >
                        <Star
                          className={`w-6 h-6 ${
                            star <= userRating
                              ? 'fill-amber-400 text-amber-400'
                              : 'text-stone-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Your Experience & Host Hospitality
                  </label>
                  <textarea
                    rows={4}
                    value={reviewText}
                    onChange={(e) => setReviewText(e.target.value)}
                    placeholder="Tell future travelers about the food, the rooms, the morning views, and the host family..."
                    className="w-full p-3 rounded-xl border border-stone-300 text-xs text-stone-800 focus:outline-none focus:border-[#2D5016]"
                    required
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowReviewModal(false)}
                    className="flex-1 py-2.5 rounded-xl border border-stone-300 text-xs font-bold text-stone-700"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-[#2D5016] text-white text-xs font-bold hover:bg-[#1F380F]"
                  >
                    Submit Review
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
