import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  auth,
  googleProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  updateProfile,
  onAuthStateChanged,
  FirebaseUser,
  getUserProfile,
  createUserProfile,
  updateUserProfile,
} from '../services/firebase';
import { UserProfile } from '../types';

interface AuthContextType {
  user: FirebaseUser | null;
  profile: UserProfile | null;
  loading: boolean;
  isAdmin: boolean;
  savedPropertyIds: string[];
  signInWithEmail: (e: string, p: string) => Promise<void>;
  signUpWithEmail: (e: string, p: string, fullName: string, phone: string) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  sendPasswordReset: (e: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfileData: (data: Partial<UserProfile>) => Promise<void>;
  toggleSaveProperty: (propertyId: string) => void;
  isSaved: (propertyId: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [savedPropertyIds, setSavedPropertyIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('cosyfy_saved_stays');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const ADMIN_EMAIL = 'avnish.raj.crr@gmail.com';
  const isAdmin = Boolean(
    (user?.email && user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) ||
    profile?.role === 'admin'
  );

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          let userProfile = await getUserProfile(currentUser.uid);
          if (!userProfile) {
            // First time login via Google or external provider
            userProfile = {
              id: currentUser.uid,
              email: currentUser.email || '',
              fullName: currentUser.displayName || 'Cosyfy Guest',
              role: currentUser.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase() ? 'admin' : 'customer',
              createdAt: new Date().toISOString(),
            };
            await createUserProfile(userProfile);
          }
          setProfile(userProfile);
        } catch (err) {
          console.warn('Could not load user profile, using fallback:', err);
          setProfile({
            id: currentUser.uid,
            email: currentUser.email || '',
            fullName: currentUser.displayName || 'Cosyfy Guest',
            role: currentUser.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase() ? 'admin' : 'customer',
          });
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithEmail = async (email: string, pass: string) => {
    await signInWithEmailAndPassword(auth, email, pass);
  };

  const signUpWithEmail = async (email: string, pass: string, fullName: string, phone: string) => {
    const cred = await createUserWithEmailAndPassword(auth, email, pass);
    await updateProfile(cred.user, { displayName: fullName });
    const newProfile: UserProfile = {
      id: cred.user.uid,
      email: cred.user.email || email,
      fullName,
      phone,
      whatsapp: phone,
      role: email.toLowerCase() === ADMIN_EMAIL.toLowerCase() ? 'admin' : 'customer',
      createdAt: new Date().toISOString(),
    };
    await createUserProfile(newProfile);
    setProfile(newProfile);
  };

  const signInWithGoogle = async () => {
    await signInWithPopup(auth, googleProvider);
  };

  const sendPasswordReset = async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  };

  const logout = async () => {
    await signOut(auth);
    setProfile(null);
    setUser(null);
  };

  const updateProfileData = async (data: Partial<UserProfile>) => {
    if (!user) return;
    await updateUserProfile(user.uid, data);
    setProfile((prev) => (prev ? { ...prev, ...data } : null));
  };

  const toggleSaveProperty = (propertyId: string) => {
    setSavedPropertyIds((prev) => {
      const exists = prev.includes(propertyId);
      const updated = exists ? prev.filter((id) => id !== propertyId) : [...prev, propertyId];
      try {
        localStorage.setItem('cosyfy_saved_stays', JSON.stringify(updated));
      } catch (e) {
        console.error(e);
      }
      return updated;
    });
  };

  const isSaved = (propertyId: string) => savedPropertyIds.includes(propertyId);

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        isAdmin,
        savedPropertyIds,
        signInWithEmail,
        signUpWithEmail,
        signInWithGoogle,
        sendPasswordReset,
        logout,
        updateProfileData,
        toggleSaveProperty,
        isSaved,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
