import React, { createContext, useContext, useState } from 'react';

export const TAGLINES: Record<string, string> = {
  hi: 'Ek message karo, baaki hum sambhalenge',
  ta: 'Oru message pannunga, meedhi nanga paathukurom',
  te: 'Oka message cheyandi, migilindi memu chusukuntaam',
  kn: 'Ondu message kali, ulida navu nodikollutteve',
  ml: 'Oru message akanam, baaki njangal nokkolaam',
  bn: 'Ekta message koro, baki amra dekhe nebo',
  mr: 'Ek message kara, baaki aamhi sambhaloo',
  gu: 'Ek message karo, baaki ame sambhali laishu',
  pa: 'Ik message karo, baaki assi sambhal laange',
  default: 'One message. We handle the rest.',
};

export const LANGUAGE_LABELS: Record<string, { name: string; nativeName: string }> = {
  hi: { name: 'Hindi', nativeName: 'हिन्दी' },
  ta: { name: 'Tamil', nativeName: 'தமிழ்' },
  te: { name: 'Telugu', nativeName: 'తెలుగు' },
  kn: { name: 'Kannada', nativeName: 'ಕನ್ನಡ' },
  ml: { name: 'Malayalam', nativeName: 'മലയാളം' },
  bn: { name: 'Bengali', nativeName: 'বাংলা' },
  mr: { name: 'Marathi', nativeName: 'मराठी' },
  gu: { name: 'Gujarati', nativeName: 'ગુજરાતી' },
  pa: { name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ' },
  default: { name: 'English', nativeName: 'English' },
};

interface LanguageContextType {
  currentLang: string;
  detectedLang: string;
  isManuallySelected: boolean;
  tagline: string;
  setLanguage: (lang: string) => void;
  resetToDetected: () => void;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

function detectBrowserLanguage(): string {
  if (typeof window === 'undefined' || !navigator.language) {
    return 'default';
  }

  const primary = navigator.language.split('-')[0].toLowerCase();
  if (TAGLINES[primary]) {
    return primary;
  }

  // Check navigator.languages list if available
  if (navigator.languages) {
    for (const l of navigator.languages) {
      const code = l.split('-')[0].toLowerCase();
      if (TAGLINES[code]) {
        return code;
      }
    }
  }

  // Default to Hindi
  return 'hi';
}

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [detectedLang] = useState<string>(() => detectBrowserLanguage());
  const [currentLang, setCurrentLang] = useState<string>(() => {
    const saved = localStorage.getItem('cosyfy_user_lang');
    if (saved && TAGLINES[saved]) {
      return saved;
    }
    return detectBrowserLanguage();
  });
  const [isManuallySelected, setIsManuallySelected] = useState<boolean>(() => {
    return Boolean(localStorage.getItem('cosyfy_user_lang'));
  });

  const setLanguage = (lang: string) => {
    if (TAGLINES[lang]) {
      setCurrentLang(lang);
      setIsManuallySelected(true);
      localStorage.setItem('cosyfy_user_lang', lang);
    }
  };

  const resetToDetected = () => {
    setCurrentLang(detectedLang);
    setIsManuallySelected(false);
    localStorage.removeItem('cosyfy_user_lang');
  };

  const tagline = TAGLINES[currentLang] || TAGLINES.default;

  return (
    <LanguageContext.Provider
      value={{
        currentLang,
        detectedLang,
        isManuallySelected,
        tagline,
        setLanguage,
        resetToDetected,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
