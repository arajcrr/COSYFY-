import { useState, useEffect } from 'react';
import { Booking, BookingStatus } from '../types';
import { createAirtableBooking } from '../services/airtable';
import { saveBookingToFirestore, getBookingByReference } from '../services/firebase';
import { sendBookingWebhook } from '../services/webhooks';

export function useBooking(initialBooking?: Booking | null) {
  const [currentBooking, setCurrentBooking] = useState<Booking | null>(initialBooking || null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [status, setStatus] = useState<BookingStatus>(initialBooking?.status || 'pending');
  const [error, setError] = useState<string | null>(null);

  // Poll booking status every 60 seconds if in waiting flow
  useEffect(() => {
    if (!currentBooking?.bookingReference) return;
    if (status === 'confirmed' || status === 'declined' || status === 'cancelled') return;

    const interval = setInterval(async () => {
      try {
        const updated = await getBookingByReference(currentBooking.bookingReference);
        if (updated && updated.status !== status) {
          setStatus(updated.status);
          setCurrentBooking(updated);
        }
      } catch (e) {
        // Silent catch to prevent distracting users
        console.warn('Booking status poll error:', e);
      }
    }, 60000);

    return () => clearInterval(interval);
  }, [currentBooking?.bookingReference, status]);

  const submitBooking = async (bookingData: Booking): Promise<boolean> => {
    setIsSubmitting(true);
    setError(null);
    try {
      // 1. Save to Firestore
      await saveBookingToFirestore(bookingData);

      // 2. Save to Airtable
      await createAirtableBooking(bookingData);

      // 3. Trigger Make.com Webhook
      await sendBookingWebhook(bookingData);

      setCurrentBooking(bookingData);
      setStatus(bookingData.status);
      return true;
    } catch (err: any) {
      console.error('Submit booking error:', err);
      setError(err?.message || 'Failed to submit booking request');
      // Still set booking so user is not stuck
      setCurrentBooking(bookingData);
      return true;
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    booking: currentBooking,
    status,
    setStatus,
    isSubmitting,
    error,
    submitBooking,
  };
}
