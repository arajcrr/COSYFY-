import { useState, useEffect, useMemo } from 'react';
import { Property, FilterState } from '../types';
import { fetchAllProperties, filterProperties } from '../services/airtable';

const initialFilters: FilterState = {
  destination: '',
  region: 'All',
  priceRange: [500, 15000],
  guests: 1,
  amenities: [],
  wfhReady: false,
  notOnAirbnb: false,
  sortBy: 'recommended',
};

export function useProperties(customFilters?: Partial<FilterState>) {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<FilterState>({
    ...initialFilters,
    ...customFilters,
  });

  const loadProperties = async (forceRefresh = false) => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchAllProperties(forceRefresh);
      setProperties(data);
    } catch (err: any) {
      setError(err?.message || 'Failed to load properties');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProperties();
  }, []);

  const filtered = useMemo(() => {
    const list = filterProperties(properties, filters);

    // Apply sorting
    return [...list].sort((a, b) => {
      if (filters.sortBy === 'price-asc') return a.weekdayPrice - b.weekdayPrice;
      if (filters.sortBy === 'price-desc') return b.weekdayPrice - a.weekdayPrice;
      if (filters.sortBy === 'rating') return b.rating - a.rating;
      // Default: recommended (featured first, then rating)
      if (a.featured && !b.featured) return -1;
      if (!a.featured && b.featured) return 1;
      return b.rating - a.rating;
    });
  }, [properties, filters]);

  const updateFilters = (newFilters: Partial<FilterState>) => {
    setFilters((prev) => ({ ...prev, ...newFilters }));
  };

  const resetFilters = () => {
    setFilters(initialFilters);
  };

  return {
    properties: filtered,
    allProperties: properties,
    loading,
    error,
    filters,
    updateFilters,
    resetFilters,
    refresh: () => loadProperties(true),
  };
}
