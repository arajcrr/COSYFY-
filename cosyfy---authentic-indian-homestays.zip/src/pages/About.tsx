import React from 'react';
import { Heart, Compass, ShieldCheck, Users, Sparkles, CheckCircle2 } from 'lucide-react';
import { CosyfyLogo } from '../components/common/CosyfyLogo';
import { useLanguage } from '../context/LanguageContext';

export const About: React.FC = () => {
  const { tagline } = useLanguage();
  const values = [
    {
      title: 'Honesty',
      desc: 'No sneaky checkout fees, no inflated cleaning markups, and no artificial scarcity timers. What you see is exactly what your host family receives.',
      icon: ShieldCheck,
    },
    {
      title: 'Discovery',
      desc: 'We explore deep into interior valleys, tea estates, and coastal fishing hamlets to find ancestral homes that aren’t listed on major corporate OTAs.',
      icon: Compass,
    },
    {
      title: 'Personal Touch',
      desc: 'When you message Cosyfy, you talk to real travelers based in Kullu and Bangalore who know the road conditions, the hosts, and the best breakfast spots.',
      icon: Heart,
    },
    {
      title: 'Indian Soul',
      desc: 'True hospitality in India is rooted in "Atithi Devo Bhava". It means eating hot siddu by a woodfire, chatting with grandmothers, and feeling at home.',
      icon: Sparkles,
    },
  ];

  const verificationSteps = [
    {
      step: '01',
      title: 'Owner Video Call & Verification',
      desc: 'We interview the host family to understand their story, household ethos, and whether they genuinely live on the property.',
    },
    {
      step: '02',
      title: 'Address & ID Cross-Checking',
      desc: 'Every homestay host submits government ID and electric/property bills to ensure guest safety and legal compliance.',
    },
    {
      step: '03',
      title: 'Bed, Bath & Hot Water Audit',
      desc: 'We verify mattress firmness, bathroom cleanliness, geyser capacity, and drinking water sources.',
    },
    {
      step: '04',
      title: 'Network & Speed Testing',
      desc: 'Live speed tests on WiFi and carrier signals (Airtel/Jio) are recorded during peak hours for all workation-ready tags.',
    },
    {
      step: '05',
      title: 'Continuous Guest Feedback',
      desc: 'We check in with guests after their first night on WhatsApp to ensure everything matches our standard.',
    },
  ];

  return (
    <div className="space-y-20 pb-20">
      {/* 1. Hero */}
      <section className="bg-[#2D5016] text-white py-20 sm:py-28 text-center relative overflow-hidden">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-5 relative z-10">
          <span className="text-xs font-bold uppercase tracking-widest text-emerald-300 bg-white/10 px-3.5 py-1.5 rounded-full inline-block">
            Our Story & Purpose
          </span>
          <h1 className="text-3xl sm:text-5xl md:text-6xl font-bold font-display tracking-tight text-white">
            Why We Built Cosyfy
          </h1>
          <p className="text-base sm:text-xl text-stone-200 max-w-2xl mx-auto font-light leading-relaxed">
            We were tired of booking platforms that treated India like a commercial checkbox and travelers like numbers.
          </p>
        </div>
      </section>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
        {/* 2. Founder Story */}
        <section id="founder-story" className="bg-white rounded-3xl p-8 sm:p-14 border border-stone-200 shadow-sm space-y-6">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#C84B31]">
            <span>From Our Founders</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-bold text-stone-900 font-display">
            A Platform Born from Cold Himalayan Nights & Real Chai
          </h2>

          <div className="prose prose-stone text-xs sm:text-sm text-stone-700 leading-relaxed space-y-4">
            <p>
              In 2023, while traveling through remote villages in the Kullu Valley, we booked an accommodation through a famous global booking app. When we arrived after a 12-hour mountain drive, we discovered the "quaint heritage cottage" was actually a concrete commercial hotel room. The WiFi was dead, the owner was nowhere to be found, and we were charged an extra 18% service fee for "platform guarantees."
            </p>
            <p>
              The next morning, exhausted, we walked down a narrow stone path into Naggar village. We met an elderly orchardist named Chandi uncle. He invited us onto his wooden veranda, gave us hot ginger chai, and offered us an upstairs room in his ancestral timber house.
            </p>
            <p>
              We ended up staying with his family for three weeks. We ate fresh siddu stuffed with poppy seeds, worked with 120 Mbps fiber internet overlooking snow peaks, and paid half of what hotel aggregators were asking.
            </p>
            <p className="font-semibold text-stone-900">
              We realized: India’s best homestays aren't on corporate algorithms. They belong to local families who love hosting, but don't want to lose excessive platform cuts to foreign tech giants.
            </p>
            <p>
              That’s why we created <strong>COSYFY</strong> — an authentic Indian homestay network with zero service fees, personally inspected homes, and a human team who answers your questions on WhatsApp within two hours.
            </p>
          </div>
        </section>

        {/* 3. Mission Statement */}
        <section className="text-center py-6 space-y-3 border-y border-stone-200">
          <p className="text-xs uppercase font-bold tracking-widest text-[#2D5016]">Our Mission</p>
          <h2 className="text-2xl sm:text-4xl md:text-5xl font-bold text-[#1A1A1A] font-display max-w-3xl mx-auto leading-tight">
            &ldquo;India's most personal homestay booking experience.&rdquo;
          </h2>
          <p className="text-sm font-semibold text-[#C84B31] font-serif italic max-w-lg mx-auto">
            &ldquo;{tagline}&rdquo;
          </p>
          <p className="text-xs text-stone-500 max-w-md mx-auto">
            Rooted in regional culture, transparent pricing, and genuine host families.
          </p>
        </section>

        {/* 4. Values (4 Cards) */}
        <section className="space-y-8">
          <div className="text-center space-y-2">
            <h3 className="text-2xl sm:text-3xl font-bold text-stone-900 font-display">
              The Principles That Guide Us
            </h3>
            <p className="text-xs sm:text-sm text-stone-600">
              What we stand for every time a guest messages us.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {values.map((v) => {
              const Icon = v.icon;
              return (
                <div
                  key={v.title}
                  className="bg-white p-7 rounded-3xl border border-stone-200/90 shadow-sm space-y-3"
                >
                  <div className="w-12 h-12 rounded-2xl bg-[#2D5016]/10 text-[#2D5016] flex items-center justify-center">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h4 className="text-lg font-bold text-stone-900 font-display">{v.title}</h4>
                  <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">{v.desc}</p>
                </div>
              );
            })}
          </div>
        </section>

        {/* 5. How We Verify Properties (5 Steps) */}
        <section id="verification" className="bg-stone-100/70 rounded-3xl p-8 sm:p-12 border border-stone-200 space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold uppercase tracking-widest text-[#2D5016]">
              Quality Assurance
            </span>
            <h3 className="text-2xl sm:text-3xl font-bold text-stone-900 font-display">
              Our 5-Step Verification Protocol
            </h3>
            <p className="text-xs sm:text-sm text-stone-600">
              We never add a homestay without completing this exact checklist.
            </p>
          </div>

          <div className="space-y-4">
            {verificationSteps.map((step) => (
              <div
                key={step.step}
                className="bg-white p-5 rounded-2xl border border-stone-200 flex items-start gap-4 shadow-xs"
              >
                <div className="w-9 h-9 rounded-xl bg-[#2D5016] text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                  {step.step}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-stone-900">{step.title}</h4>
                  <p className="text-xs text-stone-600 mt-1 leading-relaxed">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 6. The Team Section */}
        <section className="text-center space-y-8">
          <div className="space-y-2">
            <h3 className="text-2xl sm:text-3xl font-bold text-stone-900 font-display">
              The Team Behind Cosyfy
            </h3>
            <p className="text-xs sm:text-sm text-stone-600">
              Passionate travelers, engineers, and mountain natives building for India.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 max-w-2xl mx-auto">
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm text-center space-y-3">
              <div className="w-20 h-20 rounded-full bg-[#2D5016]/10 text-[#2D5016] font-bold text-2xl flex items-center justify-center mx-auto border-2 border-[#2D5016]/20">
                CR
              </div>
              <h4 className="text-base font-bold text-stone-900 font-display">Avnish Raj</h4>
              <p className="text-xs text-stone-500">Co-Founder & Technology</p>
              <p className="text-[11px] text-stone-600 leading-snug">
                Built the core booking platform to ensure seamless real-time syncing and zero-fee reservations for Indian travelers.
              </p>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm text-center space-y-3">
              <div className="w-20 h-20 rounded-full bg-[#C84B31]/10 text-[#C84B31] font-bold text-2xl flex items-center justify-center mx-auto border-2 border-[#C84B31]/20">
                HP
              </div>
              <h4 className="text-base font-bold text-stone-900 font-display">Host Partnerships</h4>
              <p className="text-xs text-stone-500">Ground Operations • Himachal & South India</p>
              <p className="text-[11px] text-stone-600 leading-snug">
                Coordinates directly with host families across Kullu, Tirthan, Landour, and Coorg to inspect rooms and arrange home meals.
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
