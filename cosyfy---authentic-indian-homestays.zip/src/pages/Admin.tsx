import React, { useState, useEffect } from 'react';
import {
  Shield,
  LayoutDashboard,
  Calendar,
  Home,
  Settings,
  Lock,
  LogOut,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useProperties } from '../hooks/useProperties';
import { Booking, BookingStatus, Property } from '../types';
import { Dashboard } from '../components/admin/Dashboard';
import { BookingManager } from '../components/admin/BookingManager';
import { PropertyManager } from '../components/admin/PropertyManager';
import { ContentManager } from '../components/admin/ContentManager';
import { updateAirtableBookingStatus } from '../services/airtable';
import { doc, updateDoc, collection, getDocs } from 'firebase/firestore';
import { db } from '../services/firebase';

export const Admin: React.FC = () => {
  const { user, isAdmin } = useAuth();
  const { allProperties } = useProperties();

  const [authed, setAuthed] = useState<boolean>(() => {
    return localStorage.getItem('cosyfy_admin_authed') === 'true';
  });
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'bookings' | 'properties' | 'content'>('dashboard');

  const [bookings, setBookings] = useState<Booking[]>([
    {
      id: 'bk-demo-1',
      bookingReference: 'BK-COSY-9482',
      propertyName: "Chandi's Apple Orchard Heritage",
      propertyLocation: 'Naggar, Manali',
      checkIn: '2024-11-20',
      checkOut: '2024-11-25',
      adults: 2,
      children: 0,
      nights: 5,
      pricePerNight: 2400,
      basePrice: 12000,
      cleaningFee: 0,
      totalPrice: 12000,
      advanceDeposit: 1200,
      status: 'pending',
      guestName: 'Vikas Malhotra',
      guestPhone: '9812345678',
      guestEmail: 'vikas.m@gmail.com',
      guestCity: 'Delhi',
      groupType: 'Couple',
      dietary: 'Veg',
      createdAt: new Date().toISOString(),
      propertyId: 'prop-chandi-apple-retreat',
    },
    {
      id: 'bk-demo-2',
      bookingReference: 'BK-COSY-7129',
      propertyName: 'Tirthan River Whispers',
      propertyLocation: 'Gushaini, Tirthan Valley',
      checkIn: '2024-12-02',
      checkOut: '2024-12-09',
      adults: 2,
      children: 0,
      nights: 7,
      pricePerNight: 2800,
      basePrice: 19600,
      cleaningFee: 0,
      totalPrice: 19600,
      advanceDeposit: 1960,
      status: 'confirmed',
      guestName: 'Sneha Kapoor',
      guestPhone: '9876543210',
      guestEmail: 'sneha.kapoor@gmail.com',
      guestCity: 'Mumbai',
      groupType: 'Solo',
      dietary: 'Non-Veg',
      createdAt: new Date().toISOString(),
      propertyId: 'prop-tirthan-riverside-cottage',
    },
  ]);

  // Load Firestore bookings if available
  useEffect(() => {
    async function loadFirebaseBookings() {
      try {
        const snap = await getDocs(collection(db, 'bookings'));
        const list: Booking[] = [];
        snap.forEach((d) => list.push(d.data() as Booking));
        if (list.length > 0) {
          setBookings(list);
        }
      } catch (err) {
        console.warn('Admin booking load notice:', err);
      }
    }
    loadFirebaseBookings();
  }, []);

  const adminPass = import.meta.env.VITE_ADMIN_PASSWORD || 'cosyfy2024';

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === adminPass) {
      setAuthed(true);
      localStorage.setItem('cosyfy_admin_authed', 'true');
      setPasswordError(false);
    } else {
      setPasswordError(true);
    }
  };

  const handleLogoutAdmin = () => {
    setAuthed(false);
    localStorage.removeItem('cosyfy_admin_authed');
  };

  const handleUpdateStatus = async (
    bookingId: string,
    ref: string,
    newStatus: BookingStatus
  ) => {
    // 1. Update in local state
    setBookings((prev) =>
      prev.map((b) => (b.bookingReference === ref ? { ...b, status: newStatus } : b))
    );

    // 2. Update in Airtable
    await updateAirtableBookingStatus(bookingId, newStatus);

    // 3. Update in Firestore
    try {
      await updateDoc(doc(db, 'bookings', ref), {
        status: newStatus,
        updatedAt: new Date().toISOString(),
      });
    } catch (e) {
      console.warn('Firestore booking status update:', e);
    }
  };

  // Check if authenticated either by password or by Google/Firebase admin role
  const isAuthorized = authed || isAdmin;

  if (!isAuthorized) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-3xl p-8 border border-stone-200 shadow-xl space-y-6 text-center">
          <div className="w-16 h-16 rounded-full bg-amber-50 text-amber-700 flex items-center justify-center mx-auto">
            <Shield className="w-8 h-8" />
          </div>

          <div className="space-y-1">
            <h1 className="text-xl font-bold font-display text-stone-900">
              Cosyfy Host & Admin Portal
            </h1>
            <p className="text-xs text-stone-500">
              Restricted management area for property listings & bookings
            </p>
          </div>

          {passwordError && (
            <div className="p-3 rounded-xl bg-red-50 text-xs text-red-700 border border-red-200 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>Incorrect password. Default: cosyfy2024</span>
            </div>
          )}

          <form onSubmit={handlePasswordSubmit} className="space-y-4 text-xs text-left">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Admin Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                <input
                  type="password"
                  placeholder="Enter admin password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-[#2D5016] text-white font-bold text-xs hover:bg-[#1F380F] shadow-sm"
            >
              Unlock Dashboard
            </button>
          </form>

          <p className="text-[11px] text-stone-400">
            Note: If logged in as admin email (avnish.raj.crr@gmail.com), access is unlocked automatically.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Admin Top Header */}
      <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#2D5016] text-white flex items-center justify-center font-bold">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold font-display text-stone-900">
              Cosyfy Operations Hub
            </h1>
            <p className="text-xs text-stone-500">
              Airtable & Webhook Integration Control Center
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleLogoutAdmin}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:text-stone-900 border border-stone-200"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Lock Admin</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-stone-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'dashboard'
              ? 'bg-[#2D5016] text-white shadow-xs'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Dashboard</span>
        </button>

        <button
          onClick={() => setActiveTab('bookings')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'bookings'
              ? 'bg-[#2D5016] text-white shadow-xs'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Bookings ({bookings.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('properties')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'properties'
              ? 'bg-[#2D5016] text-white shadow-xs'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Home className="w-4 h-4" />
          <span>Properties ({allProperties.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('content')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'content'
              ? 'bg-[#2D5016] text-white shadow-xs'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>Content & Brand</span>
        </button>
      </div>

      {/* Active Tab Panel */}
      <div>
        {activeTab === 'dashboard' && (
          <Dashboard
            bookings={bookings}
            properties={allProperties}
            onSelectTab={(tab) => setActiveTab(tab)}
          />
        )}

        {activeTab === 'bookings' && (
          <BookingManager
            bookings={bookings}
            onUpdateStatus={handleUpdateStatus}
          />
        )}

        {activeTab === 'properties' && (
          <PropertyManager
            properties={allProperties}
            onToggleActive={(id) => {
              // demo toggle
              alert(`Toggled active status for property ${id}`);
            }}
          />
        )}

        {activeTab === 'content' && <ContentManager />}
      </div>
    </div>
  );
};
