import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Home,
  Calendar,
  Building,
  Users,
  Wallet,
  LogOut,
  Search,
  CheckCircle2,
  XCircle,
  Eye,
  Plus,
  MessageCircle,
  Menu,
  X,
  TrendingUp,
  Download,
} from 'lucide-react';
import { CosyfyLogo } from '../components/common/CosyfyLogo';
import {
  getActiveSession,
  logoutUser,
  logAuditAction,
  getStoredEmployees,
} from '../services/auth';
import {
  getAdminBookings,
  saveAdminBookings,
  updateAdminBooking,
  getAdminCustomers,
  saveAdminCustomers,
  updateAdminCustomer,
  getAdminProperties,
  saveAdminProperties,
  getOwnerPayouts,
  saveOwnerPayouts,
  getPropertyLeads,
  updatePropertyLead,
  PropertyLead,
  AdminBooking,
  AdminCustomer,
  AdminPropertyItem,
  OwnerPayout,
} from '../services/adminData';
import { PropertyOnboardingWizard } from '../components/admin/PropertyOnboardingWizard';
import { formatPrice, getWhatsAppUrl } from '../utils';

type AdminTab = 'dashboard' | 'bookings' | 'properties' | 'customers' | 'payouts';

export const AdminPortal: React.FC = () => {
  const navigate = useNavigate();
  const session = getActiveSession();

  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [bookings, setBookings] = useState<AdminBooking[]>(() => getAdminBookings());
  const [customers, setCustomers] = useState<AdminCustomer[]>(() => getAdminCustomers());
  const [properties, setProperties] = useState<AdminPropertyItem[]>(() => getAdminProperties());
  const [payouts, setPayouts] = useState<OwnerPayout[]>(() => getOwnerPayouts());
  const [propertyLeads, setPropertyLeads] = useState<PropertyLead[]>(() => getPropertyLeads());
  const [isAddPropertyOpen, setIsAddPropertyOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState<AdminPropertyItem | null>(null);
  const [selectedLeadToOnboard, setSelectedLeadToOnboard] = useState<PropertyLead | null>(null);
  const [propertySubTab, setPropertySubTab] = useState<'listings' | 'leads'>('listings');
  const employees = getStoredEmployees();

  // Booking search/filter
  const [bookingSearch, setBookingSearch] = useState('');
  const [inspectBooking, setInspectBooking] = useState<AdminBooking | null>(null);

  // Customer search
  const [customerSearch, setCustomerSearch] = useState('');

  const handleLogout = () => {
    logoutUser();
    navigate('/login', { replace: true });
  };

  const handleApproveBooking = (bookingId: string) => {
    const updated = updateAdminBooking(bookingId, { status: 'confirmed' });
    setBookings(updated);
    if (session) {
      logAuditAction(
        session.user.id,
        session.user.name,
        session.user.role,
        'BOOKING_APPROVED_BY_ADMIN',
        `Admin approved booking ${bookingId}`
      );
    }
  };

  const handleDeclineBooking = (bookingId: string) => {
    const updated = updateAdminBooking(bookingId, { status: 'cancelled' });
    setBookings(updated);
    if (session) {
      logAuditAction(
        session.user.id,
        session.user.name,
        session.user.role,
        'BOOKING_DECLINED_BY_ADMIN',
        `Admin declined booking ${bookingId}`
      );
    }
  };

  const handleMarkPayoutPaid = (payoutId: string) => {
    const updated = payouts.map((p) =>
      p.id === payoutId
        ? {
            ...p,
            payoutStatus: 'Processed' as const,
            payoutDate: new Date().toISOString().split('T')[0],
          }
        : p
    );
    saveOwnerPayouts(updated);
    setPayouts(updated);
  };

  const pendingApprovalsCount = bookings.filter((b) => b.status === 'pending').length;
  const activeBookingsCount = bookings.filter((b) => b.status === 'confirmed').length;

  return (
    <div className="min-h-screen bg-[#F8F6F0] flex flex-col md:flex-row text-stone-900 font-sans">
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-[#111c24] text-stone-300 border-r border-stone-800 shrink-0">
        <div className="p-6 border-b border-stone-800/80 flex items-center justify-between">
          <div className="bg-white p-2 rounded-xl">
            <CosyfyLogo size="sm" />
          </div>
          <span className="text-[10px] font-bold uppercase tracking-wider bg-blue-950 text-blue-300 border border-blue-800 px-2 py-0.5 rounded">
            Admin
          </span>
        </div>

        <div className="px-6 py-4 border-b border-stone-800/80 bg-stone-900/40">
          <p className="text-xs font-bold text-white truncate">{session?.user.name}</p>
          <p className="text-[11px] text-stone-400 truncate">{session?.user.email}</p>
          <span className="inline-block mt-1 text-[10px] font-semibold text-emerald-400">
            Operations Manager
          </span>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'dashboard'
                ? 'bg-[#2D5016] text-white font-bold'
                : 'text-stone-300 hover:bg-stone-800 hover:text-white'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Operations Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('bookings')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'bookings'
                ? 'bg-[#2D5016] text-white font-bold'
                : 'text-stone-300 hover:bg-stone-800 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <Calendar className="w-4 h-4" />
              <span>Bookings Pipeline</span>
            </div>
            {pendingApprovalsCount > 0 && (
              <span className="text-[10px] bg-amber-500 text-stone-900 px-1.5 py-0.5 rounded font-bold">
                {pendingApprovalsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('properties')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'properties'
                ? 'bg-[#2D5016] text-white font-bold'
                : 'text-stone-300 hover:bg-stone-800 hover:text-white'
            }`}
          >
            <Building className="w-4 h-4" />
            <span>Property Directory</span>
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'customers'
                ? 'bg-[#2D5016] text-white font-bold'
                : 'text-stone-300 hover:bg-stone-800 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Guest Enquiries & Leads</span>
          </button>

          <button
            onClick={() => setActiveTab('payouts')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'payouts'
                ? 'bg-[#2D5016] text-white font-bold'
                : 'text-stone-300 hover:bg-stone-800 hover:text-white'
            }`}
          >
            <Wallet className="w-4 h-4" />
            <span>Host Remittances</span>
          </button>
        </nav>

        <div className="p-4 border-t border-stone-800">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-rose-400 hover:bg-rose-950/40 text-xs font-bold"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Mobile Topbar */}
      <div className="md:hidden bg-[#111c24] text-white px-4 py-3 flex items-center justify-between border-b border-stone-800 sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <div className="bg-white p-1 rounded-lg">
            <CosyfyLogo size="sm" />
          </div>
          <span className="text-[10px] font-bold bg-blue-900 text-blue-200 px-1.5 py-0.5 rounded">
            Admin Portal
          </span>
        </div>
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2 rounded-lg bg-stone-800 text-stone-200"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden bg-[#111c24] text-white border-b border-stone-800 p-4 space-y-2 z-40 fixed top-14 left-0 right-0">
          {[
            { id: 'dashboard', label: 'Operations Dashboard', icon: Home },
            { id: 'bookings', label: 'Bookings Pipeline', icon: Calendar },
            { id: 'properties', label: 'Properties', icon: Building },
            { id: 'customers', label: 'Customers', icon: Users },
            { id: 'payouts', label: 'Host Remittances', icon: Wallet },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id as AdminTab);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold ${
                  activeTab === item.id ? 'bg-[#2D5016] text-white font-bold' : 'text-stone-300'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2 text-rose-400 text-xs font-bold pt-2 border-t border-stone-800"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 p-4 sm:p-8 lg:p-10 overflow-y-auto max-w-7xl mx-auto w-full space-y-8">
        {activeTab === 'dashboard' && (
          <div className="space-y-6 animate-in fade-in">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
                Operations Management Dashboard
              </h1>
              <p className="text-xs text-stone-500 mt-1">
                Monitor day-to-day stay confirmations, host liaisons, and concierge tasks
              </p>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-3xl border border-stone-200/90 shadow-sm space-y-1">
                <span className="text-[11px] uppercase font-bold text-stone-400">Awaiting Approval</span>
                <h3 className="text-2xl font-extrabold text-amber-700 font-display">
                  {pendingApprovalsCount} Stays
                </h3>
                <span className="text-[11px] text-stone-500">Host call required</span>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-stone-200/90 shadow-sm space-y-1">
                <span className="text-[11px] uppercase font-bold text-stone-400">Confirmed Stays</span>
                <h3 className="text-2xl font-extrabold text-[#2D5016] font-display">
                  {activeBookingsCount}
                </h3>
                <span className="text-[11px] text-stone-500">Dispatched to WhatsApp</span>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-stone-200/90 shadow-sm space-y-1">
                <span className="text-[11px] uppercase font-bold text-stone-400">Active Properties</span>
                <h3 className="text-2xl font-extrabold text-stone-900 font-display">
                  {properties.filter((p) => p.isActive).length}
                </h3>
                <span className="text-[11px] text-[#2D5016] font-semibold">Ready for booking</span>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-stone-200/90 shadow-sm space-y-1">
                <span className="text-[11px] uppercase font-bold text-stone-400">Enquiries in Pipeline</span>
                <h3 className="text-2xl font-extrabold text-blue-900 font-display">
                  {customers.filter((c) => c.leadStatus !== 'Lost').length}
                </h3>
                <span className="text-[11px] text-stone-500">Concierge handling</span>
              </div>
            </div>

            {/* Quick Actions Panel */}
            <div className="bg-white p-6 rounded-3xl border border-stone-200/90 shadow-sm space-y-4">
              <h3 className="text-base font-bold text-stone-900 font-display">
                Urgent Operations Tasks
              </h3>
              <div className="divide-y divide-stone-100 text-xs">
                {bookings
                  .filter((b) => b.status === 'pending')
                  .map((b) => (
                    <div
                      key={b.id}
                      className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-stone-900">{b.id}</span>
                          <span className="text-stone-700 font-semibold">• {b.customerName}</span>
                          <span className="text-stone-500">({b.propertyName})</span>
                        </div>
                        <p className="text-[11px] text-stone-500 mt-0.5">
                          Dates: {b.checkIn} to {b.checkOut} ({b.nights} nights) • {formatPrice(b.totalAmount)}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleApproveBooking(b.id)}
                          className="px-3 py-1.5 rounded-xl bg-[#2D5016] text-white font-bold text-xs"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => handleDeclineBooking(b.id)}
                          className="px-3 py-1.5 rounded-xl bg-rose-600 text-white font-bold text-xs"
                        >
                          Decline
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}

        {/* BOOKINGS TAB */}
        {activeTab === 'bookings' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold font-display text-stone-900">
                Operations Bookings Pipeline
              </h1>
            </div>

            <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-stone-50 border-b border-stone-200 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                  <tr>
                    <th className="p-4">ID</th>
                    <th className="p-4">Guest</th>
                    <th className="p-4">Property</th>
                    <th className="p-4">Dates</th>
                    <th className="p-4">Amount</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {bookings.map((b) => (
                    <tr key={b.id} className="hover:bg-stone-50">
                      <td className="p-4 font-mono font-bold text-stone-900">{b.id}</td>
                      <td className="p-4 font-semibold text-stone-900">{b.customerName}</td>
                      <td className="p-4 text-stone-700">{b.propertyName}</td>
                      <td className="p-4 text-stone-600">
                        {b.checkIn} to {b.checkOut}
                      </td>
                      <td className="p-4 font-bold text-stone-900">{formatPrice(b.totalAmount)}</td>
                      <td className="p-4">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            b.status === 'confirmed'
                              ? 'bg-emerald-100 text-[#2D5016]'
                              : b.status === 'pending'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {b.status.toUpperCase()}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        {b.status === 'pending' && (
                          <div className="flex justify-end gap-1.5">
                            <button
                              onClick={() => handleApproveBooking(b.id)}
                              className="px-2.5 py-1 rounded-lg bg-emerald-100 text-[#2D5016] font-bold text-[11px]"
                            >
                              Approve
                            </button>
                            <button
                              onClick={() => handleDeclineBooking(b.id)}
                              className="px-2.5 py-1 rounded-lg bg-rose-100 text-rose-700 font-bold text-[11px]"
                            >
                              Decline
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* PROPERTIES TAB */}
        {activeTab === 'properties' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold font-display text-stone-900">
                  Verified Properties & Host Onboarding
                </h1>
                <p className="text-xs text-stone-500 mt-1">
                  Manage homestay listings or launch the 7-step host onboarding wizard.
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingProperty(null);
                  setSelectedLeadToOnboard(null);
                  setIsAddPropertyOpen(true);
                }}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#2D5016] text-white text-xs font-bold shadow-md hover:bg-[#1f380f]"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Property (7-Step Wizard)</span>
              </button>
            </div>

            {/* Sub-tab navigation */}
            <div className="flex items-center gap-3 border-b border-stone-200 pb-2">
              <button
                onClick={() => setPropertySubTab('listings')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  propertySubTab === 'listings'
                    ? 'bg-[#2D5016] text-white shadow-sm'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                Verified Listings ({properties.length})
              </button>
              <button
                onClick={() => setPropertySubTab('leads')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                  propertySubTab === 'leads'
                    ? 'bg-[#2D5016] text-white shadow-sm'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                <span>Host Enquiries / Leads</span>
                <span className="px-1.5 py-0.2 rounded-full bg-emerald-100 text-[#2D5016] text-[10px]">
                  {propertyLeads.length}
                </span>
              </button>
            </div>

            {propertySubTab === 'listings' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {properties.map((p) => (
                  <div
                    key={p.id}
                    className="bg-white rounded-3xl border border-stone-200/90 overflow-hidden shadow-sm space-y-3 p-5"
                  >
                    <img
                      src={p.mainImage}
                      alt={p.name}
                      className="w-full h-40 object-cover rounded-2xl"
                    />
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono text-stone-400 font-bold">{p.id}</span>
                        <button
                          onClick={() => {
                            setEditingProperty(p);
                            setSelectedLeadToOnboard(null);
                            setIsAddPropertyOpen(true);
                          }}
                          className="text-[11px] font-bold text-[#2D5016] hover:underline"
                        >
                          Edit Details
                        </button>
                      </div>
                      <h3 className="font-bold text-stone-900 font-display text-sm">{p.name}</h3>
                      <p className="text-xs text-stone-500">{p.location}</p>
                    </div>
                    <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                      <span className="font-bold text-stone-900">{formatPrice(p.weekdayPrice)} / night</span>
                      <a
                        href={getWhatsAppUrl(p.ownerWhatsapp.replace(/\D/g, ''), `Namaste ${p.ownerName}!`)}
                        target="_blank"
                        rel="noreferrer"
                        className="text-emerald-700 font-bold hover:underline flex items-center gap-1"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>{p.ownerName}</span>
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              /* HOST ENQUIRIES / LEADS TABLE */
              <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden">
                <div className="p-4 bg-stone-50 border-b border-stone-200 flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-stone-900 text-sm">
                      Host Enquiries & Property Leads (Airtable Sync)
                    </h3>
                    <p className="text-xs text-stone-500">
                      Submissions from the public "/list-your-property" portal. Review and onboard into verified listings.
                    </p>
                  </div>
                </div>

                <div className="overflow-x-auto text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-stone-50 border-b border-stone-200 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                      <tr>
                        <th className="p-4">Lead ID</th>
                        <th className="p-4">Owner & Contact</th>
                        <th className="p-4">Property</th>
                        <th className="p-4">Location</th>
                        <th className="p-4">Units & Rate</th>
                        <th className="p-4">Call Window</th>
                        <th className="p-4">Status</th>
                        <th className="p-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {propertyLeads.map((lead) => (
                        <tr key={lead.id} className="hover:bg-stone-50">
                          <td className="p-4 font-mono font-bold text-stone-800">{lead.id}</td>
                          <td className="p-4">
                            <p className="font-bold text-stone-900">{lead.ownerName}</p>
                            <a
                              href={getWhatsAppUrl(
                                lead.whatsapp,
                                `Namaste ${lead.ownerName}! Following up on your Cosyfy property submission for ${lead.propertyName}:`
                              )}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[11px] text-emerald-700 font-semibold hover:underline flex items-center gap-1 mt-0.5"
                            >
                              <MessageCircle className="w-3 h-3" />
                              <span>{lead.mobile}</span>
                            </a>
                          </td>
                          <td className="p-4">
                            <p className="font-bold text-stone-900">{lead.propertyName}</p>
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-stone-100 text-stone-600 font-semibold">
                              {lead.propertyType}
                            </span>
                          </td>
                          <td className="p-4">
                            <p className="font-semibold text-stone-800">{lead.district}</p>
                            <p className="text-[11px] text-stone-500">{lead.state}</p>
                          </td>
                          <td className="p-4">
                            <span className="font-bold text-stone-900">{lead.roomsCount} units</span>
                            <span className="text-[11px] text-stone-500 block">{lead.priceRange}</span>
                          </td>
                          <td className="p-4 text-stone-700 font-medium">{lead.bestTimeToCall}</td>
                          <td className="p-4">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                lead.status === 'Onboarded'
                                  ? 'bg-emerald-100 text-[#2D5016]'
                                  : lead.status === 'Contacted'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {lead.status}
                            </span>
                          </td>
                          <td className="p-4 text-right">
                            <button
                              onClick={() => {
                                setEditingProperty(null);
                                setSelectedLeadToOnboard(lead);
                                setIsAddPropertyOpen(true);
                              }}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#2D5016] text-white text-xs font-bold hover:bg-[#1f380f] shadow-xs"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              <span>Onboard Host (7-Step Wizard)</span>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* 7-STEP VERIFIED PROPERTY ONBOARDING WIZARD */}
            <PropertyOnboardingWizard
              isOpen={isAddPropertyOpen || !!editingProperty}
              onClose={() => {
                setIsAddPropertyOpen(false);
                setEditingProperty(null);
                setSelectedLeadToOnboard(null);
              }}
              initialData={editingProperty}
              fromLead={selectedLeadToOnboard}
              onSave={(savedProperty) => {
                if (editingProperty) {
                  const updated = properties.map((p) =>
                    p.id === editingProperty.id ? savedProperty : p
                  );
                  saveAdminProperties(updated);
                  setProperties(updated);
                  setEditingProperty(null);
                } else {
                  const updated = [savedProperty, ...properties];
                  saveAdminProperties(updated);
                  setProperties(updated);
                  setIsAddPropertyOpen(false);
                  if (selectedLeadToOnboard) {
                    const updatedLeads = updatePropertyLead(selectedLeadToOnboard.id, {
                      status: 'Onboarded',
                    });
                    setPropertyLeads(updatedLeads);
                    setSelectedLeadToOnboard(null);
                  }
                }
              }}
            />
          </div>
        )}

        {/* CUSTOMERS TAB */}
        {activeTab === 'customers' && (
          <div className="space-y-6 animate-in fade-in">
            <h1 className="text-2xl font-bold font-display text-stone-900">
              Guest Enquiries & Lead Pipeline
            </h1>
            <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-stone-50 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                  <tr>
                    <th className="p-4">Customer</th>
                    <th className="p-4">Phone / WhatsApp</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">Destination</th>
                    <th className="p-4">Assigned Agent</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {customers.map((c) => (
                    <tr key={c.id} className="hover:bg-stone-50">
                      <td className="p-4 font-semibold text-stone-900">{c.name}</td>
                      <td className="p-4 text-emerald-700 font-medium">{c.phone}</td>
                      <td className="p-4">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-stone-100 text-stone-700">
                          {c.leadStatus}
                        </span>
                      </td>
                      <td className="p-4 text-stone-600">{c.destinationInterested}</td>
                      <td className="p-4 text-stone-600 font-medium">{c.assignedEmployee}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* PAYOUTS TAB */}
        {activeTab === 'payouts' && (
          <div className="space-y-6 animate-in fade-in">
            <h1 className="text-2xl font-bold font-display text-stone-900">
              Host Remittance Records
            </h1>
            <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-stone-50 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                  <tr>
                    <th className="p-4">Payout ID</th>
                    <th className="p-4">Homestay</th>
                    <th className="p-4">Host</th>
                    <th className="p-4">Net Remittance</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {payouts.map((p) => (
                    <tr key={p.id} className="hover:bg-stone-50">
                      <td className="p-4 font-mono font-bold text-stone-900">{p.id}</td>
                      <td className="p-4 text-stone-900 font-semibold">{p.propertyName}</td>
                      <td className="p-4 text-stone-600">{p.ownerName} ({p.ownerUpi})</td>
                      <td className="p-4 font-extrabold text-[#C84B31]">{formatPrice(p.netPayoutAmount)}</td>
                      <td className="p-4">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-stone-100 text-stone-700">
                          {p.payoutStatus}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        {p.payoutStatus === 'Pending' ? (
                          <button
                            onClick={() => handleMarkPayoutPaid(p.id)}
                            className="px-3 py-1.5 rounded-xl bg-[#2D5016] text-white font-bold text-[11px]"
                          >
                            Mark Paid
                          </button>
                        ) : (
                          <span className="text-stone-400">Settled</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
