import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { differenceInDays, parseISO } from 'date-fns';
import {
  ShieldCheck,
  Calendar,
  Users,
  MessageCircle,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Lock,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Smartphone,
  CreditCard,
  Building,
  Wallet,
  Loader2,
  Sparkles,
  Info,
} from 'lucide-react';
import { fetchPropertyById, fetchAllProperties } from '../services/airtable';
import { Property, Booking } from '../types';
import { useAuth } from '../context/AuthContext';
import { useBooking } from '../hooks/useBooking';
import { generateBookingId, formatPrice, validateIndianPhone } from '../utils';
import { WaitingConfirmation } from '../components/booking/WaitingConfirmation';
import { SuccessScreen } from '../components/booking/SuccessScreen';
import { AlternativesScreen } from '../components/booking/AlternativesScreen';
import { PaymentModal } from '../components/booking/PaymentModal';
import { isRazorpayLive, openLiveRazorpayCheckout } from '../services/razorpay';

interface BookingFormData {
  fullName: string;
  phone: string;
  sameWhatsapp: boolean;
  whatsapp: string;
  email: string;
  city: string;
  groupType: 'Solo' | 'Couple' | 'Friends' | 'Family';
  dietary: 'Veg' | 'Non-Veg' | 'Vegan' | 'No preference';
  arrivalTime: string;
  specialRequests: string;
  source: string;
}

export const BookingRequest: React.FC = () => {
  const { propertyId } = useParams<{ propertyId: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, profile } = useAuth();

  const [property, setProperty] = useState<Property | null>(null);
  const [alternatives, setAlternatives] = useState<Property[]>([]);
  const [loadingProp, setLoadingProp] = useState(true);

  // Two-step flow state: Step 1 (Request Form) -> Step 2 (Payment Page)
  const [currentStep, setCurrentStep] = useState<1 | 2>(1);
  const [submittedFormData, setSubmittedFormData] = useState<BookingFormData | null>(null);

  // Cancellation policy collapsible state (default open for clear visibility)
  const [cancellationPolicyOpen, setCancellationPolicyOpen] = useState(true);

  // Payment form states
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking' | 'wallet'>('upi');
  const [upiId, setUpiId] = useState('user@okhdfcbank');
  const [cardNumber, setCardNumber] = useState('4532 •••• •••• 8910');
  const [cardExpiry, setCardExpiry] = useState('11/28');
  const [cardCvv, setCardCvv] = useState('•••');
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [showDedicatedModal, setShowDedicatedModal] = useState(false);

  const checkIn = searchParams.get('checkIn') || '';
  const checkOut = searchParams.get('checkOut') || '';
  const adults = Number(searchParams.get('guests')) || 2;
  const children = 0;

  // Nights calculation
  let nights = 3;
  try {
    const diff = differenceInDays(parseISO(checkOut), parseISO(checkIn));
    nights = diff > 0 ? diff : 1;
  } catch {
    nights = 3;
  }

  const { booking, status, setStatus, isSubmitting, submitBooking } = useBooking();

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<BookingFormData>({
    defaultValues: {
      fullName: profile?.fullName || '',
      phone: profile?.phone || '',
      sameWhatsapp: true,
      whatsapp: profile?.whatsapp || profile?.phone || '',
      email: profile?.email || user?.email || '',
      city: profile?.city || '',
      groupType: 'Couple',
      dietary: profile?.dietaryPreference || 'Veg',
      arrivalTime: '1:00 PM',
      specialRequests: '',
      source: 'Google Search',
    },
  });

  const sameWhatsapp = watch('sameWhatsapp');
  const phoneValue = watch('phone');

  useEffect(() => {
    if (sameWhatsapp) {
      setValue('whatsapp', phoneValue);
    }
  }, [sameWhatsapp, phoneValue, setValue]);

  useEffect(() => {
    async function load() {
      if (!propertyId) return;
      setLoadingProp(true);
      const data = await fetchPropertyById(propertyId);
      setProperty(data);

      const all = await fetchAllProperties();
      const others = all.filter((p) => p.id !== propertyId);
      setAlternatives(others);
      setLoadingProp(false);
    }
    load();
    window.scrollTo(0, 0);
  }, [propertyId]);

  if (loadingProp) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-24 text-center animate-pulse space-y-4">
        <div className="h-8 bg-stone-200 rounded w-1/3 mx-auto" />
        <div className="h-64 bg-stone-100 rounded-3xl" />
      </div>
    );
  }

  if (!property) {
    return (
      <div className="max-w-lg mx-auto px-4 py-24 text-center space-y-4">
        <h2 className="text-xl font-bold font-display text-stone-900">Stay Not Found</h2>
        <button onClick={() => navigate('/properties')} className="px-5 py-2 rounded-xl bg-[#2D5016] text-white text-xs">
          Back to Stays
        </button>
      </div>
    );
  }

  // If booking submitted and waiting, confirmed, or declined
  if (booking) {
    if (status === 'confirmed') {
      return <SuccessScreen booking={booking} />;
    }
    if (status === 'declined') {
      return <AlternativesScreen booking={booking} alternatives={alternatives} />;
    }
    return (
      <WaitingConfirmation
        booking={booking}
      />
    );
  }

  const isRemote = Boolean(property.remoteProperty);
  const ratePerNight = property.weekdayPrice;
  const stayCost = ratePerNight * nights;
  const cleaningFee = property.cleaningFee || 0;
  const totalCost = stayCost + cleaningFee;

  // Remote property requires 100% full payment; standard property requires 10% advance
  const advanceDeposit = isRemote ? totalCost : Math.round(totalCost * 0.1);
  const amountToPayNow = advanceDeposit;
  const remainingDueOnArrival = isRemote ? 0 : totalCost - advanceDeposit;

  // Step 1: Submit Form -> Advance to Step 2 Payment Page
  const onStep1Submit = (data: BookingFormData) => {
    setSubmittedFormData(data);
    setCurrentStep(2);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Step 2: Finalize Payment & Submit Booking
  const handleCompletePayment = async (customPaymentId?: string) => {
    if (!submittedFormData) return;
    setIsProcessingPayment(true);

    const paymentId =
      customPaymentId || `pay_cosy_${Math.random().toString(36).substring(2, 9).toUpperCase()}`;

    const bookingRef = generateBookingId();
    const newBooking: Booking = {
      id: bookingRef,
      bookingReference: bookingRef,
      userId: user?.uid,
      propertyId: property.id,
      propertyName: property.name,
      propertyLocation: property.location,
      checkIn: checkIn || new Date().toISOString().split('T')[0],
      checkOut: checkOut || new Date().toISOString().split('T')[0],
      adults,
      children,
      nights,
      pricePerNight: ratePerNight,
      basePrice: stayCost,
      cleaningFee,
      totalPrice: totalCost,
      advanceDeposit: amountToPayNow,
      status: 'pending',
      guestName: submittedFormData.fullName,
      guestPhone: submittedFormData.phone,
      guestWhatsapp: submittedFormData.sameWhatsapp ? submittedFormData.phone : submittedFormData.whatsapp,
      guestEmail: submittedFormData.email,
      guestCity: submittedFormData.city,
      groupType: submittedFormData.groupType,
      dietary: submittedFormData.dietary,
      specialRequests: submittedFormData.specialRequests,
      arrivalTime: submittedFormData.arrivalTime,
      source: submittedFormData.source,
      isRemoteProperty: isRemote,
      paymentAmount: amountToPayNow,
      paymentStatus: isRemote ? 'full_paid' : 'advance_paid',
      paymentId,
      createdAt: new Date().toISOString(),
    };

    // Simulate seamless Razorpay transaction settlement delay
    setTimeout(async () => {
      await submitBooking(newBooking);
      setIsProcessingPayment(false);
      setShowDedicatedModal(false);
    }, 1200);
  };

  const handleInitiateRazorpayPayment = async () => {
    if (!submittedFormData) return;
    if (isRazorpayLive()) {
      setIsProcessingPayment(true);
      const opened = await openLiveRazorpayCheckout({
        amount: amountToPayNow,
        propertyName: property.name,
        guestName: submittedFormData.fullName,
        guestEmail: submittedFormData.email,
        guestPhone: submittedFormData.phone,
        onSuccess: (paymentId) => {
          handleCompletePayment(paymentId);
        },
        onFailure: (err) => {
          setIsProcessingPayment(false);
          console.warn('Razorpay live transaction failed:', err);
        },
        onDismiss: () => {
          setIsProcessingPayment(false);
        },
      });
      if (!opened) {
        setShowDedicatedModal(true);
        setIsProcessingPayment(false);
      }
    } else {
      // Demo Mode: Process through simulated Razorpay confirmation
      handleCompletePayment();
    }
  };

  return (
    <div className="py-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Top Navigation & Breadcrumb */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => {
            if (currentStep === 2) {
              setCurrentStep(1);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            } else {
              navigate(-1);
            }
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-[#2D5016] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{currentStep === 2 ? 'Back to Step 1 (Guest Details)' : `Back to ${property.name}`}</span>
        </button>

        {/* Step Progress Pill */}
        <div className="flex items-center gap-2 text-xs font-bold">
          <span
            className={`px-3 py-1 rounded-full transition-colors ${
              currentStep === 1
                ? 'bg-[#2D5016] text-white shadow-xs'
                : 'bg-emerald-100 text-[#2D5016]'
            }`}
          >
            1. Guest Details
          </span>
          <span className="text-stone-300">→</span>
          <span
            className={`px-3 py-1 rounded-full transition-colors ${
              currentStep === 2
                ? 'bg-[#C84B31] text-white shadow-xs'
                : 'bg-stone-100 text-stone-500'
            }`}
          >
            2. Payment & Policy
          </span>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* STEP 1: BOOKING REQUEST FORM                                              */}
      {/* ========================================================================= */}
      {currentStep === 1 && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#2D5016] bg-[#2D5016]/10 px-3 py-1 rounded-full">
              Step 1 of 2 • Reservation Request
            </span>
            <h1 className="text-2xl sm:text-4xl font-bold text-[#1A1A1A] font-display mt-2">
              Your Personal Details
            </h1>
            <p className="text-xs sm:text-sm text-stone-600 mt-1">
              We connect directly with {property.host.name} to guarantee your room. Complete details below to proceed to the payment summary.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* FORM SECTION (2 Cols) */}
            <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/90 shadow-sm space-y-6">
              <form onSubmit={handleSubmit(onStep1Submit)} className="space-y-5 text-xs">
                {/* Full Name */}
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Rahul Sharma"
                    {...register('fullName', { required: 'Please enter your full name' })}
                    className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                  />
                  {errors.fullName && (
                    <p className="text-[11px] text-red-500 mt-1">{errors.fullName.message}</p>
                  )}
                </div>

                {/* Phone & Email */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">
                      Mobile Phone Number <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-3 text-stone-400 font-semibold">+91</span>
                      <input
                        type="tel"
                        placeholder="9876543210"
                        {...register('phone', {
                          required: 'Mobile number is required',
                          validate: (v) => validateIndianPhone(v) || 'Please enter valid 10-digit Indian phone',
                        })}
                        className="w-full pl-12 pr-3 py-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                      />
                    </div>
                    {errors.phone && (
                      <p className="text-[11px] text-red-500 mt-1">{errors.phone.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block font-bold text-stone-700 mb-1">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      placeholder="rahul@gmail.com"
                      {...register('email', { required: 'Email is required' })}
                      className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                    />
                    {errors.email && (
                      <p className="text-[11px] text-red-500 mt-1">{errors.email.message}</p>
                    )}
                  </div>
                </div>

                {/* Same WhatsApp Toggle */}
                <div className="bg-stone-50 p-3 rounded-xl border border-stone-200">
                  <label className="flex items-center gap-2 cursor-pointer font-semibold text-stone-700">
                    <input
                      type="checkbox"
                      {...register('sameWhatsapp')}
                      className="w-4 h-4 rounded text-[#2D5016] accent-[#2D5016]"
                    />
                    <span>WhatsApp number is the same as phone number</span>
                  </label>

                  {!sameWhatsapp && (
                    <div className="mt-3">
                      <label className="block font-bold text-stone-700 mb-1">
                        WhatsApp Number
                      </label>
                      <input
                        type="tel"
                        placeholder="WhatsApp number"
                        {...register('whatsapp')}
                        className="w-full p-2.5 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                      />
                    </div>
                  )}
                </div>

                {/* Traveling From & Group Type */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">
                      City Traveling From <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Delhi, Chandigarh, Mumbai"
                      {...register('city', { required: 'Please enter departure city' })}
                      className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                    />
                    {errors.city && (
                      <p className="text-[11px] text-red-500 mt-1">{errors.city.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block font-bold text-stone-700 mb-1">
                      Group Type
                    </label>
                    <select
                      {...register('groupType')}
                      className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                    >
                      <option value="Solo">Solo Traveler</option>
                      <option value="Couple">Couple</option>
                      <option value="Friends">Friends Group</option>
                      <option value="Family">Family with Kids/Elders</option>
                    </select>
                  </div>
                </div>

                {/* Dietary Preference & Arrival Time */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">
                      Dietary Preferences for Host Meals
                    </label>
                    <select
                      {...register('dietary')}
                      className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                    >
                      <option value="Veg">Pure Vegetarian (Desi ghee / hill food)</option>
                      <option value="Non-Veg">Non-Vegetarian (Local poultry/fish/meat)</option>
                      <option value="Vegan">Vegan (Dairy-free)</option>
                      <option value="No preference">No preference</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-stone-700 mb-1">
                      Estimated Arrival Time
                    </label>
                    <select
                      {...register('arrivalTime')}
                      className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                    >
                      <option value="Morning (8 AM - 12 PM)">Morning (8 AM - 12 PM)</option>
                      <option value="Afternoon (12 PM - 4 PM)">Afternoon (12 PM - 4 PM)</option>
                      <option value="Evening (4 PM - 8 PM)">Evening (4 PM - 8 PM)</option>
                      <option value="Late Night (After 8 PM)">Late Night (After 8 PM)</option>
                    </select>
                  </div>
                </div>

                {/* Special requirements */}
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Special Requirements or Notes for the Host
                  </label>
                  <textarea
                    rows={3}
                    placeholder="e.g. Traveling with a pet, quiet study corner for remote meetings, extra blankets..."
                    {...register('specialRequests')}
                    className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                  />
                </div>

                {/* How did you hear */}
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    How did you hear about Cosyfy?
                  </label>
                  <select
                    {...register('source')}
                    className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                  >
                    <option value="Google Search">Google Search</option>
                    <option value="Instagram">Instagram</option>
                    <option value="Friend Recommendation">Friend Recommendation</option>
                    <option value="WhatsApp Community">WhatsApp Community</option>
                    <option value="LinkedIn">LinkedIn / Remote Work</option>
                  </select>
                </div>

                {/* Step 1 Submit Button */}
                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-4 rounded-2xl bg-[#C84B31] hover:bg-[#AF3E25] text-white font-bold text-base shadow-lg transition-all hover:shadow-xl flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Proceed to Step 2: Payment & Cancellation Policy</span>
                    <ArrowRight className="w-5 h-5" />
                  </button>
                  <p className="text-[11px] text-stone-500 text-center mt-2">
                    🔒 You will review the booking summary, cancellation rules, and payment breakdown next.
                  </p>
                </div>
              </form>
            </div>

            {/* SUMMARY PREVIEW COLUMN (1 Col) */}
            <div className="lg:col-span-1 space-y-6">
              <div className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-sm space-y-4">
                <h3 className="text-base font-bold text-stone-900 font-display border-b border-stone-100 pb-3">
                  Stay Summary
                </h3>

                <div className="flex items-center gap-3">
                  <img
                    src={property.mainImage}
                    alt={property.name}
                    className="w-20 h-16 object-cover rounded-xl border border-stone-200"
                  />
                  <div>
                    <h4 className="text-sm font-bold text-stone-900 font-display">{property.name}</h4>
                    <p className="text-[11px] text-stone-500">{property.location}</p>
                    <span className="text-[10px] font-bold text-[#2D5016] bg-emerald-50 px-2 py-0.5 rounded inline-block mt-0.5">
                      Verified Host: {property.host.name}
                    </span>
                  </div>
                </div>

                <div className="space-y-2 text-xs text-stone-600 pt-2 border-t border-stone-100">
                  <div className="flex justify-between">
                    <span>Check-in:</span>
                    <strong className="text-stone-800">{checkIn || 'Selected Date'}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Check-out:</span>
                    <strong className="text-stone-800">{checkOut || 'Selected Date'}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Duration:</span>
                    <strong className="text-stone-800">{nights} {nights === 1 ? 'Night' : 'Nights'}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Guests:</span>
                    <strong className="text-stone-800">{adults} Guests</strong>
                  </div>
                </div>

                {/* Price Breakdown */}
                <div className="space-y-2 text-xs text-stone-600 pt-3 border-t border-stone-100">
                  <div className="flex justify-between">
                    <span>{formatPrice(ratePerNight)} × {nights} nights</span>
                    <span className="font-semibold text-stone-800">{formatPrice(stayCost)}</span>
                  </div>
                  <div className="flex justify-between text-[#2D5016]">
                    <span>Cosyfy Service Fee</span>
                    <span className="font-bold">₹0 (FREE)</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-stone-900 pt-2 border-t border-stone-100">
                    <span>Total Stay Amount</span>
                    <span>{formatPrice(totalCost)}</span>
                  </div>

                  {isRemote ? (
                    <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 text-[11px] text-amber-900 mt-2 space-y-1">
                      <span className="font-bold text-[#C84B31]">Remote Homestay Policy:</span>
                      <p>Full 100% payment ({formatPrice(totalCost)}) collected at booking due to remote mountain connectivity.</p>
                    </div>
                  ) : (
                    <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200 text-[11px] text-[#2D5016] mt-2">
                      <span className="font-bold">10% Advance Deposit:</span> {formatPrice(advanceDeposit)}
                      <br />
                      <span className="text-stone-500">Remaining 90% ({formatPrice(remainingDueOnArrival)}) paid directly to host on arrival.</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* STEP 2: PAYMENT PAGE (SUMMARY + CANCELLATION POLICY + RAZORPAY GATEWAY)    */}
      {/* ========================================================================= */}
      {currentStep === 2 && submittedFormData && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#C84B31] bg-[#C84B31]/10 px-3 py-1 rounded-full">
              Step 2 of 2 • Payment & Cancellation Policy
            </span>
            <h1 className="text-2xl sm:text-4xl font-bold text-[#1A1A1A] font-display mt-2">
              Review Summary & Complete Booking
            </h1>
            <p className="text-xs sm:text-sm text-stone-600 mt-1">
              Check your reservation details, read our transparent cancellation terms, and secure your room via Razorpay.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* LEFT / CENTER (2 Cols): SUMMARY + CANCELLATION POLICY + PAYMENT FORM */}
            <div className="lg:col-span-2 space-y-6">
              {/* 1. TOP BOOKING SUMMARY CARD */}
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/90 shadow-sm space-y-5">
                <div className="flex items-center justify-between border-b border-stone-100 pb-4">
                  <h2 className="text-lg font-bold text-stone-900 font-display">
                    Booking Summary
                  </h2>
                  <button
                    type="button"
                    onClick={() => {
                      setCurrentStep(1);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="text-xs text-[#C84B31] font-semibold hover:underline"
                  >
                    Edit Guest Details
                  </button>
                </div>

                {/* Property Detail Strip */}
                <div className="flex items-start sm:items-center gap-4">
                  <img
                    src={property.mainImage}
                    alt={property.name}
                    className="w-24 h-20 object-cover rounded-2xl border border-stone-200 shrink-0"
                  />
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold text-[#2D5016] bg-emerald-50 px-2 py-0.5 rounded uppercase tracking-wider">
                      Cosyfy Verified Homestay
                    </span>
                    <h3 className="text-base sm:text-lg font-bold text-stone-900 font-display">
                      {property.name}
                    </h3>
                    <p className="text-xs text-stone-500">{property.location}</p>
                    <p className="text-xs text-stone-600 font-medium">
                      Host: <span className="text-stone-900 font-semibold">{property.host.name}</span>
                    </p>
                  </div>
                </div>

                {/* Trip & Guest Details Strip */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-stone-50 rounded-2xl border border-stone-200/80 text-xs">
                  <div>
                    <span className="text-stone-400 block text-[11px]">Check-in</span>
                    <strong className="text-stone-800">{checkIn}</strong>
                  </div>
                  <div>
                    <span className="text-stone-400 block text-[11px]">Check-out</span>
                    <strong className="text-stone-800">{checkOut}</strong>
                  </div>
                  <div>
                    <span className="text-stone-400 block text-[11px]">Duration</span>
                    <strong className="text-stone-800">{nights} {nights === 1 ? 'Night' : 'Nights'}</strong>
                  </div>
                  <div>
                    <span className="text-stone-400 block text-[11px]">Guests</span>
                    <strong className="text-stone-800">
                      {adults} Adults {children > 0 ? `, ${children} Kids` : ''}
                    </strong>
                  </div>
                </div>

                {/* Guest Contact Pill */}
                <div className="text-xs text-stone-600 flex flex-wrap items-center gap-x-4 gap-y-1 px-1">
                  <span>
                    <strong>Guest:</strong> {submittedFormData.fullName}
                  </span>
                  <span>
                    <strong>Mobile:</strong> +91 {submittedFormData.phone}
                  </span>
                  <span>
                    <strong>Email:</strong> {submittedFormData.email}
                  </span>
                  <span>
                    <strong>From:</strong> {submittedFormData.city}
                  </span>
                </div>

                {/* Numerical Financial Breakdown */}
                <div className="space-y-2.5 pt-4 border-t border-stone-100 text-xs text-stone-700">
                  <div className="flex justify-between">
                    <span>Subtotal ({formatPrice(ratePerNight)} × {nights} nights)</span>
                    <span className="font-semibold text-stone-900">{formatPrice(stayCost)}</span>
                  </div>

                  {cleaningFee > 0 && (
                    <div className="flex justify-between">
                      <span>Cleaning / Maintenance Fee</span>
                      <span className="font-semibold text-stone-900">{formatPrice(cleaningFee)}</span>
                    </div>
                  )}

                  <div className="flex justify-between text-[#2D5016] font-semibold">
                    <span className="flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-[#2D5016]" />
                      <span>Cosyfy Service Fee</span>
                    </span>
                    <span className="bg-emerald-100 text-[#2D5016] px-2 py-0.5 rounded text-[11px] font-bold">
                      ₹0 (FREE)
                    </span>
                  </div>

                  <div className="flex justify-between text-sm font-bold text-stone-900 pt-3 border-t border-stone-200">
                    <span>Total Stay Amount</span>
                    <span className="text-base">{formatPrice(totalCost)}</span>
                  </div>

                  {/* Highlighted Orange Box */}
                  {isRemote ? (
                    <div className="bg-[#FFF4EC] border-2 border-[#C84B31] rounded-2xl p-4 text-xs space-y-1 text-stone-900 shadow-xs mt-3">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-[#C84B31] text-sm uppercase tracking-wide">
                          Full Payment Required To Secure Stay
                        </span>
                        <span className="text-base font-extrabold text-[#C84B31]">
                          {formatPrice(amountToPayNow)} (100%)
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-600">
                        This property is marked as a remote location. Full stay cost is settled at reservation to guarantee your rooms.
                      </p>
                      <p className="text-[11px] text-stone-500 pt-1 border-t border-orange-200/60">
                        Remaining balance to host on arrival: <strong className="text-stone-900">₹0</strong>
                      </p>
                    </div>
                  ) : (
                    <div className="bg-[#FFF4EC] border-2 border-[#C84B31] rounded-2xl p-4 text-xs space-y-1 text-stone-900 shadow-xs mt-3">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-[#C84B31] text-sm uppercase tracking-wide">
                          10% Advance To Pay Now
                        </span>
                        <span className="text-base font-extrabold text-[#C84B31]">
                          {formatPrice(amountToPayNow)}
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-600">
                        You only pay 10% now to hold your room. Zero surprise charges.
                      </p>
                      <p className="text-[11px] text-stone-800 pt-1 border-t border-orange-200/60 flex justify-between">
                        <span>Remaining 90% paid directly to host on arrival:</span>
                        <strong className="text-stone-900 font-bold">{formatPrice(remainingDueOnArrival)}</strong>
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* 2. CANCELLATION POLICY DISPLAY (BEFORE PAYMENT BUTTON) */}
              <div className="rounded-3xl overflow-hidden border transition-all shadow-sm">
                {isRemote ? (
                  /* Remote Property Cancellation Policy */
                  <div className="bg-amber-50/90 border-2 border-amber-300 rounded-3xl p-6 sm:p-7 space-y-4 text-xs">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-amber-200 text-amber-900 flex items-center justify-center shrink-0">
                        <AlertTriangle className="w-5 h-5 text-amber-800" />
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 bg-amber-200/60 px-2 py-0.5 rounded">
                          Remote Stay Special Terms
                        </span>
                        <h4 className="text-sm sm:text-base font-bold text-amber-950 font-display mt-0.5">
                          REMOTE PROPERTY — FULL PAYMENT REQUIRED
                        </h4>
                        <p className="text-[11px] text-amber-900 mt-0.5">
                          This property is in a remote location with limited connectivity. Full payment is collected at booking to secure your reservation.
                        </p>
                      </div>
                    </div>

                    <div className="bg-white/80 rounded-2xl p-4 border border-amber-200 space-y-2 text-stone-800">
                      <div className="flex items-start gap-2">
                        <span className="text-emerald-600 font-bold">✅</span>
                        <span>
                          <strong>Cancel 15+ days before check-in:</strong> 80% refund
                        </span>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="text-amber-600 font-bold">⚡</span>
                        <span>
                          <strong>Cancel 7-15 days before check-in:</strong> 50% refund
                        </span>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="text-rose-600 font-bold">❌</span>
                        <span>
                          <strong>Cancel less than 7 days:</strong> No refund
                        </span>
                      </div>
                    </div>

                    <p className="text-[11px] text-amber-800 italic">
                      All refunds processed within 5-7 business days to original payment method.
                    </p>
                  </div>
                ) : (
                  /* Standard Property Cancellation Policy (Collapsible Card) */
                  <div className="bg-white border border-stone-200/90 rounded-3xl overflow-hidden">
                    <button
                      type="button"
                      onClick={() => setCancellationPolicyOpen(!cancellationPolicyOpen)}
                      className="w-full p-5 sm:p-6 flex items-center justify-between text-left hover:bg-stone-50/60 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-emerald-50 text-[#2D5016] flex items-center justify-center">
                          <ShieldCheck className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="text-xs sm:text-sm font-bold text-stone-900 uppercase tracking-wider font-display">
                            COSYFY CANCELLATION POLICY
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            Transparent cancellation terms • Tap to {cancellationPolicyOpen ? 'collapse' : 'expand'}
                          </p>
                        </div>
                      </div>

                      <div className="p-1 rounded-full bg-stone-100 text-stone-600">
                        {cancellationPolicyOpen ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </div>
                    </button>

                    {cancellationPolicyOpen && (
                      <div className="px-6 pb-6 pt-1 text-xs border-t border-stone-100 space-y-3 animate-in fade-in">
                        <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200/80 space-y-2.5 text-stone-800">
                          <div className="flex items-start gap-2">
                            <span className="text-emerald-600 font-bold">✅</span>
                            <span>
                              <strong>Cancel 7+ days before check-in:</strong> Full refund of advance
                            </span>
                          </div>
                          <div className="flex items-start gap-2">
                            <span className="text-amber-600 font-bold">⚡</span>
                            <span>
                              <strong>Cancel 3-7 days before check-in:</strong> 50% refund of advance
                            </span>
                          </div>
                          <div className="flex items-start gap-2">
                            <span className="text-rose-600 font-bold">❌</span>
                            <span>
                              <strong>Cancel less than 3 days before:</strong> No refund of advance
                            </span>
                          </div>
                        </div>

                        <p className="text-[11px] text-stone-500 italic">
                          All refunds processed within 5-7 business days to original payment method.
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* 3. PAYMENT METHOD SELECTOR & DIRECT CHECKOUT */}
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/90 shadow-sm space-y-5">
                <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                  <div>
                    <h3 className="text-base font-bold text-stone-900 font-display">
                      Select Payment Method
                    </h3>
                    <p className="text-[11px] text-stone-500">
                      Powered by Razorpay Secure 256-bit SSL gateway
                    </p>
                  </div>
                  <span className="text-[10px] font-bold bg-blue-50 text-blue-700 px-2.5 py-1 rounded-md border border-blue-200">
                    Razorpay Verified
                  </span>
                </div>

                {/* Tabs */}
                <div className="grid grid-cols-4 gap-2 bg-stone-100 p-1.5 rounded-2xl text-xs font-semibold">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('upi')}
                    className={`py-2 px-1 rounded-xl flex flex-col items-center gap-1 transition-all ${
                      paymentMethod === 'upi'
                        ? 'bg-white text-stone-900 shadow-xs'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 text-[#2D5016]" />
                    <span className="text-[11px]">UPI / QR</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`py-2 px-1 rounded-xl flex flex-col items-center gap-1 transition-all ${
                      paymentMethod === 'card'
                        ? 'bg-white text-stone-900 shadow-xs'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 text-[#C84B31]" />
                    <span className="text-[11px]">Card</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('netbanking')}
                    className={`py-2 px-1 rounded-xl flex flex-col items-center gap-1 transition-all ${
                      paymentMethod === 'netbanking'
                        ? 'bg-white text-stone-900 shadow-xs'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    <Building className="w-4 h-4 text-blue-700" />
                    <span className="text-[11px]">Netbanking</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('wallet')}
                    className={`py-2 px-1 rounded-xl flex flex-col items-center gap-1 transition-all ${
                      paymentMethod === 'wallet'
                        ? 'bg-white text-stone-900 shadow-xs'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    <Wallet className="w-4 h-4 text-purple-700" />
                    <span className="text-[11px]">Wallets</span>
                  </button>
                </div>

                {/* Tab Forms */}
                <div className="pt-2 text-xs">
                  {paymentMethod === 'upi' && (
                    <div className="space-y-3">
                      <div>
                        <label className="block font-bold text-stone-700 mb-1">
                          UPI ID (Google Pay / PhonePe / Paytm / BHIM)
                        </label>
                        <input
                          type="text"
                          value={upiId}
                          onChange={(e) => setUpiId(e.target.value)}
                          placeholder="e.g. mobile@okhdfcbank"
                          className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                        />
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-stone-500">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Instant payment request will be sent to your UPI app.</span>
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'card' && (
                    <div className="space-y-3">
                      <div>
                        <label className="block font-bold text-stone-700 mb-1">Card Number</label>
                        <input
                          type="text"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          placeholder="16-digit card number"
                          className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block font-bold text-stone-700 mb-1">Expiry (MM/YY)</label>
                          <input
                            type="text"
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            placeholder="12/28"
                            className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                          />
                        </div>
                        <div>
                          <label className="block font-bold text-stone-700 mb-1">CVV</label>
                          <input
                            type="password"
                            maxLength={4}
                            value={cardCvv}
                            onChange={(e) => setCardCvv(e.target.value)}
                            placeholder="•••"
                            className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'netbanking' && (
                    <div className="space-y-2">
                      <label className="block font-bold text-stone-700">Choose Bank</label>
                      <div className="grid grid-cols-2 gap-2">
                        {['HDFC Bank', 'State Bank of India', 'ICICI Bank', 'Axis Bank'].map((b) => (
                          <button
                            key={b}
                            type="button"
                            onClick={() => setSelectedBank(b)}
                            className={`p-2.5 rounded-xl border text-left font-semibold transition-all ${
                              selectedBank === b
                                ? 'border-[#2D5016] bg-emerald-50/60 text-[#2D5016]'
                                : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                            }`}
                          >
                            {b}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'wallet' && (
                    <div className="space-y-2">
                      <label className="block font-bold text-stone-700">Available Wallets</label>
                      {['Paytm Wallet', 'Amazon Pay', 'Mobikwik'].map((w) => (
                        <div
                          key={w}
                          className="p-3 rounded-xl border border-stone-200 flex items-center justify-between text-stone-800 font-medium"
                        >
                          <span>{w}</span>
                          <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-bold">
                            Supported
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Primary Payment Action Button & Trust Signals */}
                <div className="pt-3 space-y-3">
                  <div className="flex items-center justify-between pb-1">
                    <span className="text-[11px] font-semibold text-stone-600">Payment Gateway:</span>
                    {isRazorpayLive() ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-[#2D5016]">
                        <CheckCircle2 className="w-3 h-3" /> Live Razorpay Checkout Active
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
                        <AlertTriangle className="w-3 h-3 text-amber-700" /> Demo Mode — No real payment
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => handleInitiateRazorpayPayment()}
                    disabled={isProcessingPayment || isSubmitting}
                    className="w-full py-4 rounded-2xl bg-[#C84B31] hover:bg-[#AF3E25] text-white font-bold text-base shadow-xl transition-all hover:shadow-2xl flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isProcessingPayment || isSubmitting ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>Confirming with Bank & Host...</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-4 h-4" />
                        <span>Pay {formatPrice(amountToPayNow)} Now via Razorpay</span>
                      </>
                    )}
                  </button>

                  <div className="flex items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowDedicatedModal(true)}
                      className="text-xs text-stone-500 hover:text-stone-800 underline font-medium"
                    >
                      Or open Fullscreen Razorpay Checkout Window
                    </button>
                  </div>

                  <div className="flex items-center justify-center gap-1.5 text-[11px] text-stone-500 pt-1">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>
                      Instant confirmation • 100% refund as per policy • No hidden fees
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT SIDEBAR (1 Col): SUMMARY RECAP & HOST TRUST CARD */}
            <div className="lg:col-span-1 space-y-6">
              <div className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-sm space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-stone-400">
                  Payment Summary Recap
                </h4>

                <div className="space-y-2 text-xs text-stone-600">
                  <div className="flex justify-between">
                    <span>Stay Duration:</span>
                    <strong className="text-stone-800">{nights} Nights</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Rate per night:</span>
                    <strong className="text-stone-800">{formatPrice(ratePerNight)}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Stay Cost:</span>
                    <strong className="text-stone-900">{formatPrice(totalCost)}</strong>
                  </div>
                  <div className="flex justify-between text-[#2D5016]">
                    <span>Cosyfy Service Fee:</span>
                    <strong className="font-bold">₹0</strong>
                  </div>
                </div>

                <div className="p-4 bg-orange-50/70 border border-orange-200 rounded-2xl text-xs space-y-1">
                  <div className="flex justify-between font-bold text-[#C84B31] text-sm">
                    <span>Due Now:</span>
                    <span>{formatPrice(amountToPayNow)}</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-stone-600 pt-1 border-t border-orange-200/50">
                    <span>Due on arrival:</span>
                    <span className="font-semibold">{formatPrice(remainingDueOnArrival)}</span>
                  </div>
                </div>
              </div>

              {/* Host Reassurance Box */}
              <div className="bg-[#FAF7F2] rounded-3xl p-6 border border-stone-200 text-xs space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#2D5016] text-white flex items-center justify-center font-bold">
                    {property.host.name.charAt(0)}
                  </div>
                  <div>
                    <h5 className="font-bold text-stone-900">{property.host.name}</h5>
                    <p className="text-[11px] text-stone-500">Verified Local Host</p>
                  </div>
                </div>
                <p className="text-stone-600 leading-relaxed text-[11px]">
                  &ldquo;We look forward to welcoming you to our homestay. Hot local meals and comfortable rooms will be ready on your arrival.&rdquo;
                </p>
                <div className="pt-2 border-t border-stone-200 flex items-center gap-1.5 text-[11px] text-[#2D5016] font-semibold">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>24/7 WhatsApp Concierge Support Included</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Optional Dedicated Modal trigger */}
      {showDedicatedModal && (
        <PaymentModal
          amount={amountToPayNow}
          propertyName={property.name}
          guestName={submittedFormData?.fullName || ''}
          guestEmail={submittedFormData?.email || ''}
          guestPhone={submittedFormData?.phone || ''}
          onPaymentSuccess={(pId) => handleCompletePayment(pId)}
          onClose={() => setShowDedicatedModal(false)}
        />
      )}
    </div>
  );
};
