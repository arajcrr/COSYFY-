import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import {
  MessageCircle,
  Clock,
  Sparkles,
  CheckCircle2,
  Phone,
  Mail,
  Instagram,
  Youtube,
  Send,
} from 'lucide-react';
import { saveEnquiryToFirestore } from '../services/firebase';
import { sendEnquiryWebhook } from '../services/webhooks';
import { getWhatsAppUrl, validateIndianPhone } from '../utils';
import { useLanguage } from '../context/LanguageContext';

interface ContactFormData {
  name: string;
  phone: string;
  email: string;
  message: string;
}

export const Contact: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const whatsappNum = import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210';
  const whatsappUrl = getWhatsAppUrl(
    whatsappNum,
    'Namaste Cosyfy team! I need assistance with homestay booking.'
  );

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ContactFormData>();

  const onSubmit = async (data: ContactFormData) => {
    setSubmitting(true);
    try {
      // 1. Save to Firestore
      await saveEnquiryToFirestore({
        name: data.name,
        phone: data.phone,
        email: data.email,
        message: data.message,
      });

      // 2. Trigger Make.com Webhook
      await sendEnquiryWebhook({
        name: data.name,
        phone: data.phone,
        email: data.email,
        message: data.message,
      });

      setSubmitted(true);
      reset();
    } catch (e) {
      console.error(e);
      setSubmitted(true);
    } finally {
      setSubmitting(false);
    }
  };

  const { tagline } = useLanguage();

  return (
    <div className="py-12 sm:py-20 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-[#2D5016] bg-[#2D5016]/10 px-3.5 py-1.5 rounded-full inline-block">
          Personal Concierge
        </span>
        <h1 className="text-3xl sm:text-5xl font-bold font-display text-stone-900">
          Get in Touch With Cosyfy
        </h1>
        <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
          &ldquo;{tagline}&rdquo;
          <br />
          Available 7am — 10pm IST, 7 days a week. We reply within 2 hours.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
        {/* Left Column: WhatsApp Primary CTA & Direct Info */}
        <div className="bg-white rounded-3xl p-8 border border-stone-200/90 shadow-sm space-y-6">
          <div>
            <h3 className="text-xl font-bold text-stone-900 font-display">
              Fastest Way: WhatsApp
            </h3>
            <p className="text-xs text-stone-500 mt-1">
              Skip email threads. Send us a WhatsApp text and our team in Himachal & Bangalore will reply directly.
            </p>
          </div>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-4 rounded-2xl bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-sm shadow-lg flex items-center justify-center gap-2 transition-all hover:scale-102"
          >
            <MessageCircle className="w-5 h-5 fill-white" />
            <span>Chat With Us on WhatsApp</span>
          </a>

          <div className="space-y-4 pt-4 border-t border-stone-100 text-xs text-stone-700">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-stone-100 text-[#2D5016]">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <strong className="block text-stone-900">Support Hours</strong>
                <span>7:00 AM – 10:00 PM IST (All 7 Days)</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-stone-100 text-[#2D5016]">
                <Phone className="w-4 h-4" />
              </div>
              <div>
                <strong className="block text-stone-900">Support Hotline</strong>
                <span>+{whatsappNum}</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-stone-100 text-[#2D5016]">
                <Mail className="w-4 h-4" />
              </div>
              <div>
                <strong className="block text-stone-900">Email Inquiries</strong>
                <span>namaste@cosyfy.in</span>
              </div>
            </div>
          </div>

          {/* Social Links */}
          <div className="pt-4 border-t border-stone-100">
            <p className="text-xs font-bold text-stone-700 mb-2">Follow Our Journeys</p>
            <div className="flex items-center gap-3">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 rounded-xl bg-stone-100 text-stone-700 hover:text-pink-600 hover:bg-pink-50 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 rounded-xl bg-stone-100 text-stone-700 hover:text-red-600 hover:bg-red-50 transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        {/* Right Column: Contact Enquiry Form */}
        <div className="bg-white rounded-3xl p-8 border border-stone-200/90 shadow-sm space-y-6">
          <div>
            <h3 className="text-xl font-bold text-stone-900 font-display">
              Send a Message
            </h3>
            <p className="text-xs text-stone-500 mt-1">
              Have questions about booking a homestay or listing your property? Fill out the details below:
            </p>
          </div>

          {submitted ? (
            <div className="py-10 text-center space-y-3">
              <CheckCircle2 className="w-12 h-12 text-[#2D5016] mx-auto animate-bounce" />
              <h4 className="text-lg font-bold text-stone-900 font-display">Message Received!</h4>
              <p className="text-xs text-stone-600 max-w-sm mx-auto leading-relaxed">
                Thank you! Our concierge team will reach out to you on WhatsApp / email within 2 hours.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="px-4 py-2 text-xs font-bold text-[#2D5016] hover:underline"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">
                  Your Full Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Ananya Roy"
                  {...register('name', { required: 'Please enter your name' })}
                  className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                />
                {errors.name && (
                  <p className="text-[11px] text-red-500 mt-1">{errors.name.message}</p>
                )}
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">
                  Mobile / WhatsApp Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  placeholder="e.g. 9876543210"
                  {...register('phone', {
                    required: 'Phone number is required',
                    validate: (v) => validateIndianPhone(v) || 'Please enter valid 10-digit number',
                  })}
                  className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                />
                {errors.phone && (
                  <p className="text-[11px] text-red-500 mt-1">{errors.phone.message}</p>
                )}
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="ananya@gmail.com"
                  {...register('email')}
                  className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">
                  Message or Question <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={4}
                  placeholder="Tell us what you need help with (dates, specific region, long stay workation, or host onboarding)..."
                  {...register('message', { required: 'Message cannot be empty' })}
                  className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                />
                {errors.message && (
                  <p className="text-[11px] text-red-500 mt-1">{errors.message.message}</p>
                )}
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3.5 rounded-xl bg-[#2D5016] hover:bg-[#1F380F] text-white font-bold text-xs flex items-center justify-center gap-2 transition-all disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{submitting ? 'Sending...' : 'Send Message'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
