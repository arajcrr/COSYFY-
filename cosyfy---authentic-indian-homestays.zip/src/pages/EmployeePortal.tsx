import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  Calendar,
  Building,
  CheckCircle2,
  Clock,
  MessageCircle,
  Phone,
  Search,
  LogOut,
  Send,
  Star,
  Target,
  Sparkles,
  Menu,
  X,
  Plus,
} from 'lucide-react';
import { CosyfyLogo } from '../components/common/CosyfyLogo';
import { getActiveSession, logoutUser } from '../services/auth';
import {
  getAdminBookings,
  getAdminCustomers,
  updateAdminCustomer,
  getAdminProperties,
  saveAdminProperties,
  getPropertyLeads,
  updatePropertyLead,
  PropertyLead,
  AdminBooking,
  AdminCustomer,
  AdminPropertyItem,
} from '../services/adminData';
import { PropertyOnboardingWizard } from '../components/admin/PropertyOnboardingWizard';
import { formatPrice, getWhatsAppUrl } from '../utils';

type EmpTab = 'leads' | 'bookings' | 'properties' | 'performance';

export const EmployeePortal: React.FC = () => {
  const navigate = useNavigate();
  const session = getActiveSession();

  const [activeTab, setActiveTab] = useState<EmpTab>('leads');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [customers, setCustomers] = useState<AdminCustomer[]>(() => getAdminCustomers());
  const [bookings, setBookings] = useState<AdminBooking[]>(() => getAdminBookings());
  const [properties, setProperties] = useState<AdminPropertyItem[]>(() => getAdminProperties());
  const [isAddPropertyOpen, setIsAddPropertyOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState<AdminPropertyItem | null>(null);

  const [inspectCustomer, setInspectCustomer] = useState<AdminCustomer | null>(null);
  const [quickNote, setQuickNote] = useState('');

  const currentUserName = session?.user.name || 'Rohan Verma';

  // Filter customers assigned to this employee (or general leads)
  const myCustomers = customers.filter(
    (c) =>
      c.assignedEmployee.toLowerCase().includes(currentUserName.split(' ')[0].toLowerCase()) ||
      c.assignedEmployee === 'Rohan Verma'
  );

  const myBookings = bookings.filter(
    (b) =>
      b.assignedEmployee.toLowerCase().includes(currentUserName.split(' ')[0].toLowerCase()) ||
      b.assignedEmployee === 'Rohan Verma'
  );

  const handleLogout = () => {
    logoutUser();
    navigate('/login', { replace: true });
  };

  const handleUpdateStatus = (customerId: string, status: AdminCustomer['leadStatus']) => {
    const updated = updateAdminCustomer(customerId, { leadStatus: status });
    setCustomers(updated);
    if (inspectCustomer && inspectCustomer.id === customerId) {
      setInspectCustomer({ ...inspectCustomer, leadStatus: status });
    }
  };

  const handleAddNote = (customerId: string) => {
    if (!quickNote.trim()) return;
    const target = customers.find((c) => c.id === customerId);
    if (!target) return;
    const noteEntry = `[${new Date().toLocaleDateString('en-IN')}] ${currentUserName}: ${quickNote.trim()}`;
    const updatedNotes = [noteEntry, ...target.notes];
    const updated = updateAdminCustomer(customerId, { notes: updatedNotes });
    setCustomers(updated);
    if (inspectCustomer && inspectCustomer.id === customerId) {
      setInspectCustomer({ ...inspectCustomer, notes: updatedNotes });
    }
    setQuickNote('');
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] flex flex-col md:flex-row text-stone-900 font-sans">
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-[#14231b] text-stone-300 border-r border-[#1e3428] shrink-0">
        <div className="p-6 border-b border-[#1e3428] flex items-center justify-between">
          <div className="bg-white p-2 rounded-xl">
            <CosyfyLogo size="sm" />
          </div>
          <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-900 text-emerald-200 border border-emerald-700 px-2 py-0.5 rounded">
            Concierge
          </span>
        </div>

        <div className="px-6 py-4 border-b border-[#1e3428] bg-black/20">
          <p className="text-xs font-bold text-white truncate">{session?.user.name}</p>
          <p className="text-[11px] text-emerald-300/80 truncate">{session?.user.email}</p>
          <span className="inline-block mt-1 text-[10px] font-semibold text-emerald-400">
            ● Online • 2h SLA Active
          </span>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('leads')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'leads'
                ? 'bg-[#C84B31] text-white font-bold'
                : 'text-stone-300 hover:bg-[#1e3428] hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <Users className="w-4 h-4" />
              <span>My Assigned Leads</span>
            </div>
            <span className="text-[10px] bg-black/40 px-1.5 py-0.5 rounded font-mono">
              {myCustomers.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('bookings')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'bookings'
                ? 'bg-[#C84B31] text-white font-bold'
                : 'text-stone-300 hover:bg-[#1e3428] hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <Calendar className="w-4 h-4" />
              <span>My Stays Pipeline</span>
            </div>
            <span className="text-[10px] bg-black/40 px-1.5 py-0.5 rounded font-mono">
              {myBookings.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('properties')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'properties'
                ? 'bg-[#C84B31] text-white font-bold'
                : 'text-stone-300 hover:bg-[#1e3428] hover:text-white'
            }`}
          >
            <Building className="w-4 h-4" />
            <span>Homestay Directory</span>
          </button>

          <button
            onClick={() => setActiveTab('performance')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'performance'
                ? 'bg-[#C84B31] text-white font-bold'
                : 'text-stone-300 hover:bg-[#1e3428] hover:text-white'
            }`}
          >
            <Target className="w-4 h-4" />
            <span>My Monthly Goals</span>
          </button>
        </nav>

        <div className="p-4 border-t border-[#1e3428]">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-rose-300 hover:bg-rose-950/40 text-xs font-bold"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Mobile Bar */}
      <div className="md:hidden bg-[#14231b] text-white px-4 py-3 flex items-center justify-between border-b border-[#1e3428] sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <div className="bg-white p-1 rounded-lg">
            <CosyfyLogo size="sm" />
          </div>
          <span className="text-[10px] font-bold bg-emerald-900 text-emerald-200 px-1.5 py-0.5 rounded">
            Concierge Desk
          </span>
        </div>
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2 rounded-lg bg-black/30 text-stone-200"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden bg-[#14231b] text-white border-b border-[#1e3428] p-4 space-y-2 z-40 fixed top-14 left-0 right-0">
          {[
            { id: 'leads', label: 'My Assigned Leads', icon: Users },
            { id: 'bookings', label: 'My Stays Pipeline', icon: Calendar },
            { id: 'properties', label: 'Homestay Directory', icon: Building },
            { id: 'performance', label: 'My Monthly Goals', icon: Target },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id as EmpTab);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold ${
                  activeTab === item.id ? 'bg-[#C84B31] text-white font-bold' : 'text-stone-300'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2 text-rose-400 text-xs font-bold pt-2 border-t border-[#1e3428]"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      )}

      {/* Main Panel */}
      <main className="flex-1 p-4 sm:p-8 lg:p-10 overflow-y-auto max-w-7xl mx-auto w-full space-y-6">
        {/* TAB 1: LEADS & CUSTOMERS */}
        {activeTab === 'leads' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
                  My Assigned Leads & Enquiries
                </h1>
                <p className="text-xs text-stone-500 mt-1">
                  Connect with prospective travelers on WhatsApp within 2 hours. Zero service fee promise.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {myCustomers.map((c) => {
                const whatsappMessage = `Namaste ${c.name}! I am ${currentUserName} from Cosyfy homestays. I saw your enquiry for ${c.destinationInterested}. Would you like me to share verified availability and photo walkthroughs?`;
                const whatsappUrl = getWhatsAppUrl(c.phone.replace(/\D/g, ''), whatsappMessage);

                return (
                  <div
                    key={c.id}
                    className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-sm space-y-4 hover:border-[#2D5016] transition-all"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-mono text-stone-400 font-bold block">
                          {c.id} • {c.source}
                        </span>
                        <h3 className="text-base font-bold text-stone-900 font-display mt-0.5">
                          {c.name}
                        </h3>
                        <p className="text-xs text-stone-600 font-medium">{c.destinationInterested}</p>
                      </div>

                      <select
                        value={c.leadStatus}
                        onChange={(e) =>
                          handleUpdateStatus(c.id, e.target.value as AdminCustomer['leadStatus'])
                        }
                        className="text-xs font-bold px-2.5 py-1 rounded-full border border-stone-200 bg-stone-50 text-[#2D5016]"
                      >
                        <option value="New Lead">New Lead</option>
                        <option value="Contacted">Contacted</option>
                        <option value="Follow-up Due">Follow-up Due</option>
                        <option value="Proposal Sent">Proposal Sent</option>
                        <option value="Converted">Converted</option>
                        <option value="Lost">Lost</option>
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs bg-stone-50 p-3 rounded-2xl border border-stone-100">
                      <div>
                        <span className="text-[11px] text-stone-400 block">Check-in</span>
                        <strong className="text-stone-800">{c.requestedCheckIn}</strong>
                      </div>
                      <div>
                        <span className="text-[11px] text-stone-400 block">Budget / Night</span>
                        <strong className="text-stone-800">{formatPrice(c.budgetPerNight)}</strong>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-stone-100 text-xs">
                      <a
                        href={whatsappUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white font-bold shadow-xs transition-transform hover:scale-102"
                      >
                        <MessageCircle className="w-4 h-4 fill-white" />
                        <span>WhatsApp Reply</span>
                      </a>

                      <button
                        onClick={() => setInspectCustomer(c)}
                        className="text-[#C84B31] font-bold hover:underline"
                      >
                        Log Interaction Notes →
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Note & Profile Slide-over */}
            {inspectCustomer && (
              <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end">
                <div className="w-full max-w-lg bg-white h-full p-6 sm:p-8 overflow-y-auto space-y-5 animate-in slide-in-from-right duration-200">
                  <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                    <h3 className="text-base font-bold text-stone-900 font-display">
                      Interaction Notes: {inspectCustomer.name}
                    </h3>
                    <button
                      onClick={() => setInspectCustomer(null)}
                      className="p-1.5 rounded-full hover:bg-stone-100"
                    >
                      <X className="w-5 h-5 text-stone-500" />
                    </button>
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="e.g. Sent video walkthrough of Chandi Apple Retreat..."
                      value={quickNote}
                      onChange={(e) => setQuickNote(e.target.value)}
                      className="flex-1 p-2.5 rounded-xl border border-stone-300 text-xs font-medium"
                    />
                    <button
                      onClick={() => handleAddNote(inspectCustomer.id)}
                      className="px-4 py-2.5 rounded-xl bg-[#2D5016] text-white font-bold text-xs"
                    >
                      Log
                    </button>
                  </div>

                  <div className="space-y-2 text-xs">
                    <h4 className="font-bold text-stone-500 uppercase tracking-wider text-[10px]">
                      Call & Message History
                    </h4>
                    {inspectCustomer.notes.map((n, i) => (
                      <div key={i} className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-stone-700">
                        {n}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: MY BOOKINGS */}
        {activeTab === 'bookings' && (
          <div className="space-y-6 animate-in fade-in">
            <h1 className="text-2xl font-bold font-display text-stone-900">
              My Assigned Bookings & Stay Pipelines
            </h1>
            <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-stone-50 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                  <tr>
                    <th className="p-4">ID</th>
                    <th className="p-4">Guest</th>
                    <th className="p-4">Homestay</th>
                    <th className="p-4">Dates</th>
                    <th className="p-4">Total</th>
                    <th className="p-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {myBookings.map((b) => (
                    <tr key={b.id} className="hover:bg-stone-50">
                      <td className="p-4 font-mono font-bold text-stone-900">{b.id}</td>
                      <td className="p-4 font-semibold text-stone-900">{b.customerName}</td>
                      <td className="p-4 text-stone-700">{b.propertyName}</td>
                      <td className="p-4 text-stone-600">
                        {b.checkIn} to {b.checkOut}
                      </td>
                      <td className="p-4 font-bold text-stone-900">{formatPrice(b.totalAmount)}</td>
                      <td className="p-4">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            b.status === 'confirmed'
                              ? 'bg-emerald-100 text-[#2D5016]'
                              : b.status === 'pending'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {b.status.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: HOMESTAY DIRECTORY */}
        {activeTab === 'properties' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold font-display text-stone-900">
                  Verified Properties Quick Reference
                </h1>
                <p className="text-xs text-stone-500">
                  Lookup host contacts, WiFi speeds, and amenities, or onboard a new verified homestay
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingProperty(null);
                  setIsAddPropertyOpen(true);
                }}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#C84B31] text-white text-xs font-bold shadow-md hover:bg-[#af3f26]"
              >
                <Plus className="w-4 h-4" />
                <span>Onboard New Host (7-Step Wizard)</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {properties.map((p) => (
                <div
                  key={p.id}
                  className="bg-white rounded-3xl p-5 border border-stone-200/90 shadow-sm space-y-3"
                >
                  <img
                    src={p.mainImage}
                    alt={p.name}
                    className="w-full h-36 object-cover rounded-2xl"
                  />
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono text-stone-400 font-bold">{p.id}</span>
                      <button
                        onClick={() => {
                          setEditingProperty(p);
                          setIsAddPropertyOpen(true);
                        }}
                        className="text-[11px] font-bold text-[#2D5016] hover:underline"
                      >
                        Edit Details
                      </button>
                    </div>
                    <h3 className="font-bold text-stone-900 text-sm font-display">{p.name}</h3>
                    <p className="text-xs text-stone-500">{p.location}</p>
                  </div>
                  <div className="pt-2 border-t border-stone-100 text-xs flex justify-between items-center">
                    <span className="font-bold text-stone-900">{formatPrice(p.weekdayPrice)}/nt</span>
                    <a
                      href={getWhatsAppUrl(p.ownerWhatsapp.replace(/\D/g, ''), `Namaste ${p.ownerName} ji!`)}
                      target="_blank"
                      rel="noreferrer"
                      className="text-emerald-700 font-bold hover:underline flex items-center gap-1"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>{p.ownerName}</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>

            {/* 7-STEP VERIFIED PROPERTY ONBOARDING WIZARD */}
            <PropertyOnboardingWizard
              isOpen={isAddPropertyOpen || !!editingProperty}
              onClose={() => {
                setIsAddPropertyOpen(false);
                setEditingProperty(null);
              }}
              initialData={editingProperty}
              onSave={(savedProperty) => {
                if (editingProperty) {
                  const updated = properties.map((p) =>
                    p.id === editingProperty.id ? savedProperty : p
                  );
                  saveAdminProperties(updated);
                  setProperties(updated);
                  setEditingProperty(null);
                } else {
                  const updated = [savedProperty, ...properties];
                  saveAdminProperties(updated);
                  setProperties(updated);
                  setIsAddPropertyOpen(false);
                }
              }}
            />
          </div>
        )}

        {/* TAB 4: PERFORMANCE GOALS */}
        {activeTab === 'performance' && (
          <div className="space-y-6 animate-in fade-in max-w-2xl">
            <h1 className="text-2xl font-bold font-display text-stone-900">
              My Monthly Concierge Goals
            </h1>

            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/90 shadow-sm space-y-6 text-xs">
              <div className="space-y-2">
                <div className="flex justify-between font-bold text-stone-800">
                  <span>Target Bookings Converted (This Month)</span>
                  <span className="text-[#2D5016]">4 / 6 Bookings (66%)</span>
                </div>
                <div className="w-full h-3 bg-stone-100 rounded-full overflow-hidden">
                  <div className="w-2/3 h-full bg-[#2D5016] rounded-full" />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between font-bold text-stone-800">
                  <span>2-Hour WhatsApp SLA Compliance</span>
                  <span className="text-emerald-700">96.8%</span>
                </div>
                <div className="w-full h-3 bg-stone-100 rounded-full overflow-hidden">
                  <div className="w-[96.8%] h-full bg-emerald-600 rounded-full" />
                </div>
              </div>

              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-900 font-semibold space-y-1">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-700" />
                  <span>High Performer Badge</span>
                </div>
                <p className="text-[11px] text-emerald-800 font-normal">
                  Your rapid responses to Naggar & Coorg inquiries have earned praise in guest surveys. Keep up the great work!
                </p>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
