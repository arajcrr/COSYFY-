import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Mail, CheckCircle2, AlertCircle, ArrowLeft } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { CosyfyLogo } from '../components/common/CosyfyLogo';

export const ForgotPassword: React.FC = () => {
  const { sendPasswordReset } = useAuth();
  const [sent, setSent] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<{ email: string }>();

  const onSubmit = async (data: { email: string }) => {
    setErrorMsg(null);
    setLoading(true);
    try {
      await sendPasswordReset(data.email);
      setSent(true);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err?.message || 'Failed to send password reset email.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-3xl p-8 border border-stone-200 shadow-xl space-y-6">
        <div className="text-center space-y-2">
          <CosyfyLogo size="md" className="mx-auto" />
          <h1 className="text-xl font-bold font-display text-stone-900 pt-2">
            Reset Your Password
          </h1>
          <p className="text-xs text-stone-500">
            Enter your email and we will send you a link to reset your account password.
          </p>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {sent ? (
          <div className="text-center py-6 space-y-3">
            <CheckCircle2 className="w-12 h-12 text-[#2D5016] mx-auto animate-bounce" />
            <h3 className="text-sm font-bold text-stone-900">Reset Email Sent!</h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Check your inbox for password reset instructions.
            </p>
            <Link
              to="/login"
              className="inline-block mt-2 px-5 py-2 rounded-xl bg-[#2D5016] text-white text-xs font-semibold"
            >
              Return to Login
            </Link>
          </div>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                <input
                  type="email"
                  placeholder="you@gmail.com"
                  {...register('email', { required: 'Email is required' })}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                />
              </div>
              {errors.email && (
                <p className="text-[11px] text-red-500 mt-1">{errors.email.message}</p>
              )}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-[#2D5016] text-white font-bold text-xs hover:bg-[#1F380F] shadow-sm disabled:opacity-50"
            >
              {loading ? 'Sending link...' : 'Send Reset Link'}
            </button>
          </form>
        )}

        <div className="pt-2 text-center">
          <Link
            to="/login"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-[#2D5016]"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Login</span>
          </Link>
        </div>
      </div>
    </div>
  );
};
