import React from 'react';
import { HeroSection } from '../components/home/HeroSection';
import { SearchBar } from '../components/home/SearchBar';
import { HowItWorks } from '../components/home/HowItWorks';
import { WhyCosyfy } from '../components/home/WhyCosyfy';
import { WFMSection } from '../components/home/WFMSection';
import { FeaturedProperties } from '../components/home/FeaturedProperties';
import { FeaturedDestinations } from '../components/home/FeaturedDestinations';
import { Testimonials } from '../components/home/Testimonials';
import { useProperties } from '../hooks/useProperties';

export const Home: React.FC = () => {
  const { allProperties, loading } = useProperties();

  return (
    <div className="min-h-screen">
      {/* 1. Hero Section */}
      <HeroSection />

      {/* 2. Interactive Search Bar */}
      <SearchBar />

      {/* 3. Featured Properties Grid (6 items) */}
      <FeaturedProperties properties={allProperties} loading={loading} />

      {/* 4. How It Works (3 Steps) */}
      <HowItWorks />

      {/* 5. Work From Mountains Spotlight */}
      <WFMSection properties={allProperties} />

      {/* 6. Why Cosyfy (4 Value Cards) */}
      <WhyCosyfy />

      {/* 7. Featured Destinations (6 Region Cards) */}
      <FeaturedDestinations />

      {/* 8. Testimonials (Real Indian Stories) */}
      <Testimonials />
    </div>
  );
};
