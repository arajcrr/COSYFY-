import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ShieldCheck,
  CheckCircle2,
  ChevronDown,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Clock,
  Phone,
  MessageCircle,
  HelpCircle,
  Building,
  Check,
  DollarSign,
  HeartHandshake,
  UserCheck,
  Share2,
  Send,
  Calendar,
} from 'lucide-react';
import { addPropertyLead, PropertyLead } from '../services/adminData';
import { logAuditEvent } from '../services/auth';
import { formatPrice } from '../utils';

const INDIAN_STATES = [
  'Himachal Pradesh',
  'Uttarakhand',
  'Jammu & Kashmir',
  'Ladakh',
  'Kerala',
  'Goa',
  'Karnataka',
  'Tamil Nadu',
  'Maharashtra',
  'Rajasthan',
  'Sikkim',
  'Meghalaya',
  'West Bengal',
  'Assam',
  'Arunachal Pradesh',
  'Nagaland',
  'Manipur',
  'Mizoram',
  'Tripura',
  'Andhra Pradesh',
  'Telangana',
  'Madhya Pradesh',
  'Gujarat',
  'Punjab',
  'Haryana',
  'Uttar Pradesh',
  'Bihar',
  'Odisha',
  'Jharkhand',
  'Chhattisgarh',
];

const PROPERTY_TYPES = [
  'Homestay',
  'Villa',
  'Cottage',
  'Farm Stay',
  'Heritage Stay',
  'Treehouse',
  'Other',
];

const PRICE_RANGES = [
  'Under ₹1000',
  '₹1000-2000',
  '₹2000-4000',
  '₹4000-8000',
  'Above ₹8000',
];

const OTHER_PLATFORMS = ['Airbnb', 'MakeMyTrip', 'Booking.com', 'OYO', 'None'];

const CALL_TIMES = ['Morning 9-12', 'Afternoon 12-4', 'Evening 4-8'];

const REFERRAL_SOURCES = [
  'Google Search',
  'Instagram',
  'WhatsApp Community',
  'Friend or Relative',
  'Facebook',
  'Travel Blog or Article',
  'Other',
];

export const ListYourProperty: React.FC = () => {
  // Form State
  const [ownerName, setOwnerName] = useState('');
  const [mobile, setMobile] = useState('');
  const [sameWhatsapp, setSameWhatsapp] = useState(true);
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [propertyName, setPropertyName] = useState('');
  const [propertyType, setPropertyType] = useState('Homestay');
  const [state, setState] = useState('Himachal Pradesh');
  const [district, setDistrict] = useState('');
  const [approxLocation, setApproxLocation] = useState('');
  const [roomsCount, setRoomsCount] = useState<number>(3);
  const [priceRange, setPriceRange] = useState('₹2000-4000');
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [description, setDescription] = useState('');
  const [bestTimeToCall, setBestTimeToCall] = useState('Morning 9-12');
  const [source, setSource] = useState('Google Search');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedLead, setSubmittedLead] = useState<PropertyLead | null>(null);

  // FAQ Accordion State
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const togglePlatform = (p: string) => {
    if (p === 'None') {
      setSelectedPlatforms(['None']);
      return;
    }
    const filtered = selectedPlatforms.filter((item) => item !== 'None');
    if (filtered.includes(p)) {
      setSelectedPlatforms(filtered.filter((item) => item !== p));
    } else {
      setSelectedPlatforms([...filtered, p]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ownerName.trim() || !mobile.trim() || !propertyName.trim()) {
      alert('Please fill in required fields: Owner Name, Mobile Number, and Property Name.');
      return;
    }

    setIsSubmitting(true);
    const finalWhatsapp = sameWhatsapp ? mobile : whatsapp || mobile;

    setTimeout(() => {
      const created = addPropertyLead({
        ownerName: ownerName.trim(),
        mobile: mobile.trim(),
        whatsapp: finalWhatsapp.trim(),
        email: email.trim(),
        propertyName: propertyName.trim(),
        propertyType,
        state,
        district: district.trim() || 'Central',
        approxLocation: approxLocation.trim(),
        roomsCount: Number(roomsCount) || 1,
        priceRange,
        otherPlatforms: selectedPlatforms.length > 0 ? selectedPlatforms : ['None'],
        description: description.trim(),
        bestTimeToCall,
        source,
        status: 'New',
        notes: `Initial submission from public host portal on ${new Date().toLocaleDateString('en-IN')}`,
      });

      // Internal Alert logged to audit trail
      logAuditEvent(
        'PROPERTY_LEAD_SUBMISSION',
        `New property lead submitted: "${propertyName.trim()}" in ${state} by host ${ownerName.trim()} (${mobile.trim()})`,
        {
          leadId: created.id,
          propertyName: created.propertyName,
          state: created.state,
          phone: created.mobile,
          preferredCallTime: created.bestTimeToCall,
        }
      );

      setIsSubmitting(false);
      setSubmittedLead(created);

      // Scroll to success screen
      const el = document.getElementById('submission-container');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 700);
  };

  const faqs = [
    {
      q: 'Do I need to be on Airbnb to join Cosyfy?',
      a: 'Not at all! Many of our most successful hosts are exclusive to Cosyfy or only host via personal referrals. If you are already on Airbnb, Booking.com, or MakeMyTrip, we can easily sync calendars or coexist without any exclusivity restriction.',
    },
    {
      q: 'What documents do I need to onboard?',
      a: 'Basic verification requires just 2 simple documents: your government ID (Aadhaar or PAN) and proof of property ownership/residence (such as an electricity bill, property tax receipt, or lease). Our onboarding manager assists you with everything over WhatsApp.',
    },
    {
      q: 'How and when do I get paid?',
      a: 'We believe in transparent, timely payouts. You receive direct guest payments at check-in (for standard bookings) or deposited straight into your verified bank/UPI account within 24 hours of guest arrival (for remote properties). We discuss all payout details transparently with you on your onboarding call.',
    },
    {
      q: 'Can I decline a booking?',
      a: 'Yes, absolutely. You retain full control over your calendar and home. Before any booking is finalized, our travel concierge team contacts you to verify room availability and confirm guest details.',
    },
    {
      q: 'What if a guest causes damage?',
      a: 'Every Cosyfy guest passes ID screening before arrival. In the rare event of accidental damage, your assigned relationship manager coordinates immediate security deposit reconciliation and host protection support.',
    },
  ];

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#1A1A1A]">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden bg-[#182a12] text-white pt-20 pb-28 md:py-28 px-4 sm:px-6 lg:px-8">
        {/* Subtle background ambient pattern */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:24px_24px]" />
        
        <div className="max-w-6xl mx-auto relative z-10 text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs sm:text-sm font-semibold shadow-inner">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>Host Community & Partner Program</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold font-display tracking-tight text-white max-w-4xl mx-auto leading-tight sm:leading-tight">
            Grow your homestay bookings.{' '}
            <span className="text-emerald-400">Pay only when you earn.</span>
          </h1>

          <p className="text-base sm:text-xl text-stone-300 max-w-2xl mx-auto font-normal leading-relaxed">
            Join 200+ verified homestay owners across India who trust Cosyfy to fill their
            calendars with respectful, verified travelers.
          </p>

          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="#submission-form"
              className="w-full sm:w-auto px-8 py-4 rounded-full bg-[#C84B31] hover:bg-[#b03f27] text-white font-bold text-sm sm:text-base shadow-lg hover:shadow-xl transition-all hover:scale-105 inline-flex items-center justify-center gap-2"
            >
              <span>Submit Your Property Now</span>
              <ArrowRight className="w-5 h-5" />
            </a>
            <a
              href="#how-it-works"
              className="w-full sm:w-auto px-7 py-4 rounded-full bg-white/10 hover:bg-white/20 text-white font-semibold text-sm sm:text-base border border-white/20 transition-colors inline-flex items-center justify-center gap-2"
            >
              <span>See How It Works</span>
            </a>
          </div>

          {/* Social Proof Badges */}
          <div className="pt-8 flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-xs text-stone-300">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>₹0 Upfront Listing Fee</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>No Monthly Fees</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>24hr Host Support via WhatsApp</span>
            </div>
          </div>
        </div>
      </section>

      {/* THREE BENEFIT CARDS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-14 relative z-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1 */}
          <div className="bg-white rounded-3xl p-8 border border-stone-200 shadow-xl space-y-4 hover:border-emerald-600 transition-all">
            <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-[#2D5016] flex items-center justify-center shadow-inner">
              <DollarSign className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-bold font-display text-stone-900">
              Zero upfront cost
            </h3>
            <p className="text-sm text-stone-600 leading-relaxed">
              List for free. We charge only when a booking is confirmed. No monthly subscriptions,
              no annual fee, no hidden marketing charges.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-white rounded-3xl p-8 border border-stone-200 shadow-xl space-y-4 hover:border-emerald-600 transition-all">
            <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center shadow-inner">
              <UserCheck className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-bold font-display text-stone-900">
              Verified guests only
            </h3>
            <p className="text-sm text-stone-600 leading-relaxed">
              We screen every guest before sending them your way. We verify government IDs and travel
              intent, keeping your family home safe and peaceful.
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-white rounded-3xl p-8 border border-stone-200 shadow-xl space-y-4 hover:border-emerald-600 transition-all">
            <div className="w-14 h-14 rounded-2xl bg-rose-100 text-[#C84B31] flex items-center justify-center shadow-inner">
              <HeartHandshake className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-bold font-display text-stone-900">
              Dedicated support
            </h3>
            <p className="text-sm text-stone-600 leading-relaxed">
              Your personal Cosyfy relationship manager handles guest questions, arrival updates,
              and payment coordination directly via WhatsApp.
            </p>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS FOR OWNERS — 4 STEPS */}
      <section id="how-it-works" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-[#2D5016]">
            Transparent Process
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold font-display text-stone-900">
            How it works for homestay owners
          </h2>
          <p className="text-sm sm:text-base text-stone-600">
            From your first submission to receiving happy travelers in just 4 straightforward steps.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Step 1 */}
          <div className="bg-white p-7 rounded-3xl border border-stone-200/90 shadow-sm relative group hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-full bg-[#2D5016] text-white flex items-center justify-center font-bold text-sm mb-5 shadow">
              1
            </div>
            <h4 className="text-lg font-bold font-display text-stone-900 mb-2">
              Submit your property
            </h4>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
              Free and takes 10 minutes. Provide your basic location, room counts, photos, and preferred call timing.
            </p>
          </div>

          {/* Step 2 */}
          <div className="bg-white p-7 rounded-3xl border border-stone-200/90 shadow-sm relative group hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-full bg-[#2D5016] text-white flex items-center justify-center font-bold text-sm mb-5 shadow">
              2
            </div>
            <h4 className="text-lg font-bold font-display text-stone-900 mb-2">
              We verify & call you
            </h4>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
              Our regional operations team verifies details and calls you within 24 hours to discuss pricing and amenities.
            </p>
          </div>

          {/* Step 3 */}
          <div className="bg-white p-7 rounded-3xl border border-stone-200/90 shadow-sm relative group hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-full bg-[#2D5016] text-white flex items-center justify-center font-bold text-sm mb-5 shadow">
              3
            </div>
            <h4 className="text-lg font-bold font-display text-stone-900 mb-2">
              Live listing & bookings
            </h4>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
              We publish your verified listing on Cosyfy and begin dispatching screened guest enquiries immediately.
            </p>
          </div>

          {/* Step 4 */}
          <div className="bg-white p-7 rounded-3xl border border-stone-200/90 shadow-sm relative group hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-full bg-[#2D5016] text-white flex items-center justify-center font-bold text-sm mb-5 shadow">
              4
            </div>
            <h4 className="text-lg font-bold font-display text-stone-900 mb-2">
              Confirm & get paid
            </h4>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
              You approve every reservation on your schedule and receive direct payments without complicated delays.
            </p>
          </div>
        </div>
      </section>

      {/* PARTNERSHIP MODEL & COMMUNITY SECTION */}
      <section className="py-16 bg-[#F4EFE6] border-y border-stone-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-6 space-y-6">
              <span className="text-xs font-bold uppercase tracking-widest text-[#2D5016]">
                Simple & Fair Partnership
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold font-display text-stone-900 leading-tight">
                Our Partnership Model
              </h2>
              <div className="p-6 rounded-2xl bg-white border border-stone-300/80 shadow-xs space-y-3">
                <p className="text-base sm:text-lg font-medium text-stone-800 leading-relaxed">
                  "Our partnership model is simple and fair. We handle the marketing, the customer verification, and the booking coordination. You focus on hosting. We discuss our partnership terms personally on your onboarding call — no surprises, no hidden conditions."
                </p>
              </div>

              <div className="space-y-3 text-sm text-stone-600">
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-emerald-100 text-[#2D5016] flex items-center justify-center">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span>Zero upfront cost — list your property completely free</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-emerald-100 text-[#2D5016] flex items-center justify-center">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span>Pay only when you earn from confirmed bookings</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-emerald-100 text-[#2D5016] flex items-center justify-center">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span>No monthly fees, no hidden marketing charges</span>
                </div>
              </div>
            </div>

            {/* Real Numbers & Community Section */}
            <div className="lg:col-span-6 bg-white p-7 sm:p-9 rounded-3xl border border-stone-300 shadow-xl space-y-6">
              <div className="border-b border-stone-100 pb-4">
                <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-[#2D5016] text-xs font-bold mb-2">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Real Results Across India</span>
                </span>
                <h3 className="text-xl font-bold font-display text-stone-900">
                  Growing Homestay Revenue Together
                </h3>
              </div>

              <div className="p-6 rounded-2xl bg-[#FAF7F2] border border-stone-200/90 space-y-4">
                <p className="text-sm sm:text-base text-stone-700 leading-relaxed font-medium">
                  Hundreds of homestay owners across India are earning more with Cosyfy. Join them — our team will share real numbers from properties similar to yours on your onboarding call.
                </p>
                <div className="pt-2 border-t border-stone-200 flex flex-wrap gap-4 text-xs font-semibold text-stone-600">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-[#2D5016]" />
                    <span>200+ Active Hosts</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-[#2D5016]" />
                    <span>Himalayas to Western Ghats</span>
                  </div>
                </div>
              </div>

              <div className="text-center pt-2">
                <a
                  href="#submission-form"
                  className="w-full py-3.5 rounded-full bg-[#2D5016] hover:bg-[#1f380f] text-white font-bold text-xs sm:text-sm inline-flex items-center justify-center gap-2 transition-all shadow-md"
                >
                  <span>Submit Details for Your Onboarding Call</span>
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ADDITION 3: PROPERTY SUBMISSION FORM (PUBLIC LEAD CAPTURE) */}
      <section id="submission-form" className="py-20 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div id="submission-container">
          {submittedLead ? (
            /* SUCCESS STATE AFTER SUBMISSION */
            <div className="bg-white rounded-3xl p-8 sm:p-12 border-2 border-[#2D5016] shadow-2xl space-y-6 text-center animate-in zoom-in-95">
              <div className="w-20 h-20 rounded-full bg-emerald-100 text-[#2D5016] mx-auto flex items-center justify-center shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div className="space-y-2 max-w-xl mx-auto">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                  Reference ID: {submittedLead.id}
                </span>
                <h2 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
                  Thank you, {submittedLead.ownerName}! 🎉
                </h2>
                <p className="text-sm sm:text-base text-stone-600 leading-relaxed">
                  We're excited to see <strong>{submittedLead.propertyName}</strong> on Cosyfy. Our team
                  will call you within 24 hours during your preferred time window (
                  <span className="font-semibold text-stone-800">{submittedLead.bestTimeToCall}</span>).
                </p>
              </div>

              {/* WhatsApp Confirmation Message */}
              <div className="max-w-md mx-auto p-5 rounded-2xl bg-emerald-50 border border-emerald-200 text-left space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-[#2D5016]">
                  <MessageCircle className="w-4 h-4 fill-[#2D5016]" />
                  <span>WhatsApp Confirmation Dispatched:</span>
                </div>
                <p className="text-xs text-stone-700 italic bg-white p-3.5 rounded-xl border border-emerald-100">
                  "Namaste {submittedLead.ownerName}! We received your property submission for{' '}
                  {submittedLead.propertyName}. Our team will call you at {submittedLead.mobile} within
                  24 hours during your preferred time ({submittedLead.bestTimeToCall}). Welcome to the
                  Cosyfy family! 🏡"
                </p>
                <p className="text-[11px] text-emerald-800">
                  ✓ Dispatched directly to your dedicated Cosyfy relationship manager
                </p>
              </div>

              {/* Action Buttons & Helpful Links */}
              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4 text-xs font-bold">
                <Link
                  to="/about#verification"
                  className="w-full sm:w-auto px-6 py-3 rounded-full bg-[#2D5016] text-white hover:bg-[#233f11] transition-colors"
                >
                  What makes a great Cosyfy listing →
                </Link>
                <Link
                  to="/properties"
                  className="w-full sm:w-auto px-6 py-3 rounded-full border border-stone-300 text-stone-700 hover:bg-stone-50 transition-colors"
                >
                  Explore Other Verified Homestays
                </Link>
              </div>
            </div>
          ) : (
            /* SUBMISSION FORM */
            <div className="bg-white rounded-3xl p-6 sm:p-10 border border-stone-200 shadow-xl space-y-8">
              <div className="text-center max-w-2xl mx-auto space-y-2">
                <span className="text-xs font-bold uppercase tracking-widest text-[#2D5016]">
                  Join As A Host
                </span>
                <h2 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
                  Submit Your Property Details
                </h2>
                <p className="text-xs sm:text-sm text-stone-600">
                  Tell us a few quick details about your homestay. Our team will verify and follow up
                  to complete your free listing.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6 text-xs sm:text-sm">
                {/* 1. Host Contact Information */}
                <div className="space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-stone-400 border-b border-stone-200 pb-2">
                    1. Owner & Contact Information
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold text-stone-800 mb-1.5">
                        Owner Full Name <span className="text-rose-600">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Rameshwar Singh Thakur"
                        value={ownerName}
                        onChange={(e) => setOwnerName(e.target.value)}
                        className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-stone-800 mb-1.5">
                        Mobile Number <span className="text-rose-600">*</span>
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="e.g. +91 98160 12345"
                        value={mobile}
                        onChange={(e) => setMobile(e.target.value)}
                        className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          id="sameWhatsapp"
                          checked={sameWhatsapp}
                          onChange={(e) => setSameWhatsapp(e.target.checked)}
                          className="w-4 h-4 rounded accent-[#2D5016]"
                        />
                        <label htmlFor="sameWhatsapp" className="text-xs font-medium text-stone-700">
                          WhatsApp number is the same as mobile
                        </label>
                      </div>

                      {!sameWhatsapp && (
                        <div>
                          <label className="block font-semibold text-stone-800 mb-1">
                            WhatsApp Number
                          </label>
                          <input
                            type="tel"
                            placeholder="e.g. +91 98160 54321"
                            value={whatsapp}
                            onChange={(e) => setWhatsapp(e.target.value)}
                            className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                          />
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="block font-semibold text-stone-800 mb-1.5">
                        Email Address (Optional)
                      </label>
                      <input
                        type="email"
                        placeholder="e.g. host@gmail.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                      />
                    </div>
                  </div>
                </div>

                {/* 2. Property Basics */}
                <div className="space-y-4 pt-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-stone-400 border-b border-stone-200 pb-2">
                    2. Property Details & Location
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold text-stone-800 mb-1.5">
                        Property Name <span className="text-rose-600">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Tirthan Valley Pine Cottage"
                        value={propertyName}
                        onChange={(e) => setPropertyName(e.target.value)}
                        className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-stone-800 mb-1.5">
                        Property Type
                      </label>
                      <select
                        value={propertyType}
                        onChange={(e) => setPropertyType(e.target.value)}
                        className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                      >
                        {PROPERTY_TYPES.map((pt) => (
                          <option key={pt} value={pt}>
                            {pt}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold text-stone-800 mb-1.5">State</label>
                      <select
                        value={state}
                        onChange={(e) => setState(e.target.value)}
                        className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                      >
                        {INDIAN_STATES.map((st) => (
                          <option key={st} value={st}>
                            {st}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-semibold text-stone-800 mb-1.5">
                        District / City
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Kullu, Jibhi, Mukteshwar"
                        value={district}
                        onChange={(e) => setDistrict(e.target.value)}
                        className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-800 mb-1.5">
                      Approximate Location / Landmark / Address
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 2 km from Gushaini riverside bridge, near GHNP trail"
                      value={approxLocation}
                      onChange={(e) => setApproxLocation(e.target.value)}
                      className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                    />
                  </div>
                </div>

                {/* 3. Capacity & Pricing */}
                <div className="space-y-4 pt-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-stone-400 border-b border-stone-200 pb-2">
                    3. Rooms & Pricing Overview
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold text-stone-800 mb-1.5">
                        Rooms / Units Available for Booking
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="30"
                        value={roomsCount}
                        onChange={(e) => setRoomsCount(Number(e.target.value))}
                        className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-stone-800 mb-1.5">
                        Price Range per Night
                      </label>
                      <select
                        value={priceRange}
                        onChange={(e) => setPriceRange(e.target.value)}
                        className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                      >
                        {PRICE_RANGES.map((pr) => (
                          <option key={pr} value={pr}>
                            {pr}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Platforms Checklist */}
                  <div>
                    <label className="block font-semibold text-stone-800 mb-2">
                      Currently Listed On Other Platforms
                    </label>
                    <div className="flex flex-wrap gap-2.5">
                      {OTHER_PLATFORMS.map((plat) => {
                        const isChecked = selectedPlatforms.includes(plat);
                        return (
                          <button
                            type="button"
                            key={plat}
                            onClick={() => togglePlatform(plat)}
                            className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all ${
                              isChecked
                                ? 'bg-[#2D5016] text-white border-[#2D5016]'
                                : 'bg-stone-50 text-stone-700 border-stone-300 hover:bg-stone-100'
                            }`}
                          >
                            {isChecked ? `✓ ${plat}` : plat}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-800 mb-1.5">
                      Brief Description of Your Property
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Tell us what makes your homestay special (views, orchard, organic meals, fast internet, pets)..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                    />
                  </div>
                </div>

                {/* 4. Scheduling & Lead Attribution */}
                <div className="space-y-4 pt-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-stone-400 border-b border-stone-200 pb-2">
                    4. Best Time to Speak With Our Team
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold text-stone-800 mb-1.5">
                        Best Time to Call
                      </label>
                      <select
                        value={bestTimeToCall}
                        onChange={(e) => setBestTimeToCall(e.target.value)}
                        className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                      >
                        {CALL_TIMES.map((ct) => (
                          <option key={ct} value={ct}>
                            {ct}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-semibold text-stone-800 mb-1.5">
                        How Did You Hear About Cosyfy?
                      </label>
                      <select
                        value={source}
                        onChange={(e) => setSource(e.target.value)}
                        className="w-full p-3 rounded-xl border border-stone-300 bg-white font-medium focus:outline-none focus:border-[#2D5016]"
                      >
                        {REFERRAL_SOURCES.map((rs) => (
                          <option key={rs} value={rs}>
                            {rs}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Submit CTA */}
                <div className="pt-4">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 rounded-2xl bg-[#C84B31] hover:bg-[#b03f27] text-white font-bold text-sm sm:text-base shadow-lg hover:shadow-xl transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Submitting Your Homestay Details...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Submit — Our team will call within 24 hours</span>
                      </>
                    )}
                  </button>
                  <p className="text-[11px] text-stone-500 text-center mt-2.5">
                    By submitting, you agree to receive a verification call from a Cosyfy relationship manager.
                  </p>
                </div>
              </form>
            </div>
          )}
        </div>
      </section>

      {/* FAQ SECTION FOR OWNERS */}
      <section className="py-16 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
          <span className="text-xs font-bold uppercase tracking-widest text-[#2D5016]">
            Questions & Answers
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
            Frequently Asked Questions by Hosts
          </h2>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, index) => {
            const isOpen = openFaq === index;
            return (
              <div
                key={faq.q}
                className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs transition-all"
              >
                <button
                  type="button"
                  onClick={() => setOpenFaq(isOpen ? null : index)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 font-bold text-sm text-stone-900 hover:text-[#2D5016]"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-stone-500 transition-transform ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 text-xs sm:text-sm text-stone-600 leading-relaxed border-t border-stone-100 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* CTA AT BOTTOM */}
      <section className="py-16 bg-[#1f380f] text-white text-center px-4">
        <div className="max-w-2xl mx-auto space-y-5">
          <h2 className="text-2xl sm:text-4xl font-bold font-display">
            Ready to welcome verified guests to your homestay?
          </h2>
          <p className="text-xs sm:text-sm text-emerald-100/90">
            Join hundreds of mountain and rural retreat owners thriving with Cosyfy.
          </p>
          <div>
            <a
              href="#submission-form"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-white text-[#2D5016] font-bold text-sm sm:text-base shadow-lg hover:bg-emerald-50 transition-all hover:scale-105"
            >
              <span>Submit Your Property Now</span>
              <ArrowRight className="w-5 h-5" />
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
