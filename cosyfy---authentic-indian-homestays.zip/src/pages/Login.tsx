import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Lock, Mail, AlertCircle, Loader2, ArrowRight, ShieldCheck, Info } from 'lucide-react';
import { CosyfyLogo } from '../components/common/CosyfyLogo';
import {
  authenticateUser,
  getActiveSession,
  getRedirectPathForRole,
  DEMO_CREDENTIALS,
  UserRole,
} from '../services/auth';

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successInfo, setSuccessInfo] = useState<{ portalName: string; path: string } | null>(null);
  const [showForgotMsg, setShowForgotMsg] = useState(false);

  // If already logged into an active session, redirect to authorized dashboard
  React.useEffect(() => {
    const session = getActiveSession();
    if (session) {
      const path = getRedirectPathForRole(session.user.role);
      navigate(path, { replace: true });
    }
  }, [navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setShowForgotMsg(false);

    if (!email.trim() || !password.trim()) {
      setErrorMessage('Please enter both email and password.');
      return;
    }

    setIsLoading(true);

    try {
      const { user, redirectPath } = await authenticateUser(email, password);

      let portalName = 'Employee Concierge Desk';
      if (user.role === UserRole.SUPER_ADMIN) {
        portalName = 'Super Administrator Central';
      } else if (user.role === UserRole.ADMIN) {
        portalName = 'Operations Admin Dashboard';
      }

      setSuccessInfo({ portalName, path: redirectPath });

      // Short delay to display which portal is detected as requested
      setTimeout(() => {
        navigate(redirectPath, { replace: true });
      }, 1000);
    } catch (err: any) {
      setErrorMessage(err.message || 'Invalid credentials. Please verify your email and password.');
      setIsLoading(false);
    }
  };

  const fillDemo = (role: 'super' | 'admin' | 'employee') => {
    setErrorMessage(null);
    setShowForgotMsg(false);
    if (role === 'super') {
      setEmail(DEMO_CREDENTIALS.superAdmin.email);
      setPassword(DEMO_CREDENTIALS.superAdmin.password);
    } else if (role === 'admin') {
      setEmail(DEMO_CREDENTIALS.admin.email);
      setPassword(DEMO_CREDENTIALS.admin.password);
    } else {
      setEmail(DEMO_CREDENTIALS.employee.email);
      setPassword(DEMO_CREDENTIALS.employee.password);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4 sm:p-6 bg-[#FAF7F2]">
      <div className="max-w-md w-full bg-white rounded-3xl p-8 sm:p-10 border border-stone-200/90 shadow-xl space-y-6 animate-in fade-in zoom-in-95">
        {/* Centered Cosyfy Logo */}
        <div className="text-center space-y-3">
          <div className="flex justify-center">
            <CosyfyLogo size="lg" />
          </div>
          <div>
            <h1 className="text-2xl font-bold font-display text-stone-900">
              Cosyfy Portal Login
            </h1>
            <p className="text-xs text-stone-500 mt-1">
              Sign in with your organizational credentials. Role will be auto-detected.
            </p>
          </div>
        </div>

        {/* Success Portal Notification */}
        {successInfo && (
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-[#2D5016] flex items-center gap-3 animate-in fade-in">
            <ShieldCheck className="w-5 h-5 shrink-0 text-[#2D5016]" />
            <div>
              <p className="font-bold">Access Granted!</p>
              <p className="text-[11px] text-stone-600">
                Opening <span className="font-bold text-[#2D5016]">{successInfo.portalName}</span>...
              </p>
            </div>
          </div>
        )}

        {/* Error Notification */}
        {errorMessage && (
          <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center gap-2.5 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Forgot Password Message */}
        {showForgotMsg && (
          <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-800 flex items-center gap-2.5 animate-in fade-in">
            <Info className="w-4 h-4 shrink-0 text-amber-600" />
            <span>Contact your Super Administrator at admin@cosyfy.in to reset credentials.</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleLogin} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-stone-700 mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@cosyfy.in"
                required
                className="w-full pl-10 pr-3.5 py-3 rounded-xl border border-stone-300 font-medium text-stone-800 placeholder-stone-400 focus:outline-none focus:border-[#C84B31] focus:ring-1 focus:ring-[#C84B31]"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block font-bold text-stone-700">Password</label>
              <button
                type="button"
                onClick={() => setShowForgotMsg(true)}
                className="text-[11px] text-[#C84B31] hover:underline font-semibold"
              >
                Forgot password?
              </button>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                required
                className="w-full pl-10 pr-3.5 py-3 rounded-xl border border-stone-300 font-medium text-stone-800 placeholder-stone-400 focus:outline-none focus:border-[#C84B31] focus:ring-1 focus:ring-[#C84B31]"
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading || Boolean(successInfo)}
              className="w-full py-3.5 px-4 rounded-xl bg-[#C84B31] hover:bg-[#AF3E25] text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying Credentials...</span>
                </>
              ) : (
                <>
                  <span>Sign In to Cosyfy</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </form>

        {/* Quick Demo Credentials Panel for Review & Testing */}
        <div className="pt-4 border-t border-stone-100 space-y-2">
          <div className="flex items-center justify-between text-[11px] text-stone-500">
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              Demo Role Fast-Fill
            </span>
            <span className="text-[10px] bg-stone-100 px-2 py-0.5 rounded text-stone-600">
              Auto-Detects Role
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 text-xs">
            <button
              type="button"
              onClick={() => fillDemo('super')}
              className="p-2 rounded-xl bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-900 font-bold text-[11px] transition-colors"
            >
              Super Admin
            </button>
            <button
              type="button"
              onClick={() => fillDemo('admin')}
              className="p-2 rounded-xl bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-900 font-bold text-[11px] transition-colors"
            >
              Admin
            </button>
            <button
              type="button"
              onClick={() => fillDemo('employee')}
              className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-900 font-bold text-[11px] transition-colors"
            >
              Employee
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
