import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Calendar, MapPin, Users, MessageCircle, ArrowRight, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { getUserBookingsFromFirestore } from '../services/firebase';
import { Booking } from '../types';
import { formatPrice, getWhatsAppUrl } from '../utils';

export const MyBookings: React.FC = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loadingBookings, setLoadingBookings] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
      return;
    }

    async function load() {
      if (!user) return;
      try {
        const data = await getUserBookingsFromFirestore(user.uid);
        setBookings(data);
      } catch (err) {
        console.warn('Could not load user bookings from firestore:', err);
      } finally {
        setLoadingBookings(false);
      }
    }

    load();
  }, [user, loading, navigate]);

  if (loading || loadingBookings) {
    return (
      <div className="max-w-4xl mx-auto py-20 px-4 space-y-4 animate-pulse">
        <div className="h-8 bg-stone-200 rounded w-1/3" />
        <div className="h-32 bg-stone-100 rounded-3xl" />
        <div className="h-32 bg-stone-100 rounded-3xl" />
      </div>
    );
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-[#2D5016]">Confirmed</span>;
      case 'declined':
        return <span className="px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-700">Declined</span>;
      case 'contacting_host':
        return <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800">Checking Host</span>;
      default:
        return <span className="px-3 py-1 rounded-full text-xs font-bold bg-stone-100 text-stone-700">Pending</span>;
    }
  };

  const whatsappNum = import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210';

  return (
    <div className="py-12 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-stone-900 font-display">
          My Reservations & Stays
        </h1>
        <p className="text-xs sm:text-sm text-stone-500 mt-1">
          Track the status of your homestay booking requests and chat directly with host families
        </p>
      </div>

      {bookings.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-stone-200 space-y-4 max-w-md mx-auto">
          <Calendar className="w-12 h-12 text-stone-400 mx-auto" />
          <h3 className="text-lg font-bold text-stone-900 font-display">No reservations yet</h3>
          <p className="text-xs text-stone-500">
            Explore authentic Indian homestays and send a zero-fee booking request!
          </p>
          <Link
            to="/properties"
            className="inline-block px-5 py-2.5 rounded-xl bg-[#2D5016] text-white text-xs font-bold"
          >
            Explore Verified Stays
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {bookings.map((b) => {
            const whatsappMsg = `Hi Cosyfy! Regarding my booking (${b.bookingReference}) for ${b.propertyName}:`;
            const whatsappUrl = getWhatsAppUrl(whatsappNum, whatsappMsg);

            return (
              <div
                key={b.id || b.bookingReference}
                className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-xs hover:shadow-md transition-shadow space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-3">
                  <div>
                    <span className="text-[10px] uppercase font-mono font-bold text-stone-400 block">
                      Booking Reference
                    </span>
                    <span className="text-base font-extrabold text-[#C84B31] font-mono">
                      {b.bookingReference}
                    </span>
                  </div>
                  <div>{getStatusBadge(b.status)}</div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div>
                    <span className="text-stone-400 block">Property & Location</span>
                    <strong className="text-stone-900 text-sm">{b.propertyName}</strong>
                    <p className="text-stone-500">{b.propertyLocation}</p>
                  </div>

                  <div>
                    <span className="text-stone-400 block">Dates & Duration</span>
                    <strong className="text-stone-900">
                      {b.checkIn} to {b.checkOut}
                    </strong>
                    <p className="text-stone-500">
                      {b.nights} nights • {b.adults} Adults
                    </p>
                  </div>

                  <div>
                    <span className="text-stone-400 block">Price Details</span>
                    <strong className="text-stone-900 text-sm">
                      {formatPrice(b.totalPrice)}
                    </strong>
                    <p className="text-[#2D5016] font-semibold">
                      Advance: {formatPrice(b.advanceDeposit)} (10%)
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-stone-100 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-xs text-stone-500">
                    <ShieldCheck className="w-4 h-4 text-[#2D5016]" />
                    <span>Zero service fee guaranteed</span>
                  </div>

                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#25D366] text-white text-xs font-bold hover:bg-[#20ba59] shadow-xs"
                  >
                    <MessageCircle className="w-3.5 h-3.5 fill-white" />
                    <span>WhatsApp Concierge</span>
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
