import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { User, Phone, MapPin, Coffee, CheckCircle2, Shield, Calendar, Heart } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserProfile } from '../types';

export const Profile: React.FC = () => {
  const { user, profile, loading, updateProfileData, logout, isAdmin, savedPropertyIds } = useAuth();
  const navigate = useNavigate();
  const [success, setSuccess] = useState(false);
  const [saving, setSaving] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<Partial<UserProfile>>({
    defaultValues: {
      fullName: profile?.fullName || '',
      phone: profile?.phone || '',
      whatsapp: profile?.whatsapp || '',
      city: profile?.city || '',
      dietaryPreference: profile?.dietaryPreference || 'Veg',
      bio: profile?.bio || '',
    },
  });

  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
    }
    if (profile) {
      reset({
        fullName: profile.fullName,
        phone: profile.phone,
        whatsapp: profile.whatsapp,
        city: profile.city,
        dietaryPreference: profile.dietaryPreference || 'Veg',
        bio: profile.bio || '',
      });
    }
  }, [user, profile, loading, navigate, reset]);

  if (loading || !user) {
    return (
      <div className="max-w-2xl mx-auto py-20 text-center animate-pulse">
        <div className="w-16 h-16 bg-stone-200 rounded-full mx-auto mb-4" />
        <div className="h-6 bg-stone-200 rounded w-48 mx-auto" />
      </div>
    );
  }

  const onSubmit = async (data: Partial<UserProfile>) => {
    setSaving(true);
    try {
      await updateProfileData(data);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (e) {
      console.error(e);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="py-12 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Profile Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-5 text-center sm:text-left">
          <div className="w-20 h-20 rounded-full bg-[#2D5016] text-white flex items-center justify-center font-bold text-2xl uppercase shadow-md">
            {profile?.fullName ? profile.fullName.charAt(0) : 'U'}
          </div>
          <div>
            <div className="flex items-center gap-2 justify-center sm:justify-start">
              <h1 className="text-xl sm:text-2xl font-bold text-stone-900 font-display">
                {profile?.fullName || 'Cosyfy Traveler'}
              </h1>
              {isAdmin && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 flex items-center gap-1">
                  <Shield className="w-3 h-3" /> Admin
                </span>
              )}
            </div>
            <p className="text-xs text-stone-500">{user.email}</p>
            <p className="text-[11px] text-[#2D5016] font-semibold mt-1">
              Member of Cosyfy Homestay Network
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/my-bookings')}
            className="px-4 py-2.5 rounded-xl border border-stone-300 text-xs font-semibold text-stone-700 hover:bg-stone-50"
          >
            My Reservations
          </button>
          <button
            onClick={() => logout()}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50"
          >
            Log Out
          </button>
        </div>
      </div>

      {/* Main Profile Form */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-sm space-y-6">
        <div className="flex items-center justify-between border-b border-stone-100 pb-4">
          <div>
            <h2 className="text-lg font-bold text-stone-900 font-display">
              Personal Information & Homestay Preferences
            </h2>
            <p className="text-xs text-stone-500">
              Pre-fills your booking requests for faster confirmation with host families.
            </p>
          </div>
          {success && (
            <span className="flex items-center gap-1 text-xs text-[#2D5016] font-bold">
              <CheckCircle2 className="w-4 h-4" />
              <span>Saved!</span>
            </span>
          )}
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Full Name</label>
              <input
                type="text"
                {...register('fullName', { required: 'Name is required' })}
                className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
              />
              {errors.fullName && (
                <p className="text-[11px] text-red-500 mt-1">{errors.fullName.message}</p>
              )}
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1">Email Address</label>
              <input
                type="email"
                disabled
                value={user.email || ''}
                className="w-full p-3 rounded-xl border border-stone-200 bg-stone-50 font-medium text-stone-500 cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1">Phone Number</label>
              <input
                type="tel"
                placeholder="10-digit number"
                {...register('phone')}
                className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1">WhatsApp Number</label>
              <input
                type="tel"
                placeholder="For booking confirmation updates"
                {...register('whatsapp')}
                className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1">Current Living City</label>
              <input
                type="text"
                placeholder="e.g. Bangalore, Delhi, Pune"
                {...register('city')}
                className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1">Default Meal Preference</label>
              <select
                {...register('dietaryPreference')}
                className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
              >
                <option value="Veg">Pure Vegetarian (Desi ghee / Pahadi food)</option>
                <option value="Non-Veg">Non-Vegetarian</option>
                <option value="Vegan">Vegan</option>
                <option value="No preference">No preference</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-bold text-stone-700 mb-1">
              About You & Travel Style (Bio)
            </label>
            <textarea
              rows={3}
              placeholder="Tell host families a little about yourself (e.g., Software engineer who loves quiet mountain walks and homecooked thalis)..."
              {...register('bio')}
              className="w-full p-3 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-3 rounded-xl bg-[#2D5016] text-white font-bold text-xs hover:bg-[#1F380F] shadow-sm disabled:opacity-50"
            >
              {saving ? 'Saving Changes...' : 'Save Profile Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
