import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Filter,
  X,
  RotateCcw,
  Search,
  MessageCircle,
  SlidersHorizontal,
  Wifi,
  Sparkles,
} from 'lucide-react';
import { useProperties } from '../hooks/useProperties';
import { PropertyCard } from '../components/common/PropertyCard';
import { PropertyGridSkeleton } from '../components/common/LoadingSkeleton';
import { Region, Amenity } from '../types';
import { formatPrice, getWhatsAppUrl } from '../utils';

export const Properties: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const initialDest = searchParams.get('destination') || '';
  const initialRegion = (searchParams.get('region') as Region) || 'All';
  const initialGuests = Number(searchParams.get('guests')) || 1;

  const {
    properties,
    loading,
    filters,
    updateFilters,
    resetFilters,
  } = useProperties({
    destination: initialDest,
    region: initialRegion,
    guests: initialGuests,
  });

  const regions: Region[] = ['All', 'Hills', 'Beach', 'Forest', 'Heritage', 'Desert', 'Village'];

  const allAmenities: Amenity[] = [
    'WiFi',
    'AC',
    'Heater',
    'Meals',
    'Parking',
    'Pet Friendly',
    'Mountain View',
    'Bonfire',
    'Work Desk',
    'Private Bathroom',
  ];

  const handleAmenityToggle = (amenity: Amenity) => {
    const exists = filters.amenities.includes(amenity);
    const updated = exists
      ? filters.amenities.filter((a) => a !== amenity)
      : [...filters.amenities, amenity];
    updateFilters({ amenities: updated });
  };

  const whatsappNum = import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210';
  const emptyWhatsAppUrl = getWhatsAppUrl(
    whatsappNum,
    `Hi Cosyfy! I was looking for a homestay in "${filters.destination || 'India'}" with my preferences, but found no matches. Can you check offline inventory?`
  );

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Page Title & Region Pills */}
      <div className="mb-8 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-4xl font-bold text-[#1A1A1A] font-display">
              All Verified Homestays
            </h1>
            <p className="text-xs sm:text-sm text-stone-600 mt-1">
              Personally inspected properties across India. No hidden service charges.
            </p>
          </div>

          {/* Mobile Filter Button */}
          <button
            onClick={() => setMobileFilterOpen(true)}
            className="md:hidden inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-stone-300 text-stone-800 text-xs font-semibold shadow-xs self-start"
          >
            <SlidersHorizontal className="w-4 h-4 text-[#2D5016]" />
            <span>Filters ({filters.amenities.length + (filters.wfhReady ? 1 : 0) + (filters.notOnAirbnb ? 1 : 0)})</span>
          </button>
        </div>

        {/* Region Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {regions.map((reg) => (
            <button
              key={reg}
              onClick={() => updateFilters({ region: reg })}
              className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                filters.region === reg
                  ? 'bg-[#2D5016] text-white shadow-sm'
                  : 'bg-white text-stone-700 hover:bg-stone-200/60 border border-stone-200'
              }`}
            >
              {reg === 'All' ? 'All Regions' : reg}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* DESKTOP FILTER SIDEBAR */}
        <aside className="hidden md:block col-span-1 space-y-6 bg-white rounded-3xl p-6 border border-stone-200/90 shadow-sm h-fit sticky top-28">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100">
            <div className="flex items-center gap-2 font-bold text-sm text-stone-900 font-display">
              <Filter className="w-4 h-4 text-[#2D5016]" />
              <span>Filters</span>
            </div>
            <button
              onClick={resetFilters}
              className="text-[11px] font-semibold text-[#C84B31] hover:underline flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </div>

          {/* Destination Search */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-stone-500">
              Destination
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="City, village or region..."
                value={filters.destination}
                onChange={(e) => updateFilters({ destination: e.target.value })}
                className="w-full pl-9 pr-3 py-2 text-xs font-semibold text-stone-800 rounded-xl border border-stone-300 focus:outline-none focus:border-[#2D5016]"
              />
            </div>
          </div>

          {/* Price Range Slider */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <label className="font-bold uppercase tracking-wider text-stone-500 text-[11px]">
                Max Price per night
              </label>
              <span className="font-extrabold text-[#2D5016]">
                {formatPrice(filters.priceRange[1])}
              </span>
            </div>
            <input
              type="range"
              min={1000}
              max={15000}
              step={500}
              value={filters.priceRange[1]}
              onChange={(e) => updateFilters({ priceRange: [500, Number(e.target.value)] })}
              className="w-full accent-[#2D5016] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-stone-400">
              <span>₹500</span>
              <span>₹15,000+</span>
            </div>
          </div>

          {/* Guests Count */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-stone-500">
              Guests
            </label>
            <select
              value={filters.guests}
              onChange={(e) => updateFilters({ guests: Number(e.target.value) })}
              className="w-full p-2 text-xs font-semibold text-stone-800 rounded-xl border border-stone-300 focus:outline-none focus:border-[#2D5016]"
            >
              {[1, 2, 3, 4, 5, 6, 8, 10].map((num) => (
                <option key={num} value={num}>
                  {num} {num === 1 ? 'Guest' : 'Guests or more'}
                </option>
              ))}
            </select>
          </div>

          {/* Special Toggles */}
          <div className="space-y-3 pt-2 border-t border-stone-100">
            <label className="flex items-center justify-between text-xs cursor-pointer group">
              <div className="flex items-center gap-2">
                <Wifi className="w-4 h-4 text-emerald-600" />
                <span className="font-medium text-stone-800">WFH Ready Only</span>
              </div>
              <input
                type="checkbox"
                checked={filters.wfhReady}
                onChange={(e) => updateFilters({ wfhReady: e.target.checked })}
                className="w-4 h-4 rounded text-[#2D5016] accent-[#2D5016]"
              />
            </label>

            <label className="flex items-center justify-between text-xs cursor-pointer group">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#C84B31]" />
                <span className="font-medium text-stone-800">Not On Airbnb</span>
              </div>
              <input
                type="checkbox"
                checked={filters.notOnAirbnb}
                onChange={(e) => updateFilters({ notOnAirbnb: e.target.checked })}
                className="w-4 h-4 rounded text-[#2D5016] accent-[#2D5016]"
              />
            </label>
          </div>

          {/* Amenities Checkboxes */}
          <div className="space-y-2 pt-2 border-t border-stone-100">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-stone-500">
              Key Amenities
            </label>
            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {allAmenities.map((amenity) => (
                <label
                  key={amenity}
                  className="flex items-center gap-2 text-xs text-stone-700 cursor-pointer hover:text-stone-900"
                >
                  <input
                    type="checkbox"
                    checked={filters.amenities.includes(amenity)}
                    onChange={() => handleAmenityToggle(amenity)}
                    className="w-3.5 h-3.5 rounded text-[#2D5016] accent-[#2D5016]"
                  />
                  <span>{amenity}</span>
                </label>
              ))}
            </div>
          </div>
        </aside>

        {/* PROPERTY LISTINGS MAIN AREA */}
        <main className="col-span-1 md:col-span-3 space-y-6">
          {/* Top Sort & Count Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-stone-200/80 shadow-xs">
            <span className="text-xs font-semibold text-stone-600">
              Showing <strong className="text-stone-900">{properties.length}</strong> homestays
              {filters.destination && ` in "${filters.destination}"`}
            </span>

            {/* Sort Select */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-stone-500 font-medium">Sort by:</span>
              <select
                value={filters.sortBy}
                onChange={(e) => updateFilters({ sortBy: e.target.value as any })}
                className="font-bold text-stone-800 bg-stone-50 px-3 py-1.5 rounded-xl border border-stone-200 focus:outline-none"
              >
                <option value="recommended">Recommended</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="rating">Top Rated</option>
              </select>
            </div>
          </div>

          {/* Properties Grid */}
          {loading ? (
            <PropertyGridSkeleton count={6} />
          ) : properties.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {properties.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          ) : (
            /* Empty State */
            <div className="bg-white rounded-3xl p-10 text-center border border-stone-200 space-y-4 max-w-lg mx-auto my-12">
              <div className="w-16 h-16 rounded-full bg-stone-100 flex items-center justify-center mx-auto text-stone-400">
                <Search className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-stone-900 font-display">
                No exact stays matching those filters
              </h3>
              <p className="text-xs text-stone-500 leading-relaxed">
                We have over 40 offline homestays across Himachal, Uttarakhand, and South India waiting for digital verification. Message us directly on WhatsApp and we will find your stay.
              </p>
              <div className="pt-2 flex flex-col sm:flex-row gap-2 justify-center">
                <button
                  onClick={resetFilters}
                  className="px-4 py-2.5 rounded-xl border border-stone-300 text-stone-700 text-xs font-semibold hover:bg-stone-50"
                >
                  Clear All Filters
                </button>
                <a
                  href={emptyWhatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-2.5 rounded-xl bg-[#25D366] text-white text-xs font-bold hover:bg-[#20ba59] flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <MessageCircle className="w-4 h-4 fill-white" />
                  <span>Ask Concierge on WhatsApp</span>
                </a>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* MOBILE FILTER DRAWER */}
      {mobileFilterOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end md:hidden">
          <div className="w-4/5 max-w-sm bg-white h-full p-6 overflow-y-auto space-y-6 animate-in slide-in-from-right">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="font-bold text-stone-900 text-base font-display">Filter Stays</h3>
              <button onClick={() => setMobileFilterOpen(false)} className="p-1">
                <X className="w-5 h-5 text-stone-500" />
              </button>
            </div>

            {/* Mobile filter controls */}
            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Destination</label>
                <input
                  type="text"
                  placeholder="Location..."
                  value={filters.destination}
                  onChange={(e) => updateFilters({ destination: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-stone-300"
                />
              </div>

              <div>
                <div className="flex justify-between font-bold text-stone-700 mb-1">
                  <span>Max Nightly Rate</span>
                  <span className="text-[#2D5016]">{formatPrice(filters.priceRange[1])}</span>
                </div>
                <input
                  type="range"
                  min={1000}
                  max={15000}
                  step={500}
                  value={filters.priceRange[1]}
                  onChange={(e) => updateFilters({ priceRange: [500, Number(e.target.value)] })}
                  className="w-full accent-[#2D5016]"
                />
              </div>

              <label className="flex items-center justify-between font-bold text-stone-800">
                <span>WFH Ready Only</span>
                <input
                  type="checkbox"
                  checked={filters.wfhReady}
                  onChange={(e) => updateFilters({ wfhReady: e.target.checked })}
                  className="w-4 h-4 accent-[#2D5016]"
                />
              </label>

              <label className="flex items-center justify-between font-bold text-stone-800">
                <span>Cosyfy Exclusive</span>
                <input
                  type="checkbox"
                  checked={filters.notOnAirbnb}
                  onChange={(e) => updateFilters({ notOnAirbnb: e.target.checked })}
                  className="w-4 h-4 accent-[#2D5016]"
                />
              </label>

              <div className="pt-4 border-t border-stone-200 flex gap-2">
                <button
                  onClick={resetFilters}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 font-semibold"
                >
                  Reset
                </button>
                <button
                  onClick={() => setMobileFilterOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-[#2D5016] text-white font-semibold"
                >
                  Show Results
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
