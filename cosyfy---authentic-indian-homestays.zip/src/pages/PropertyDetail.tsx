import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  MapPin,
  Star,
  ShieldCheck,
  Users,
  Bed,
  Bath,
  ArrowLeft,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Navigation,
} from 'lucide-react';
import { fetchPropertyById } from '../services/airtable';
import { Property } from '../types';
import { ImageGallery } from '../components/property/ImageGallery';
import { BookingPanel } from '../components/property/BookingPanel';
import { AmenitiesGrid } from '../components/property/AmenitiesGrid';
import { HostInfo } from '../components/property/HostInfo';
import { ReviewSection } from '../components/property/ReviewSection';

export const PropertyDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [property, setProperty] = useState<Property | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedDesc, setExpandedDesc] = useState(false);

  useEffect(() => {
    async function load() {
      if (!id) return;
      setLoading(true);
      const data = await fetchPropertyById(id);
      setProperty(data);
      setLoading(false);
    }
    load();
    window.scrollTo(0, 0);
  }, [id]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 animate-pulse space-y-6">
        <div className="h-6 w-36 bg-stone-200 rounded" />
        <div className="h-10 w-2/3 bg-stone-200 rounded" />
        <div className="aspect-[16/9] w-full bg-stone-200 rounded-3xl" />
      </div>
    );
  }

  if (!property) {
    return (
      <div className="max-w-xl mx-auto px-4 py-24 text-center space-y-4">
        <h2 className="text-2xl font-bold font-display text-stone-900">
          Homestay Not Found
        </h2>
        <p className="text-sm text-stone-600">
          This property might have been unlisted or the link is incorrect.
        </p>
        <Link
          to="/properties"
          className="inline-block px-6 py-2.5 rounded-xl bg-[#2D5016] text-white text-xs font-bold"
        >
          Browse All Stays
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Back button */}
      <Link
        to="/properties"
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-[#2D5016] transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to all stays</span>
      </Link>

      {/* Property Heading Header */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#2D5016] text-white">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
            <span>Cosyfy Verified Homestay</span>
          </span>
          <span className="text-xs text-stone-500">• ID & Address Inspected</span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-bold text-[#1A1A1A] font-display">
          {property.name}
        </h1>

        <div className="flex flex-wrap items-center justify-between gap-4 text-xs text-stone-600">
          <div className="flex flex-wrap items-center gap-4">
            {/* Rating */}
            <div className="flex items-center gap-1 font-bold text-stone-900">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              <span>{property.rating.toFixed(1)}</span>
              <span className="text-stone-500 font-normal">({property.reviewCount} reviews)</span>
            </div>

            {/* Location & Google Maps Link */}
            <a
              href={property.googleMapsUrl || `https://maps.google.com/?q=${encodeURIComponent(property.location)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-[#2D5016] font-semibold hover:underline"
            >
              <MapPin className="w-4 h-4 shrink-0" />
              <span>{property.address || property.location}</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          {/* Capacity stats */}
          <div className="flex items-center gap-4 text-stone-700 font-medium">
            <span className="flex items-center gap-1">
              <Users className="w-4 h-4 text-stone-400" />
              <span>Max {property.maxGuests} Guests</span>
            </span>
            <span className="flex items-center gap-1">
              <Bed className="w-4 h-4 text-stone-400" />
              <span>{property.bedrooms} Bedrooms</span>
            </span>
            <span className="flex items-center gap-1">
              <Bath className="w-4 h-4 text-stone-400" />
              <span>{property.bathrooms} Bathrooms</span>
            </span>
          </div>
        </div>
      </div>

      {/* Image / Video Gallery */}
      <ImageGallery
        images={property.images}
        videoUrl={property.videoUrl}
        propertyName={property.name}
      />

      {/* Main Grid: Details Left, Sticky Booking Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 pt-4">
        {/* LEFT COLUMN: 2 Cols on large screens */}
        <div className="lg:col-span-2 space-y-10">
          {/* Tagline & Description */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-[#1A1A1A] font-display">
              About this homestay
            </h2>
            <div className="prose prose-stone text-xs sm:text-sm text-stone-700 leading-relaxed whitespace-pre-line">
              {expandedDesc
                ? property.description
                : `${property.description.slice(0, 360)}...`}
            </div>
            {property.description.length > 360 && (
              <button
                onClick={() => setExpandedDesc(!expandedDesc)}
                className="inline-flex items-center gap-1 text-xs font-bold text-[#2D5016] hover:underline"
              >
                <span>{expandedDesc ? 'Show Less' : 'Read Full Description'}</span>
                {expandedDesc ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>
            )}
          </div>

          {/* Amenities Grid */}
          <AmenitiesGrid amenities={property.amenities} />

          {/* Location & Surrounding Area */}
          <div className="space-y-4 pt-6 border-t border-stone-200">
            <h3 className="text-xl font-bold text-[#1A1A1A] font-display">
              Where you will be
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
              {property.surroundingArea || `${property.name} is nestled in ${property.location}.`}
            </p>

            {/* Embedded Google Map */}
            <div className="rounded-3xl overflow-hidden border border-stone-200 shadow-xs aspect-[16/9] w-full bg-stone-100">
              <iframe
                title={`Map of ${property.name}`}
                width="100%"
                height="100%"
                frameBorder="0"
                style={{ border: 0 }}
                src={
                  property.mapEmbedUrl ||
                  `https://maps.google.com/maps?q=${encodeURIComponent(property.location)}&t=&z=13&ie=UTF8&iwloc=&output=embed`
                }
                allowFullScreen
                loading="lazy"
              />
            </div>

            {/* Transit Distances & Nearby Attractions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-2">
              <div className="bg-white p-4 rounded-2xl border border-stone-200 space-y-2">
                <span className="font-bold text-stone-900 flex items-center gap-1.5">
                  <Navigation className="w-3.5 h-3.5 text-[#2D5016]" />
                  <span>Transit Distances</span>
                </span>
                <ul className="space-y-1 text-stone-600">
                  {property.distances.railway && <li>• Railway: {property.distances.railway}</li>}
                  {property.distances.airport && <li>• Airport: {property.distances.airport}</li>}
                  {property.distances.busStand && <li>• Bus Stand: {property.distances.busStand}</li>}
                </ul>
              </div>

              {property.nearbyAttractions.length > 0 && (
                <div className="bg-white p-4 rounded-2xl border border-stone-200 space-y-2">
                  <span className="font-bold text-stone-900 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-[#C84B31]" />
                    <span>Nearby Attractions</span>
                  </span>
                  <ul className="space-y-1 text-stone-600">
                    {property.nearbyAttractions.map((att) => (
                      <li key={att}>• {att}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* About the Host */}
          <HostInfo host={property.host} propertyName={property.name} />

          {/* House Rules */}
          <div className="space-y-4 pt-6 border-t border-stone-200">
            <h3 className="text-xl font-bold text-[#1A1A1A] font-display">
              House Rules & Timings
            </h3>
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="bg-white p-4 rounded-2xl border border-stone-200">
                <span className="text-stone-400 block">Check-in</span>
                <strong className="text-stone-800 text-sm">{property.houseRules.checkInTime}</strong>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-stone-200">
                <span className="text-stone-400 block">Check-out</span>
                <strong className="text-stone-800 text-sm">{property.houseRules.checkOutTime}</strong>
              </div>
            </div>
            <ul className="space-y-2 text-xs sm:text-sm text-stone-600 pt-1">
              {property.houseRules.policies.map((p, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-[#2D5016] font-bold">✓</span>
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Reviews Section */}
          <ReviewSection
            rating={property.rating}
            reviewCount={property.reviewCount}
            reviews={property.reviews}
            propertyName={property.name}
          />
        </div>

        {/* RIGHT COLUMN: Sticky Booking Panel */}
        <div className="lg:col-span-1">
          <BookingPanel property={property} />
        </div>
      </div>
    </div>
  );
};
