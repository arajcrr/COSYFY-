import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Compass } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useProperties } from '../hooks/useProperties';
import { PropertyCard } from '../components/common/PropertyCard';

export const SavedStays: React.FC = () => {
  const { savedPropertyIds } = useAuth();
  const { allProperties } = useProperties();

  const savedList = allProperties.filter((p) => savedPropertyIds.includes(p.id));

  return (
    <div className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
      <div>
        <div className="flex items-center gap-2">
          <Heart className="w-6 h-6 text-[#C84B31] fill-[#C84B31]" />
          <h1 className="text-2xl sm:text-3xl font-bold text-stone-900 font-display">
            My Wishlist & Saved Stays ({savedList.length})
          </h1>
        </div>
        <p className="text-xs sm:text-sm text-stone-500 mt-1">
          Handpicked homestays you loved. Saved across sessions for your next Indian journey.
        </p>
      </div>

      {savedList.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-stone-200 space-y-4 max-w-md mx-auto">
          <div className="w-16 h-16 rounded-full bg-orange-50 text-[#C84B31] flex items-center justify-center mx-auto">
            <Heart className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-stone-900 font-display">
            Your wishlist is empty
          </h3>
          <p className="text-xs text-stone-500">
            Click the heart icon on any homestay card to save it here for later.
          </p>
          <Link
            to="/properties"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#2D5016] text-white text-xs font-bold"
          >
            <Compass className="w-4 h-4" />
            <span>Browse Homestays</span>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {savedList.map((property) => (
            <PropertyCard key={property.id} property={property} />
          ))}
        </div>
      )}
    </div>
  );
};
