import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Lock, Mail, User, Phone, AlertCircle, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { CosyfyLogo } from '../components/common/CosyfyLogo';
import { validateIndianPhone } from '../utils';

interface SignUpForm {
  fullName: string;
  email: string;
  phone: string;
  password: string;
}

export const SignUp: React.FC = () => {
  const { signUpWithEmail, signInWithGoogle, user } = useAuth();
  const navigate = useNavigate();
  const [authError, setAuthError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  if (user) {
    navigate('/', { replace: true });
  }

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SignUpForm>();

  const onSubmit = async (data: SignUpForm) => {
    setAuthError(null);
    setSubmitting(true);
    try {
      await signUpWithEmail(data.email, data.password, data.fullName, data.phone);
      navigate('/', { replace: true });
    } catch (err: any) {
      console.error(err);
      if (err?.code === 'auth/email-already-in-use') {
        setAuthError('An account with this email already exists.');
      } else {
        setAuthError(err?.message || 'Failed to create account.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setAuthError(null);
    try {
      await signInWithGoogle();
      navigate('/', { replace: true });
    } catch (err: any) {
      console.error(err);
      setAuthError(err?.message || 'Google signup was cancelled.');
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4 sm:p-6">
      <div className="max-w-md w-full bg-white rounded-3xl p-8 sm:p-10 border border-stone-200/90 shadow-xl space-y-6">
        <div className="text-center space-y-2">
          <CosyfyLogo size="md" className="mx-auto" />
          <h1 className="text-2xl font-bold font-display text-stone-900 pt-2">
            Create Your Cosyfy Account
          </h1>
          <p className="text-xs text-stone-500">
            Book verified homestays, save wishlists, and connect directly with local host families
          </p>
        </div>

        {authError && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{authError}</span>
          </div>
        )}

        {/* Google Sign In Button */}
        <button
          type="button"
          onClick={handleGoogleSignIn}
          className="w-full py-3 px-4 rounded-xl border border-stone-300 hover:bg-stone-50 font-semibold text-xs text-stone-700 flex items-center justify-center gap-3 transition-colors shadow-xs"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span>Sign up with Google</span>
        </button>

        <div className="relative flex items-center justify-center">
          <div className="border-t border-stone-200 w-full" />
          <span className="bg-white px-3 text-[11px] text-stone-400 font-semibold uppercase absolute">
            or with email
          </span>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-stone-700 mb-1">Full Name</label>
            <div className="relative">
              <User className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Rohan Mehra"
                {...register('fullName', { required: 'Please enter your full name' })}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
              />
            </div>
            {errors.fullName && (
              <p className="text-[11px] text-red-500 mt-1">{errors.fullName.message}</p>
            )}
          </div>

          <div>
            <label className="block font-bold text-stone-700 mb-1">Email</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="email"
                placeholder="rohan@gmail.com"
                {...register('email', { required: 'Please enter your email' })}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
              />
            </div>
            {errors.email && (
              <p className="text-[11px] text-red-500 mt-1">{errors.email.message}</p>
            )}
          </div>

          <div>
            <label className="block font-bold text-stone-700 mb-1">Mobile / WhatsApp Number</label>
            <div className="relative">
              <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="tel"
                placeholder="9876543210"
                {...register('phone', {
                  required: 'Phone number is required',
                  validate: (v) => validateIndianPhone(v) || 'Please enter valid 10-digit number',
                })}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
              />
            </div>
            {errors.phone && (
              <p className="text-[11px] text-red-500 mt-1">{errors.phone.message}</p>
            )}
          </div>

          <div>
            <label className="block font-bold text-stone-700 mb-1">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="password"
                placeholder="Min 6 characters"
                {...register('password', {
                  required: 'Please choose a password',
                  minLength: { value: 6, message: 'Password must be at least 6 characters' },
                })}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
              />
            </div>
            {errors.password && (
              <p className="text-[11px] text-red-500 mt-1">{errors.password.message}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3 rounded-xl bg-[#2D5016] hover:bg-[#1F380F] text-white font-bold text-xs shadow-md transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <span>{submitting ? 'Creating Profile...' : 'Sign Up'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <p className="text-center text-xs text-stone-500">
          Already have an account?{' '}
          <Link to="/login" className="font-bold text-[#C84B31] hover:underline">
            Log in here
          </Link>
        </p>
      </div>
    </div>
  );
};
