import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Home,
  Calendar,
  Building,
  Users,
  Briefcase,
  BarChart3,
  Wallet,
  Settings,
  Clock,
  LogOut,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Plus,
  ArrowUpRight,
  ChevronRight,
  TrendingUp,
  Download,
  Eye,
  Trash2,
  Edit,
  Shield,
  Phone,
  MessageCircle,
  Mail,
  MapPin,
  Sparkles,
  Wifi,
  Menu,
  X,
  CreditCard,
  DollarSign,
  UserCheck,
  Send,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
} from 'recharts';
import { CosyfyLogo } from '../components/common/CosyfyLogo';
import {
  getActiveSession,
  logoutUser,
  getAuditLogs,
  logAuditAction,
  getStoredEmployees,
  saveStoredEmployees,
  UserRole,
  User,
  AuditLogEntry,
} from '../services/auth';
import {
  getAdminBookings,
  saveAdminBookings,
  updateAdminBooking,
  getAdminCustomers,
  saveAdminCustomers,
  updateAdminCustomer,
  getAdminProperties,
  saveAdminProperties,
  getOwnerPayouts,
  saveOwnerPayouts,
  getPlatformSettings,
  savePlatformSettings,
  getPropertyLeads,
  updatePropertyLead,
  PropertyLead,
  AdminBooking,
  AdminCustomer,
  AdminPropertyItem,
  OwnerPayout,
  PlatformSettings,
} from '../services/adminData';
import { PropertyOnboardingWizard } from '../components/admin/PropertyOnboardingWizard';
import { formatPrice, getWhatsAppUrl } from '../utils';

type NavTab =
  | 'dashboard'
  | 'bookings'
  | 'properties'
  | 'customers'
  | 'employees'
  | 'financials'
  | 'payouts'
  | 'settings'
  | 'audit';

export const SuperAdmin: React.FC = () => {
  const navigate = useNavigate();
  const session = getActiveSession();

  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Data States
  const [bookings, setBookings] = useState<AdminBooking[]>(() => getAdminBookings());
  const [customers, setCustomers] = useState<AdminCustomer[]>(() => getAdminCustomers());
  const [properties, setProperties] = useState<AdminPropertyItem[]>(() => getAdminProperties());
  const [payouts, setPayouts] = useState<OwnerPayout[]>(() => getOwnerPayouts());
  const [employees, setEmployees] = useState<User[]>(() => getStoredEmployees());
  const [settings, setSettings] = useState<PlatformSettings>(() => getPlatformSettings());
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() => getAuditLogs());

  // Filter & Search States for Bookings
  const [bookingSearch, setBookingSearch] = useState('');
  const [bookingStatusFilter, setBookingStatusFilter] = useState('all');
  const [bookingEmpFilter, setBookingEmpFilter] = useState('all');
  const [selectedBookingIds, setSelectedBookingIds] = useState<string[]>([]);
  const [inspectBooking, setInspectBooking] = useState<AdminBooking | null>(null);

  // Customer Filter & Inspection
  const [customerSearch, setCustomerSearch] = useState('');
  const [customerStatusFilter, setCustomerStatusFilter] = useState('all');
  const [inspectCustomer, setInspectCustomer] = useState<AdminCustomer | null>(null);
  const [newCustomerNote, setNewCustomerNote] = useState('');

  // Property Filters & Modal
  const [propertySearch, setPropertySearch] = useState('');
  const [propertyStatusFilter, setPropertyStatusFilter] = useState('all');
  const [editingProperty, setEditingProperty] = useState<AdminPropertyItem | null>(null);
  const [isAddPropertyOpen, setIsAddPropertyOpen] = useState(false);
  const [propertyLeads, setPropertyLeads] = useState<PropertyLead[]>(getPropertyLeads());
  const [selectedLeadToOnboard, setSelectedLeadToOnboard] = useState<PropertyLead | null>(null);
  const [propertySubTab, setPropertySubTab] = useState<'listings' | 'leads'>('listings');

  // Employee Modal
  const [isAddEmployeeOpen, setIsAddEmployeeOpen] = useState(false);
  const [newEmpName, setNewEmpName] = useState('');
  const [newEmpEmail, setNewEmpEmail] = useState('');
  const [newEmpRole, setNewEmpRole] = useState<UserRole>(UserRole.EMPLOYEE);

  // Settings Feedback
  const [settingsSaved, setSettingsSaved] = useState(false);

  const handleLogout = () => {
    logoutUser();
    navigate('/login', { replace: true });
  };

  // -------------------------------------------------------------
  // REVENUE & STATS CALCULATIONS
  // -------------------------------------------------------------
  const totalRevenueThisMonth = useMemo(() => {
    return bookings
      .filter((b) => b.status === 'confirmed' || b.status === 'completed')
      .reduce((sum, b) => sum + b.totalAmount, 0);
  }, [bookings]);

  const commissionEarnedThisMonth = useMemo(() => {
    return bookings
      .filter((b) => b.status === 'confirmed' || b.status === 'completed')
      .reduce((sum, b) => sum + b.commission, 0);
  }, [bookings]);

  const activeBookingsCount = useMemo(() => {
    return bookings.filter((b) => b.status === 'confirmed' || b.status === 'pending').length;
  }, [bookings]);

  const pendingPayoutsTotal = useMemo(() => {
    return payouts
      .filter((p) => p.payoutStatus === 'Pending')
      .reduce((sum, p) => sum + p.netPayoutAmount, 0);
  }, [payouts]);

  const conversionRate = useMemo(() => {
    if (customers.length === 0) return 0;
    const converted = customers.filter((c) => c.leadStatus === 'Converted').length;
    return Math.round((converted / customers.length) * 100);
  }, [customers]);

  // 6-Month Chart Data
  const revenueChartData = [
    { month: 'Nov', revenue: 68000, commission: 6800 },
    { month: 'Dec', revenue: 94000, commission: 9400 },
    { month: 'Jan', revenue: 112000, commission: 11200 },
    { month: 'Feb', revenue: 135000, commission: 13500 },
    { month: 'Mar', revenue: 168000, commission: 16800 },
    { month: 'Apr (Current)', revenue: totalRevenueThisMonth, commission: commissionEarnedThisMonth },
  ];

  // -------------------------------------------------------------
  // BOOKING ACTIONS
  // -------------------------------------------------------------
  const handleApproveBooking = (bookingId: string) => {
    const updated = updateAdminBooking(bookingId, { status: 'confirmed' });
    setBookings(updated);
    if (inspectBooking && inspectBooking.id === bookingId) {
      setInspectBooking({ ...inspectBooking, status: 'confirmed' });
    }
    if (session) {
      logAuditAction(
        session.user.id,
        session.user.name,
        session.user.role,
        'BOOKING_APPROVED',
        `Approved booking ${bookingId}`
      );
    }
  };

  const handleDeclineBooking = (bookingId: string) => {
    const updated = updateAdminBooking(bookingId, { status: 'cancelled' });
    setBookings(updated);
    if (inspectBooking && inspectBooking.id === bookingId) {
      setInspectBooking({ ...inspectBooking, status: 'cancelled' });
    }
    if (session) {
      logAuditAction(
        session.user.id,
        session.user.name,
        session.user.role,
        'BOOKING_DECLINED',
        `Declined/Cancelled booking ${bookingId}`
      );
    }
  };

  const handleBulkApprove = () => {
    if (selectedBookingIds.length === 0) return;
    const updated = bookings.map((b) =>
      selectedBookingIds.includes(b.id) ? { ...b, status: 'confirmed' as const } : b
    );
    saveAdminBookings(updated);
    setBookings(updated);
    setSelectedBookingIds([]);
    if (session) {
      logAuditAction(
        session.user.id,
        session.user.name,
        session.user.role,
        'BULK_BOOKINGS_APPROVED',
        `Bulk approved ${selectedBookingIds.length} bookings`
      );
    }
  };

  const handleReassignBooking = (bookingId: string, employeeName: string) => {
    const emp = employees.find((e) => e.name === employeeName);
    const updated = updateAdminBooking(bookingId, {
      assignedEmployee: employeeName,
      assignedEmployeeId: emp?.employeeId || 'EMP-001',
    });
    setBookings(updated);
  };

  // -------------------------------------------------------------
  // CUSTOMER ACTIONS
  // -------------------------------------------------------------
  const handleAddNoteToCustomer = (customerId: string) => {
    if (!newCustomerNote.trim()) return;
    const cust = customers.find((c) => c.id === customerId);
    if (!cust) return;
    const noteText = `[${new Date().toLocaleDateString('en-IN')}] ${session?.user.name}: ${newCustomerNote.trim()}`;
    const updatedNotes = [noteText, ...cust.notes];
    const updated = updateAdminCustomer(customerId, { notes: updatedNotes });
    setCustomers(updated);
    if (inspectCustomer && inspectCustomer.id === customerId) {
      setInspectCustomer({ ...inspectCustomer, notes: updatedNotes });
    }
    setNewCustomerNote('');
  };

  const handleUpdateCustomerStatus = (
    customerId: string,
    status: AdminCustomer['leadStatus']
  ) => {
    const updated = updateAdminCustomer(customerId, {
      leadStatus: status,
      lastContacted: new Date().toISOString().split('T')[0],
    });
    setCustomers(updated);
    if (inspectCustomer && inspectCustomer.id === customerId) {
      setInspectCustomer({ ...inspectCustomer, leadStatus: status });
    }
  };

  // -------------------------------------------------------------
  // PROPERTY ACTIONS
  // -------------------------------------------------------------
  const handleTogglePropertyActive = (propId: string) => {
    const updated = properties.map((p) =>
      p.id === propId ? { ...p, isActive: !p.isActive } : p
    );
    saveAdminProperties(updated);
    setProperties(updated);
    if (session) {
      const target = updated.find((p) => p.id === propId);
      logAuditAction(
        session.user.id,
        session.user.name,
        session.user.role,
        'PROPERTY_STATUS_TOGGLED',
        `Toggled ${target?.name} active state to ${target?.isActive ? 'Active' : 'Inactive'}`
      );
    }
  };

  const handleDeleteProperty = (propId: string) => {
    if (!window.confirm('Are you sure you want to delete this property listing?')) return;
    const updated = properties.filter((p) => p.id !== propId);
    saveAdminProperties(updated);
    setProperties(updated);
  };

  // -------------------------------------------------------------
  // OWNER PAYOUT ACTIONS
  // -------------------------------------------------------------
  const handleMarkPayoutPaid = (payoutId: string) => {
    const updated = payouts.map((p) =>
      p.id === payoutId
        ? {
            ...p,
            payoutStatus: 'Processed' as const,
            payoutDate: new Date().toISOString().split('T')[0],
          }
        : p
    );
    saveOwnerPayouts(updated);
    setPayouts(updated);
    if (session) {
      logAuditAction(
        session.user.id,
        session.user.name,
        session.user.role,
        'PAYOUT_PROCESSED',
        `Marked host payout ${payoutId} as Paid`
      );
    }
  };

  // -------------------------------------------------------------
  // EMPLOYEE ACTIONS
  // -------------------------------------------------------------
  const handleAddEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmpName.trim() || !newEmpEmail.trim()) return;

    const newEmp: User = {
      id: `usr_emp_${Date.now()}`,
      name: newEmpName.trim(),
      email: newEmpEmail.trim(),
      role: newEmpRole,
      employeeId: `EMP-CS-${String(employees.length + 1).padStart(3, '0')}`,
      createdAt: new Date().toISOString(),
      isActive: true,
      assignedLeads: [],
      department: newEmpRole === UserRole.ADMIN ? 'Operations' : 'Concierge',
    };

    const updated = [...employees, newEmp];
    saveStoredEmployees(updated);
    setEmployees(updated);
    setIsAddEmployeeOpen(false);
    setNewEmpName('');
    setNewEmpEmail('');
  };

  const handleToggleEmployeeActive = (empId: string) => {
    const updated = employees.map((emp) =>
      emp.id === empId ? { ...emp, isActive: !emp.isActive } : emp
    );
    saveStoredEmployees(updated);
    setEmployees(updated);
  };

  // -------------------------------------------------------------
  // SETTINGS SAVE
  // -------------------------------------------------------------
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    savePlatformSettings(settings);
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 3000);
    if (session) {
      logAuditAction(
        session.user.id,
        session.user.name,
        session.user.role,
        'SETTINGS_SAVED',
        'Updated platform configuration'
      );
    }
  };

  // CSV Export Helper
  const exportBookingsToCSV = () => {
    const headers = 'Booking ID,Customer,Phone,Property,CheckIn,CheckOut,Nights,Total,Commission,Status\n';
    const rows = bookings
      .map(
        (b) =>
          `"${b.id}","${b.customerName}","${b.customerPhone}","${b.propertyName}","${b.checkIn}","${b.checkOut}",${b.nights},${b.totalAmount},${b.commission},"${b.status}"`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cosyfy_bookings_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-[#F8F6F0] flex flex-col md:flex-row text-stone-900 font-sans">
      {/* ------------------------------------------------------------- */}
      {/* DESKTOP SIDEBAR NAVIGATION                                   */}
      {/* ------------------------------------------------------------- */}
      <aside className="hidden md:flex flex-col w-64 bg-[#1A1A1A] text-stone-300 border-r border-stone-800 shrink-0">
        <div className="p-6 border-b border-stone-800 flex items-center justify-between">
          <div className="bg-white p-2 rounded-xl">
            <CosyfyLogo size="sm" />
          </div>
          <span className="text-[10px] font-bold uppercase tracking-wider bg-purple-950 text-purple-300 border border-purple-800 px-2 py-0.5 rounded">
            Super Admin
          </span>
        </div>

        {/* User Card */}
        <div className="px-6 py-4 border-b border-stone-800/80 bg-stone-900/40">
          <p className="text-xs font-bold text-white truncate">{session?.user.name}</p>
          <p className="text-[11px] text-stone-400 truncate">{session?.user.email}</p>
          <span className="inline-block mt-1 text-[10px] font-semibold text-emerald-400">
            ● Active Session (24h)
          </span>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto text-xs font-semibold">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'dashboard'
                ? 'bg-[#C84B31] text-white font-bold shadow-sm'
                : 'text-stone-300 hover:bg-stone-800/70 hover:text-white'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('bookings')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'bookings'
                ? 'bg-[#C84B31] text-white font-bold shadow-sm'
                : 'text-stone-300 hover:bg-stone-800/70 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <Calendar className="w-4 h-4" />
              <span>Bookings</span>
            </div>
            <span className="text-[10px] bg-stone-800 text-stone-300 px-1.5 py-0.5 rounded-md font-mono">
              {bookings.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('properties')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'properties'
                ? 'bg-[#C84B31] text-white font-bold shadow-sm'
                : 'text-stone-300 hover:bg-stone-800/70 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <Building className="w-4 h-4" />
              <span>Properties</span>
            </div>
            <span className="text-[10px] bg-stone-800 text-stone-300 px-1.5 py-0.5 rounded-md font-mono">
              {properties.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'customers'
                ? 'bg-[#C84B31] text-white font-bold shadow-sm'
                : 'text-stone-300 hover:bg-stone-800/70 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <Users className="w-4 h-4" />
              <span>Customers & Leads</span>
            </div>
            <span className="text-[10px] bg-stone-800 text-stone-300 px-1.5 py-0.5 rounded-md font-mono">
              {customers.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('employees')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'employees'
                ? 'bg-[#C84B31] text-white font-bold shadow-sm'
                : 'text-stone-300 hover:bg-stone-800/70 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <Briefcase className="w-4 h-4" />
              <span>Employees</span>
            </div>
            <span className="text-[10px] bg-stone-800 text-stone-300 px-1.5 py-0.5 rounded-md font-mono">
              {employees.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('financials')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'financials'
                ? 'bg-[#C84B31] text-white font-bold shadow-sm'
                : 'text-stone-300 hover:bg-stone-800/70 hover:text-white'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Financial Reports</span>
          </button>

          <button
            onClick={() => setActiveTab('payouts')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'payouts'
                ? 'bg-[#C84B31] text-white font-bold shadow-sm'
                : 'text-stone-300 hover:bg-stone-800/70 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <Wallet className="w-4 h-4" />
              <span>Owner Payouts</span>
            </div>
            {payouts.some((p) => p.payoutStatus === 'Pending') && (
              <span className="w-2 h-2 rounded-full bg-amber-400" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'settings'
                ? 'bg-[#C84B31] text-white font-bold shadow-sm'
                : 'text-stone-300 hover:bg-stone-800/70 hover:text-white'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Platform Settings</span>
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors ${
              activeTab === 'audit'
                ? 'bg-[#C84B31] text-white font-bold shadow-sm'
                : 'text-stone-300 hover:bg-stone-800/70 hover:text-white'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Audit Log</span>
          </button>
        </nav>

        {/* Logout Bottom */}
        <div className="p-4 border-t border-stone-800">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-rose-400 hover:bg-rose-950/40 hover:text-rose-300 text-xs font-bold transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* ------------------------------------------------------------- */}
      {/* MOBILE TOP BAR & BOTTOM SHEET                                 */}
      {/* ------------------------------------------------------------- */}
      <div className="md:hidden bg-[#1A1A1A] text-white px-4 py-3 flex items-center justify-between border-b border-stone-800 sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <div className="bg-white p-1 rounded-lg">
            <CosyfyLogo size="sm" />
          </div>
          <span className="text-[10px] font-bold bg-purple-900 text-purple-200 px-1.5 py-0.5 rounded">
            Super Admin
          </span>
        </div>
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2 rounded-lg bg-stone-800 text-stone-200"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden bg-[#1A1A1A] text-white border-b border-stone-800 p-4 space-y-2 z-40 fixed top-14 left-0 right-0 max-h-[80vh] overflow-y-auto">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Home },
            { id: 'bookings', label: 'Bookings', icon: Calendar },
            { id: 'properties', label: 'Properties', icon: Building },
            { id: 'customers', label: 'Customers & Leads', icon: Users },
            { id: 'employees', label: 'Employees', icon: Briefcase },
            { id: 'financials', label: 'Financial Reports', icon: BarChart3 },
            { id: 'payouts', label: 'Owner Payouts', icon: Wallet },
            { id: 'settings', label: 'Platform Settings', icon: Settings },
            { id: 'audit', label: 'Audit Log', icon: Clock },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id as NavTab);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold ${
                  activeTab === item.id ? 'bg-[#C84B31] text-white font-bold' : 'text-stone-300'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2 text-rose-400 text-xs font-bold pt-2 border-t border-stone-800"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* MAIN CONTENT AREA                                             */}
      {/* ------------------------------------------------------------- */}
      <main className="flex-1 p-4 sm:p-8 lg:p-10 overflow-y-auto max-w-7xl mx-auto w-full space-y-8">
        {/* ========================================================= */}
        {/* TAB 1: DASHBOARD OVERVIEW                                 */}
        {/* ========================================================= */}
        {activeTab === 'dashboard' && (
          <div className="space-y-8 animate-in fade-in">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
                  Super Admin Executive Control
                </h1>
                <p className="text-xs text-stone-500 mt-1">
                  Real-time operational health, platform revenue, host payouts, and booking pipeline
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={exportBookingsToCSV}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-stone-300 bg-white hover:bg-stone-50 text-xs font-bold text-stone-700 shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export CSV</span>
                </button>
                <button
                  onClick={() => setIsAddPropertyOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#2D5016] hover:bg-[#1f380f] text-xs font-bold text-white shadow-2xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Property</span>
                </button>
              </div>
            </div>

            {/* TOP STATS ROW (4 CARDS) */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              <div className="bg-white p-5 rounded-3xl border border-stone-200/90 shadow-sm space-y-2">
                <div className="flex items-center justify-between text-stone-400">
                  <span className="text-[11px] font-bold uppercase tracking-wider">Revenue This Month</span>
                  <DollarSign className="w-4 h-4 text-emerald-600" />
                </div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-stone-900 font-display">
                  {formatPrice(totalRevenueThisMonth)}
                </h3>
                <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  <span>+18.4% vs last month</span>
                </span>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-stone-200/90 shadow-sm space-y-2">
                <div className="flex items-center justify-between text-stone-400">
                  <span className="text-[11px] font-bold uppercase tracking-wider">Commission Earned</span>
                  <BarChart3 className="w-4 h-4 text-[#C84B31]" />
                </div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-[#C84B31] font-display">
                  {formatPrice(commissionEarnedThisMonth)}
                </h3>
                <span className="text-[11px] text-stone-500">10% Host platform share</span>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-stone-200/90 shadow-sm space-y-2">
                <div className="flex items-center justify-between text-stone-400">
                  <span className="text-[11px] font-bold uppercase tracking-wider">Active Bookings</span>
                  <Calendar className="w-4 h-4 text-blue-600" />
                </div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-stone-900 font-display">
                  {activeBookingsCount}
                </h3>
                <span className="text-[11px] text-stone-500">Pending & confirmed stays</span>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-stone-200/90 shadow-sm space-y-2">
                <div className="flex items-center justify-between text-stone-400">
                  <span className="text-[11px] font-bold uppercase tracking-wider">Properties Listed</span>
                  <Building className="w-4 h-4 text-[#2D5016]" />
                </div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-stone-900 font-display">
                  {properties.length}
                </h3>
                <span className="text-[11px] text-[#2D5016] font-semibold">100% ID Verified</span>
              </div>
            </div>

            {/* SECOND STATS ROW (4 CARDS) */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              <div className="bg-white p-5 rounded-3xl border border-stone-200/90 shadow-sm space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-400">
                  New Leads Today
                </span>
                <h3 className="text-xl sm:text-2xl font-extrabold text-stone-900 font-display">
                  {customers.filter((c) => c.leadStatus === 'New Lead').length + 3}
                </h3>
                <span className="text-[11px] text-stone-500">WhatsApp & Instagram</span>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-stone-200/90 shadow-sm space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-400">
                  Bookings This Week
                </span>
                <h3 className="text-xl sm:text-2xl font-extrabold text-stone-900 font-display">
                  {bookings.filter((b) => b.status === 'confirmed').length}
                </h3>
                <span className="text-[11px] text-emerald-700 font-semibold">100% advance collected</span>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-stone-200/90 shadow-sm space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-400">
                  Pending Owner Payouts
                </span>
                <h3 className="text-xl sm:text-2xl font-extrabold text-amber-700 font-display">
                  {formatPrice(pendingPayoutsTotal)}
                </h3>
                <span className="text-[11px] text-stone-500">
                  {payouts.filter((p) => p.payoutStatus === 'Pending').length} hosts awaiting transfer
                </span>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-stone-200/90 shadow-sm space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-400">
                  Lead Conversion Rate
                </span>
                <h3 className="text-xl sm:text-2xl font-extrabold text-stone-900 font-display">
                  {conversionRate}%
                </h3>
                <span className="text-[11px] text-[#2D5016] font-semibold">High human-touch assist</span>
              </div>
            </div>

            {/* REVENUE CHART: LAST 6 MONTHS */}
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/90 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-4">
                <div>
                  <h3 className="text-base font-bold text-stone-900 font-display">
                    Platform Revenue & Commission (Last 6 Months)
                  </h3>
                  <p className="text-xs text-stone-500">
                    Gross stay amount vs Cosyfy net commission earnings
                  </p>
                </div>
                <div className="flex items-center gap-4 text-xs font-semibold">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-[#C84B31]" />
                    <span>Gross Revenue</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-[#2D5016]" />
                    <span>Net Commission</span>
                  </div>
                </div>
              </div>

              <div className="h-72 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={revenueChartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0eee8" />
                    <XAxis dataKey="month" stroke="#888" fontSize={11} />
                    <YAxis stroke="#888" fontSize={11} tickFormatter={(val) => `₹${val / 1000}k`} />
                    <Tooltip
                      formatter={(val: any) => formatPrice(Number(val))}
                      contentStyle={{ backgroundColor: '#fff', borderRadius: '16px', border: '1px solid #ddd' }}
                    />
                    <Line
                      type="monotone"
                      dataKey="revenue"
                      name="Gross Stay Amount"
                      stroke="#C84B31"
                      strokeWidth={3}
                      dot={{ r: 5, fill: '#C84B31' }}
                    />
                    <Line
                      type="monotone"
                      dataKey="commission"
                      name="Cosyfy Commission"
                      stroke="#2D5016"
                      strokeWidth={2}
                      dot={{ r: 4, fill: '#2D5016' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* PENDING ACTIONS & RECENT BOOKINGS SPLIT */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* PENDING ACTIONS CARD (1 Col) */}
              <div className="lg:col-span-1 bg-white p-6 rounded-3xl border border-stone-200/90 shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                  <h3 className="text-base font-bold text-stone-900 font-display">
                    Pending Actions Needed
                  </h3>
                  <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">
                    3 Attention Items
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="p-3 rounded-2xl bg-amber-50/80 border border-amber-200/80 space-y-1">
                    <div className="flex items-center justify-between font-bold text-amber-900">
                      <span>Booking Approval Pending</span>
                      <span className="font-mono text-[10px]">CSF-2024-9130</span>
                    </div>
                    <p className="text-[11px] text-stone-600">
                      Coorg Bungalow booking awaiting confirmation on extra cot for family.
                    </p>
                    <button
                      onClick={() => setActiveTab('bookings')}
                      className="text-[11px] text-[#C84B31] font-bold hover:underline pt-1 inline-block"
                    >
                      Review Booking →
                    </button>
                  </div>

                  <div className="p-3 rounded-2xl bg-rose-50/80 border border-rose-200/80 space-y-1">
                    <div className="flex items-center justify-between font-bold text-rose-900">
                      <span>Host Payout Overdue</span>
                      <span className="font-mono text-[10px]">PAY-802</span>
                    </div>
                    <p className="text-[11px] text-stone-600">
                      ₹12,600 remote stay settlement due to Mahesh Thakur (Tirthan).
                    </p>
                    <button
                      onClick={() => setActiveTab('payouts')}
                      className="text-[11px] text-[#C84B31] font-bold hover:underline pt-1 inline-block"
                    >
                      Process Payout →
                    </button>
                  </div>

                  <div className="p-3 rounded-2xl bg-blue-50/80 border border-blue-200/80 space-y-1">
                    <div className="flex items-center justify-between font-bold text-blue-900">
                      <span>Lead Follow-Up Today</span>
                      <span className="font-mono text-[10px]">Deepak Chawla</span>
                    </div>
                    <p className="text-[11px] text-stone-600">
                      Writer retreat query for Landour needs price confirmation.
                    </p>
                    <button
                      onClick={() => setActiveTab('customers')}
                      className="text-[11px] text-[#2D5016] font-bold hover:underline pt-1 inline-block"
                    >
                      Open Customer Profile →
                    </button>
                  </div>
                </div>
              </div>

              {/* RECENT BOOKINGS TABLE (2 Cols) */}
              <div className="lg:col-span-2 bg-white p-6 rounded-3xl border border-stone-200/90 shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                  <div>
                    <h3 className="text-base font-bold text-stone-900 font-display">
                      Recent Bookings (Last 10)
                    </h3>
                    <p className="text-xs text-stone-500">Live booking feed across all verified properties</p>
                  </div>
                  <button
                    onClick={() => setActiveTab('bookings')}
                    className="text-xs font-bold text-[#C84B31] hover:underline"
                  >
                    View All {bookings.length} →
                  </button>
                </div>

                <div className="overflow-x-auto text-xs">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-stone-200 text-[10px] font-bold uppercase tracking-wider text-stone-400">
                        <th className="pb-2">Booking ID</th>
                        <th className="pb-2">Guest</th>
                        <th className="pb-2">Homestay</th>
                        <th className="pb-2">Dates</th>
                        <th className="pb-2">Amount</th>
                        <th className="pb-2">Commission</th>
                        <th className="pb-2">Status</th>
                        <th className="pb-2">Handled By</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {bookings.slice(0, 6).map((b) => (
                        <tr
                          key={b.id}
                          className="hover:bg-stone-50 cursor-pointer transition-colors"
                          onClick={() => {
                            setInspectBooking(b);
                            setActiveTab('bookings');
                          }}
                        >
                          <td className="py-2.5 font-mono font-bold text-stone-800">{b.id}</td>
                          <td className="py-2.5 font-semibold text-stone-900">{b.customerName}</td>
                          <td className="py-2.5 text-stone-600 truncate max-w-[120px]">{b.propertyName}</td>
                          <td className="py-2.5 text-stone-500 whitespace-nowrap">
                            {b.checkIn.substring(5)} to {b.checkOut.substring(5)}
                          </td>
                          <td className="py-2.5 font-bold text-stone-900">{formatPrice(b.totalAmount)}</td>
                          <td className="py-2.5 font-bold text-[#2D5016]">{formatPrice(b.commission)}</td>
                          <td className="py-2.5">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                b.status === 'confirmed'
                                  ? 'bg-emerald-100 text-[#2D5016]'
                                  : b.status === 'pending'
                                  ? 'bg-amber-100 text-amber-800'
                                  : b.status === 'completed'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {b.status.toUpperCase()}
                            </span>
                          </td>
                          <td className="py-2.5 text-stone-500">{b.assignedEmployee}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 2: BOOKINGS MANAGEMENT                                */}
        {/* ========================================================= */}
        {activeTab === 'bookings' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
                  Bookings Master Management
                </h1>
                <p className="text-xs text-stone-500 mt-1">
                  Filter, inspect, approve, reassign, or cancel reservations across all properties
                </p>
              </div>

              {selectedBookingIds.length > 0 && (
                <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 p-2 rounded-2xl">
                  <span className="text-xs font-bold text-[#2D5016] px-2">
                    {selectedBookingIds.length} Selected
                  </span>
                  <button
                    onClick={handleBulkApprove}
                    className="px-3 py-1.5 rounded-xl bg-[#2D5016] text-white text-xs font-bold shadow-xs hover:bg-[#1f380f]"
                  >
                    Bulk Approve
                  </button>
                  <button
                    onClick={() => setSelectedBookingIds([])}
                    className="px-2 py-1 text-xs text-stone-500 hover:text-stone-800"
                  >
                    Clear
                  </button>
                </div>
              )}
            </div>

            {/* Filter Bar */}
            <div className="bg-white p-4 rounded-3xl border border-stone-200/90 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between text-xs">
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search guest name, phone, booking ID..."
                  value={bookingSearch}
                  onChange={(e) => setBookingSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#C84B31]"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                <select
                  value={bookingStatusFilter}
                  onChange={(e) => setBookingStatusFilter(e.target.value)}
                  className="p-2 rounded-xl border border-stone-300 bg-stone-50 font-semibold text-stone-700 cursor-pointer"
                >
                  <option value="all">All Statuses</option>
                  <option value="pending">Pending</option>
                  <option value="confirmed">Confirmed</option>
                  <option value="cancelled">Cancelled</option>
                  <option value="completed">Completed</option>
                </select>

                <select
                  value={bookingEmpFilter}
                  onChange={(e) => setBookingEmpFilter(e.target.value)}
                  className="p-2 rounded-xl border border-stone-300 bg-stone-50 font-semibold text-stone-700 cursor-pointer"
                >
                  <option value="all">All Employees</option>
                  {employees.map((e) => (
                    <option key={e.id} value={e.name}>
                      {e.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Bookings Table */}
            <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden">
              <div className="overflow-x-auto text-xs">
                <table className="w-full text-left">
                  <thead className="bg-stone-50 border-b border-stone-200 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                    <tr>
                      <th className="p-4 w-8">
                        <input
                          type="checkbox"
                          checked={
                            selectedBookingIds.length > 0 &&
                            selectedBookingIds.length === bookings.length
                          }
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedBookingIds(bookings.map((b) => b.id));
                            } else {
                              setSelectedBookingIds([]);
                            }
                          }}
                        />
                      </th>
                      <th className="p-4">Booking ID</th>
                      <th className="p-4">Customer</th>
                      <th className="p-4">Property</th>
                      <th className="p-4">Dates</th>
                      <th className="p-4">Amount</th>
                      <th className="p-4">Commission</th>
                      <th className="p-4">Payment</th>
                      <th className="p-4">Status</th>
                      <th className="p-4">Assigned Agent</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {bookings
                      .filter((b) => {
                        if (bookingStatusFilter !== 'all' && b.status !== bookingStatusFilter) return false;
                        if (bookingEmpFilter !== 'all' && b.assignedEmployee !== bookingEmpFilter) return false;
                        if (
                          bookingSearch &&
                          !b.customerName.toLowerCase().includes(bookingSearch.toLowerCase()) &&
                          !b.id.toLowerCase().includes(bookingSearch.toLowerCase()) &&
                          !b.customerPhone.includes(bookingSearch)
                        ) {
                          return false;
                        }
                        return true;
                      })
                      .map((b) => (
                        <tr key={b.id} className="hover:bg-stone-50/80 transition-colors">
                          <td className="p-4">
                            <input
                              type="checkbox"
                              checked={selectedBookingIds.includes(b.id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedBookingIds([...selectedBookingIds, b.id]);
                                } else {
                                  setSelectedBookingIds(selectedBookingIds.filter((id) => id !== b.id));
                                }
                              }}
                            />
                          </td>
                          <td className="p-4 font-mono font-bold text-stone-900">{b.id}</td>
                          <td className="p-4">
                            <p className="font-semibold text-stone-900">{b.customerName}</p>
                            <a
                              href={getWhatsAppUrl(b.customerPhone.replace(/\D/g, ''), `Namaste ${b.customerName}! Regarding your Cosyfy booking ${b.id}`)}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[11px] text-emerald-700 hover:underline flex items-center gap-1"
                            >
                              <MessageCircle className="w-3 h-3" />
                              <span>{b.customerPhone}</span>
                            </a>
                          </td>
                          <td className="p-4">
                            <p className="font-medium text-stone-800">{b.propertyName}</p>
                            <p className="text-[11px] text-stone-400">{b.propertyLocation}</p>
                          </td>
                          <td className="p-4 whitespace-nowrap">
                            <span className="font-medium text-stone-700">{b.checkIn} to {b.checkOut}</span>
                            <span className="block text-[11px] text-stone-400">({b.nights} nights)</span>
                          </td>
                          <td className="p-4 font-extrabold text-stone-900">{formatPrice(b.totalAmount)}</td>
                          <td className="p-4 font-bold text-[#2D5016]">{formatPrice(b.commission)}</td>
                          <td className="p-4">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                b.paymentStatus === 'paid_full' || b.paymentStatus === 'paid_10_percent'
                                  ? 'bg-emerald-100 text-[#2D5016]'
                                  : b.paymentStatus === 'refunded'
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-stone-100 text-stone-600'
                              }`}
                            >
                              {b.paymentStatus === 'paid_10_percent'
                                ? '10% Paid'
                                : b.paymentStatus === 'paid_full'
                                ? '100% Paid'
                                : b.paymentStatus.toUpperCase()}
                            </span>
                          </td>
                          <td className="p-4">
                            <span
                              className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                                b.status === 'confirmed'
                                  ? 'bg-emerald-100 text-[#2D5016]'
                                  : b.status === 'pending'
                                  ? 'bg-amber-100 text-amber-800'
                                  : b.status === 'completed'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {b.status.toUpperCase()}
                            </span>
                          </td>
                          <td className="p-4">
                            <select
                              value={b.assignedEmployee}
                              onChange={(e) => handleReassignBooking(b.id, e.target.value)}
                              className="text-[11px] p-1.5 rounded-lg border border-stone-200 bg-white"
                            >
                              {employees.map((emp) => (
                                <option key={emp.id} value={emp.name}>
                                  {emp.name}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => setInspectBooking(b)}
                                title="View details"
                                className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-600"
                              >
                                <Eye className="w-4 h-4" />
                              </button>
                              {b.status === 'pending' && (
                                <>
                                  <button
                                    onClick={() => handleApproveBooking(b.id)}
                                    title="Approve booking"
                                    className="p-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-[#2D5016]"
                                  >
                                    <CheckCircle2 className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={() => handleDeclineBooking(b.id)}
                                    title="Decline booking"
                                    className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600"
                                  >
                                    <XCircle className="w-4 h-4" />
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* FULL BOOKING DETAIL SLIDE-OVER */}
            {inspectBooking && (
              <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end">
                <div className="w-full max-w-xl bg-white h-full p-6 sm:p-8 overflow-y-auto space-y-6 animate-in slide-in-from-right duration-300">
                  <div className="flex items-center justify-between border-b border-stone-200 pb-4">
                    <div>
                      <span className="text-[10px] font-bold font-mono text-stone-400">
                        BOOKING DETAILS SLIDE-OVER
                      </span>
                      <h2 className="text-xl font-bold font-display text-stone-900">
                        {inspectBooking.id}
                      </h2>
                    </div>
                    <button
                      onClick={() => setInspectBooking(null)}
                      className="p-2 rounded-full hover:bg-stone-100"
                    >
                      <X className="w-5 h-5 text-stone-500" />
                    </button>
                  </div>

                  {/* Status Banner */}
                  <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-stone-400 uppercase font-bold block">Current Status</span>
                      <span className="text-sm font-bold capitalize text-stone-900">{inspectBooking.status}</span>
                    </div>
                    <div className="flex gap-2">
                      {inspectBooking.status === 'pending' && (
                        <>
                          <button
                            onClick={() => handleApproveBooking(inspectBooking.id)}
                            className="px-3 py-1.5 rounded-xl bg-[#2D5016] text-white text-xs font-bold"
                          >
                            Approve
                          </button>
                          <button
                            onClick={() => handleDeclineBooking(inspectBooking.id)}
                            className="px-3 py-1.5 rounded-xl bg-rose-600 text-white text-xs font-bold"
                          >
                            Decline
                          </button>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Guest Information */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-stone-400">
                      Guest Contact Information
                    </h4>
                    <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 text-xs space-y-2">
                      <div className="flex justify-between">
                        <span className="text-stone-500">Full Name:</span>
                        <strong className="text-stone-900">{inspectBooking.customerName}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stone-500">Phone / WhatsApp:</span>
                        <strong className="text-stone-900">{inspectBooking.customerPhone}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stone-500">Email:</span>
                        <strong className="text-stone-900">{inspectBooking.customerEmail}</strong>
                      </div>
                    </div>
                  </div>

                  {/* Homestay Details */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-stone-400">
                      Homestay & Reservation
                    </h4>
                    <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 text-xs space-y-2">
                      <div className="flex justify-between">
                        <span className="text-stone-500">Property:</span>
                        <strong className="text-stone-900">{inspectBooking.propertyName}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stone-500">Location:</span>
                        <strong className="text-stone-900">{inspectBooking.propertyLocation}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stone-500">Check-in:</span>
                        <strong className="text-stone-900">{inspectBooking.checkIn}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stone-500">Check-out:</span>
                        <strong className="text-stone-900">{inspectBooking.checkOut} ({inspectBooking.nights} nights)</strong>
                      </div>
                    </div>
                  </div>

                  {/* Financial Breakdown */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-stone-400">
                      Financial Breakdown & Commission
                    </h4>
                    <div className="p-4 rounded-2xl bg-[#FAF7F2] border border-stone-200 text-xs space-y-2.5">
                      <div className="flex justify-between">
                        <span className="text-stone-600">Total Stay Amount:</span>
                        <strong className="text-stone-900 font-bold">{formatPrice(inspectBooking.totalAmount)}</strong>
                      </div>
                      <div className="flex justify-between text-[#2D5016]">
                        <span>Cosyfy Platform Commission (10%):</span>
                        <strong className="font-bold">{formatPrice(inspectBooking.commission)}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stone-600">Advance Paid by Guest:</span>
                        <strong className="text-stone-900">{formatPrice(inspectBooking.advancePaid)}</strong>
                      </div>
                      <div className="flex justify-between border-t border-stone-200 pt-2 text-stone-800">
                        <span>Remaining Due to Host on Arrival:</span>
                        <strong className="text-stone-900">{formatPrice(inspectBooking.remainingDue)}</strong>
                      </div>
                    </div>
                  </div>

                  {/* Communication Notes */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-stone-400">
                      Notes & Host Instructions
                    </h4>
                    <p className="text-xs text-stone-700 bg-stone-50 p-4 rounded-2xl border border-stone-200">
                      {inspectBooking.notes || 'No special dietary requests logged.'}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 3: PROPERTIES MANAGEMENT                              */}
        {/* ========================================================= */}
        {activeTab === 'properties' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
                  Property Listings Directory
                </h1>
                <p className="text-xs text-stone-500 mt-1">
                  Manage host profiles, room pricing, commission rates, and WFH readiness tags
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingProperty(null);
                  setSelectedLeadToOnboard(null);
                  setIsAddPropertyOpen(true);
                }}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#2D5016] text-white text-xs font-bold shadow-md hover:bg-[#1f380f]"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Property (7-Step Wizard)</span>
              </button>
            </div>

            {/* Sub-tab navigation */}
            <div className="flex items-center gap-3 border-b border-stone-200 pb-2">
              <button
                onClick={() => setPropertySubTab('listings')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  propertySubTab === 'listings'
                    ? 'bg-[#2D5016] text-white shadow-sm'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                Verified Listings ({properties.length})
              </button>
              <button
                onClick={() => setPropertySubTab('leads')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                  propertySubTab === 'leads'
                    ? 'bg-[#2D5016] text-white shadow-sm'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                <span>Host Submissions / Leads</span>
                <span className="px-1.5 py-0.2 rounded-full bg-emerald-100 text-[#2D5016] text-[10px]">
                  {propertyLeads.length}
                </span>
              </button>
            </div>

            {/* Search & Filter */}
            <div className="bg-white p-4 rounded-3xl border border-stone-200/90 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between text-xs">
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search property name, state, owner..."
                  value={propertySearch}
                  onChange={(e) => setPropertySearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#2D5016]"
                />
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={propertyStatusFilter}
                  onChange={(e) => setPropertyStatusFilter(e.target.value)}
                  className="p-2 rounded-xl border border-stone-300 bg-stone-50 font-semibold text-stone-700"
                >
                  <option value="all">All Properties</option>
                  <option value="active">Active Only</option>
                  <option value="remote">Remote Only</option>
                  <option value="wfh">WFH Ready Only</option>
                </select>
              </div>
            </div>

            {/* Properties Table */}
            <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden">
              <div className="overflow-x-auto text-xs">
                <table className="w-full text-left">
                  <thead className="bg-stone-50 border-b border-stone-200 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                    <tr>
                      <th className="p-4">ID</th>
                      <th className="p-4">Property</th>
                      <th className="p-4">Location</th>
                      <th className="p-4">Host Contact</th>
                      <th className="p-4">Weekday / Wknd</th>
                      <th className="p-4">Commission</th>
                      <th className="p-4">Badges</th>
                      <th className="p-4">Enquiries</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {properties
                      .filter((p) => {
                        if (propertyStatusFilter === 'active' && !p.isActive) return false;
                        if (propertyStatusFilter === 'remote' && !p.isRemoteProperty) return false;
                        if (propertyStatusFilter === 'wfh' && !p.isWfhReady) return false;
                        if (
                          propertySearch &&
                          !p.name.toLowerCase().includes(propertySearch.toLowerCase()) &&
                          !p.location.toLowerCase().includes(propertySearch.toLowerCase()) &&
                          !p.ownerName.toLowerCase().includes(propertySearch.toLowerCase())
                        ) {
                          return false;
                        }
                        return true;
                      })
                      .map((p) => (
                        <tr key={p.id} className="hover:bg-stone-50/80 transition-colors">
                          <td className="p-4 font-mono font-bold text-stone-900">{p.id}</td>
                          <td className="p-4">
                            <div className="flex items-center gap-3">
                              <img
                                src={p.mainImage}
                                alt={p.name}
                                className="w-12 h-10 object-cover rounded-lg border border-stone-200"
                              />
                              <div>
                                <strong className="text-stone-900 block">{p.name}</strong>
                                <span className="text-[10px] text-stone-400">/{p.slug}</span>
                              </div>
                            </div>
                          </td>
                          <td className="p-4 text-stone-600">{p.location}</td>
                          <td className="p-4">
                            <span className="block font-semibold text-stone-800">{p.ownerName}</span>
                            <a
                              href={getWhatsAppUrl(p.ownerWhatsapp.replace(/\D/g, ''), `Namaste ${p.ownerName} ji!`)}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[11px] text-emerald-700 hover:underline flex items-center gap-1"
                            >
                              <MessageCircle className="w-3 h-3" />
                              <span>WhatsApp Host</span>
                            </a>
                          </td>
                          <td className="p-4 font-semibold text-stone-800">
                            {formatPrice(p.weekdayPrice)} / {formatPrice(p.weekendPrice)}
                          </td>
                          <td className="p-4 font-bold text-[#2D5016]">{p.commissionPercent}%</td>
                          <td className="p-4">
                            <div className="flex flex-wrap gap-1">
                              {p.isWfhReady && (
                                <span className="px-1.5 py-0.5 rounded bg-emerald-50 text-[#2D5016] text-[10px] font-bold">
                                  WFH
                                </span>
                              )}
                              {p.isRemoteProperty && (
                                <span className="px-1.5 py-0.5 rounded bg-orange-50 text-[#C84B31] text-[10px] font-bold">
                                  Remote
                                </span>
                              )}
                              {p.isAirbnbListed && (
                                <span className="px-1.5 py-0.5 rounded bg-rose-50 text-rose-700 text-[10px] font-bold">
                                  Airbnb
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-4">
                            <span className="font-bold text-stone-900">{p.enquiriesThisMonth}</span>
                            <span className="text-[10px] text-stone-400 block">({p.bookingsThisMonth} stays)</span>
                          </td>
                          <td className="p-4">
                            <button
                              type="button"
                              onClick={() => handleTogglePropertyActive(p.id)}
                              className={`px-3 py-1 rounded-full text-[10px] font-bold transition-colors ${
                                p.isActive
                                  ? 'bg-emerald-100 text-[#2D5016]'
                                  : 'bg-stone-200 text-stone-600'
                              }`}
                            >
                              {p.isActive ? 'Active' : 'Inactive'}
                            </button>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => setEditingProperty(p)}
                                className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-600"
                                title="Edit Property"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteProperty(p.id)}
                                className="p-1.5 rounded-lg hover:bg-rose-50 text-rose-600"
                                title="Delete Property"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* HOST SUBMISSIONS / PROPERTY LEADS TABLE */}
            {propertySubTab === 'leads' && (
              <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden">
                <div className="p-4 bg-stone-50 border-b border-stone-200 flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-stone-900 text-sm">
                      Host Enquiries & Property Leads (Airtable Sync)
                    </h3>
                    <p className="text-xs text-stone-500">
                      Submissions from the public "/list-your-property" portal. Review and onboard into verified listings.
                    </p>
                  </div>
                </div>

                <div className="overflow-x-auto text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-stone-50 border-b border-stone-200 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                      <tr>
                        <th className="p-4">Lead ID</th>
                        <th className="p-4">Owner & Contact</th>
                        <th className="p-4">Property</th>
                        <th className="p-4">Location</th>
                        <th className="p-4">Units & Rate</th>
                        <th className="p-4">Call Window</th>
                        <th className="p-4">Status</th>
                        <th className="p-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {propertyLeads.map((lead) => (
                        <tr key={lead.id} className="hover:bg-stone-50">
                          <td className="p-4 font-mono font-bold text-stone-800">{lead.id}</td>
                          <td className="p-4">
                            <p className="font-bold text-stone-900">{lead.ownerName}</p>
                            <a
                              href={getWhatsAppUrl(
                                lead.whatsapp,
                                `Namaste ${lead.ownerName}! Following up on your Cosyfy property submission for ${lead.propertyName}:`
                              )}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[11px] text-emerald-700 font-semibold hover:underline flex items-center gap-1 mt-0.5"
                            >
                              <MessageCircle className="w-3 h-3" />
                              <span>{lead.mobile}</span>
                            </a>
                          </td>
                          <td className="p-4">
                            <p className="font-bold text-stone-900">{lead.propertyName}</p>
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-stone-100 text-stone-600 font-semibold">
                              {lead.propertyType}
                            </span>
                          </td>
                          <td className="p-4">
                            <p className="font-semibold text-stone-800">{lead.district}</p>
                            <p className="text-[11px] text-stone-500">{lead.state}</p>
                          </td>
                          <td className="p-4">
                            <span className="font-bold text-stone-900">{lead.roomsCount} units</span>
                            <span className="text-[11px] text-stone-500 block">{lead.priceRange}</span>
                          </td>
                          <td className="p-4 text-stone-700 font-medium">{lead.bestTimeToCall}</td>
                          <td className="p-4">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                lead.status === 'Onboarded'
                                  ? 'bg-emerald-100 text-[#2D5016]'
                                  : lead.status === 'Contacted'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {lead.status}
                            </span>
                          </td>
                          <td className="p-4 text-right">
                            <button
                              onClick={() => {
                                setEditingProperty(null);
                                setSelectedLeadToOnboard(lead);
                                setIsAddPropertyOpen(true);
                              }}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#2D5016] text-white text-xs font-bold hover:bg-[#1f380f] shadow-xs"
                            >
                              <Sparkles className="w-3.5 h-3.5" />
                              <span>Onboard Host (7-Step Wizard)</span>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* 7-STEP VERIFIED PROPERTY ONBOARDING WIZARD */}
            <PropertyOnboardingWizard
              isOpen={isAddPropertyOpen || !!editingProperty}
              onClose={() => {
                setIsAddPropertyOpen(false);
                setEditingProperty(null);
                setSelectedLeadToOnboard(null);
              }}
              initialData={editingProperty}
              fromLead={selectedLeadToOnboard}
              onSave={(savedProperty) => {
                if (editingProperty) {
                  const updated = properties.map((p) =>
                    p.id === editingProperty.id ? savedProperty : p
                  );
                  saveAdminProperties(updated);
                  setProperties(updated);
                  setEditingProperty(null);
                } else {
                  const updated = [savedProperty, ...properties];
                  saveAdminProperties(updated);
                  setProperties(updated);
                  setIsAddPropertyOpen(false);
                  if (selectedLeadToOnboard) {
                    const updatedLeads = updatePropertyLead(selectedLeadToOnboard.id, {
                      status: 'Onboarded',
                    });
                    setPropertyLeads(updatedLeads);
                    setSelectedLeadToOnboard(null);
                  }
                }
              }}
            />
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 4: CUSTOMERS & LEADS MANAGEMENT                       */}
        {/* ========================================================= */}
        {activeTab === 'customers' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
                  Customer & Lead Relationship Manager
                </h1>
                <p className="text-xs text-stone-500 mt-1">
                  Track guest enquiries, follow-up dates, lead stages, and communication history
                </p>
              </div>
            </div>

            {/* Filter Bar */}
            <div className="bg-white p-4 rounded-3xl border border-stone-200/90 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between text-xs">
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search customer name, email, destination..."
                  value={customerSearch}
                  onChange={(e) => setCustomerSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-stone-300 font-medium text-stone-800 focus:outline-none focus:border-[#C84B31]"
                />
              </div>

              <select
                value={customerStatusFilter}
                onChange={(e) => setCustomerStatusFilter(e.target.value)}
                className="p-2 rounded-xl border border-stone-300 bg-stone-50 font-semibold text-stone-700 cursor-pointer"
              >
                <option value="all">All Lead Stages</option>
                <option value="New Lead">New Lead</option>
                <option value="Contacted">Contacted</option>
                <option value="Follow-up Due">Follow-up Due</option>
                <option value="Proposal Sent">Proposal Sent</option>
                <option value="Converted">Converted</option>
                <option value="Lost">Lost</option>
              </select>
            </div>

            {/* Customers Table */}
            <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden">
              <div className="overflow-x-auto text-xs">
                <table className="w-full text-left">
                  <thead className="bg-stone-50 border-b border-stone-200 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                    <tr>
                      <th className="p-4">Customer ID</th>
                      <th className="p-4">Guest</th>
                      <th className="p-4">Lead Status</th>
                      <th className="p-4">Interested In</th>
                      <th className="p-4">Budget / Night</th>
                      <th className="p-4">Source</th>
                      <th className="p-4">Assigned To</th>
                      <th className="p-4">Next Follow-Up</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {customers
                      .filter((c) => {
                        if (customerStatusFilter !== 'all' && c.leadStatus !== customerStatusFilter) return false;
                        if (
                          customerSearch &&
                          !c.name.toLowerCase().includes(customerSearch.toLowerCase()) &&
                          !c.email.toLowerCase().includes(customerSearch.toLowerCase()) &&
                          !c.destinationInterested.toLowerCase().includes(customerSearch.toLowerCase())
                        ) {
                          return false;
                        }
                        return true;
                      })
                      .map((c) => {
                        const isOverdue =
                          new Date(c.nextFollowUp).getTime() <= Date.now() &&
                          c.leadStatus !== 'Converted' &&
                          c.leadStatus !== 'Lost';

                        return (
                          <tr key={c.id} className="hover:bg-stone-50/80 transition-colors">
                            <td className="p-4 font-mono font-bold text-stone-800">{c.id}</td>
                            <td className="p-4">
                              <strong className="text-stone-900 block">{c.name}</strong>
                              <a
                                href={getWhatsAppUrl(c.phone.replace(/\D/g, ''), `Namaste ${c.name}! Cosyfy travel desk here.`)}
                                target="_blank"
                                rel="noreferrer"
                                className="text-[11px] text-emerald-700 hover:underline flex items-center gap-1"
                              >
                                <MessageCircle className="w-3 h-3" />
                                <span>{c.phone}</span>
                              </a>
                            </td>
                            <td className="p-4">
                              <span
                                className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                                  c.leadStatus === 'Converted'
                                    ? 'bg-emerald-100 text-[#2D5016]'
                                    : c.leadStatus === 'New Lead'
                                    ? 'bg-blue-100 text-blue-800'
                                    : c.leadStatus === 'Follow-up Due'
                                    ? 'bg-amber-100 text-amber-800'
                                    : c.leadStatus === 'Proposal Sent'
                                    ? 'bg-purple-100 text-purple-800'
                                    : 'bg-stone-200 text-stone-600'
                                }`}
                              >
                                {c.leadStatus}
                              </span>
                            </td>
                            <td className="p-4 text-stone-700 font-medium">{c.destinationInterested}</td>
                            <td className="p-4 font-bold text-stone-900">{formatPrice(c.budgetPerNight)}</td>
                            <td className="p-4">
                              <span className="text-stone-600 font-semibold">{c.source}</span>
                            </td>
                            <td className="p-4 text-stone-600">{c.assignedEmployee}</td>
                            <td className="p-4">
                              <span
                                className={`font-semibold ${
                                  isOverdue ? 'text-rose-600 font-bold' : 'text-stone-600'
                                }`}
                              >
                                {c.nextFollowUp}
                                {isOverdue && ' (Due)'}
                              </span>
                            </td>
                            <td className="p-4 text-right">
                              <button
                                onClick={() => setInspectCustomer(c)}
                                className="px-3 py-1.5 rounded-xl border border-stone-200 hover:bg-stone-100 text-stone-800 font-bold text-[11px]"
                              >
                                View Profile
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* CUSTOMER PROFILE SLIDE-OVER */}
            {inspectCustomer && (
              <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end">
                <div className="w-full max-w-xl bg-white h-full p-6 sm:p-8 overflow-y-auto space-y-6 animate-in slide-in-from-right duration-300">
                  <div className="flex items-center justify-between border-b border-stone-200 pb-4">
                    <div>
                      <span className="text-[10px] font-bold font-mono text-stone-400">
                        CUSTOMER PROFILE
                      </span>
                      <h2 className="text-xl font-bold font-display text-stone-900">
                        {inspectCustomer.name}
                      </h2>
                    </div>
                    <button
                      onClick={() => setInspectCustomer(null)}
                      className="p-2 rounded-full hover:bg-stone-100"
                    >
                      <X className="w-5 h-5 text-stone-500" />
                    </button>
                  </div>

                  {/* Contact Card */}
                  <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 text-xs space-y-2">
                    <div className="flex justify-between">
                      <span className="text-stone-500">Phone:</span>
                      <strong className="text-stone-900">{inspectCustomer.phone}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500">Email:</span>
                      <strong className="text-stone-900">{inspectCustomer.email}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500">Lead Stage:</span>
                      <select
                        value={inspectCustomer.leadStatus}
                        onChange={(e) =>
                          handleUpdateCustomerStatus(
                            inspectCustomer.id,
                            e.target.value as AdminCustomer['leadStatus']
                          )
                        }
                        className="p-1 rounded-lg border border-stone-300 font-bold text-[#2D5016]"
                      >
                        <option value="New Lead">New Lead</option>
                        <option value="Contacted">Contacted</option>
                        <option value="Follow-up Due">Follow-up Due</option>
                        <option value="Proposal Sent">Proposal Sent</option>
                        <option value="Converted">Converted</option>
                        <option value="Lost">Lost</option>
                      </select>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500">Preferred Region:</span>
                      <strong className="text-stone-900">{inspectCustomer.destinationInterested}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500">Budget / Night:</span>
                      <strong className="text-stone-900">{formatPrice(inspectCustomer.budgetPerNight)}</strong>
                    </div>
                  </div>

                  {/* Add Note */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500">
                      Add Interaction Note
                    </h4>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="e.g. Discussed breakfast options with guest on phone..."
                        value={newCustomerNote}
                        onChange={(e) => setNewCustomerNote(e.target.value)}
                        className="flex-1 p-2.5 rounded-xl border border-stone-300 text-xs"
                      />
                      <button
                        onClick={() => handleAddNoteToCustomer(inspectCustomer.id)}
                        className="px-4 py-2.5 rounded-xl bg-[#2D5016] text-white text-xs font-bold hover:bg-[#1f380f]"
                      >
                        Add Note
                      </button>
                    </div>
                  </div>

                  {/* Notes Timeline */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500">
                      Interaction Log
                    </h4>
                    <div className="space-y-2">
                      {inspectCustomer.notes.map((note, idx) => (
                        <div
                          key={idx}
                          className="p-3 rounded-xl bg-stone-50 border border-stone-200/90 text-xs text-stone-700 leading-relaxed"
                        >
                          {note}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 5: EMPLOYEES MANAGEMENT                               */}
        {/* ========================================================= */}
        {activeTab === 'employees' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
                  Internal Team & Employee Registry
                </h1>
                <p className="text-xs text-stone-500 mt-1">
                  Manage personnel roles (Admin, Employee), active status, and lead assignments
                </p>
              </div>

              <button
                onClick={() => setIsAddEmployeeOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#2D5016] text-white text-xs font-bold shadow-md hover:bg-[#1f380f]"
              >
                <Plus className="w-4 h-4" />
                <span>Add Team Member</span>
              </button>
            </div>

            <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden">
              <div className="overflow-x-auto text-xs">
                <table className="w-full text-left">
                  <thead className="bg-stone-50 border-b border-stone-200 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                    <tr>
                      <th className="p-4">Employee ID</th>
                      <th className="p-4">Name & Email</th>
                      <th className="p-4">Role</th>
                      <th className="p-4">Department</th>
                      <th className="p-4">Active Leads</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {employees.map((emp) => (
                      <tr key={emp.id} className="hover:bg-stone-50/80 transition-colors">
                        <td className="p-4 font-mono font-bold text-stone-900">
                          {emp.employeeId || 'EMP-001'}
                        </td>
                        <td className="p-4">
                          <strong className="text-stone-900 block">{emp.name}</strong>
                          <span className="text-[11px] text-stone-500">{emp.email}</span>
                        </td>
                        <td className="p-4">
                          <span
                            className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                              emp.role === UserRole.SUPER_ADMIN
                                ? 'bg-purple-100 text-purple-800'
                                : emp.role === UserRole.ADMIN
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-emerald-100 text-[#2D5016]'
                            }`}
                          >
                            {emp.role.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="p-4 text-stone-600 font-medium">
                          {emp.department || 'Operations'}
                        </td>
                        <td className="p-4 font-bold text-stone-900">
                          {emp.assignedLeads?.length || 2} Leads
                        </td>
                        <td className="p-4">
                          <button
                            onClick={() => handleToggleEmployeeActive(emp.id)}
                            className={`px-3 py-1 rounded-full text-[10px] font-bold ${
                              emp.isActive
                                ? 'bg-emerald-100 text-[#2D5016]'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {emp.isActive ? 'Active' : 'Deactivated'}
                          </button>
                        </td>
                        <td className="p-4 text-right">
                          <button
                            onClick={() =>
                              alert(`Default password for ${emp.email} in demo mode is password123`)
                            }
                            className="text-xs text-[#C84B31] font-bold hover:underline"
                          >
                            Reset Password
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* ADD EMPLOYEE MODAL */}
            {isAddEmployeeOpen && (
              <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-5 animate-in zoom-in-95">
                  <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                    <h3 className="text-lg font-bold font-display text-stone-900">
                      Add Internal Team Member
                    </h3>
                    <button
                      onClick={() => setIsAddEmployeeOpen(false)}
                      className="p-1.5 rounded-full hover:bg-stone-100"
                    >
                      <X className="w-5 h-5 text-stone-500" />
                    </button>
                  </div>

                  <form onSubmit={handleAddEmployee} className="space-y-4 text-xs">
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Full Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Megha Singhal"
                        value={newEmpName}
                        onChange={(e) => setNewEmpName(e.target.value)}
                        required
                        className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Company Email</label>
                      <input
                        type="email"
                        placeholder="megha@cosyfy.in"
                        value={newEmpEmail}
                        onChange={(e) => setNewEmpEmail(e.target.value)}
                        required
                        className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Portal Role</label>
                      <select
                        value={newEmpRole}
                        onChange={(e) => setNewEmpRole(e.target.value as UserRole)}
                        className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                      >
                        <option value={UserRole.EMPLOYEE}>Employee (Concierge Desk)</option>
                        <option value={UserRole.ADMIN}>Admin (Operations Manager)</option>
                      </select>
                    </div>

                    <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-[11px] text-stone-600">
                      Default demo login password will be set to: <strong>password123</strong>
                    </div>

                    <div className="flex justify-end gap-3 pt-2">
                      <button
                        type="button"
                        onClick={() => setIsAddEmployeeOpen(false)}
                        className="px-4 py-2 rounded-xl border border-stone-300 text-stone-700"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 rounded-xl bg-[#2D5016] text-white font-bold"
                      >
                        Create Employee
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 6: FINANCIAL REPORTS                                  */}
        {/* ========================================================= */}
        {activeTab === 'financials' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
                  Financial Performance & Audit Statements
                </h1>
                <p className="text-xs text-stone-500 mt-1">
                  Gross transaction volumes, 10% commission reconciliation, and host remittances
                </p>
              </div>

              <button
                onClick={exportBookingsToCSV}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#C84B31] text-white text-xs font-bold shadow-md hover:bg-[#AF3E25]"
              >
                <Download className="w-4 h-4" />
                <span>Export Financial Statement (CSV)</span>
              </button>
            </div>

            {/* Financial Overview Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-3xl border border-stone-200/90 shadow-sm space-y-1">
                <span className="text-[11px] uppercase font-bold text-stone-400">Total Processed Stays</span>
                <h3 className="text-2xl font-extrabold text-stone-900 font-display">
                  {formatPrice(totalRevenueThisMonth)}
                </h3>
                <p className="text-xs text-stone-500">Zero service fees charged to guests</p>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-stone-200/90 shadow-sm space-y-1">
                <span className="text-[11px] uppercase font-bold text-stone-400">Cosyfy Net Earnings</span>
                <h3 className="text-2xl font-extrabold text-[#2D5016] font-display">
                  {formatPrice(commissionEarnedThisMonth)}
                </h3>
                <p className="text-xs text-[#2D5016] font-semibold">10% retained from host settlement</p>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-stone-200/90 shadow-sm space-y-1">
                <span className="text-[11px] uppercase font-bold text-stone-400">Host Direct Collections</span>
                <h3 className="text-2xl font-extrabold text-blue-900 font-display">
                  {formatPrice(totalRevenueThisMonth - commissionEarnedThisMonth)}
                </h3>
                <p className="text-xs text-stone-500">Settled directly on arrival or via full prepayment</p>
              </div>
            </div>

            {/* Reconciliation Table */}
            <div className="bg-white rounded-3xl border border-stone-200/90 p-6 space-y-4">
              <h3 className="text-base font-bold text-stone-900 font-display">
                Monthly Breakdown Reconciliation
              </h3>
              <div className="overflow-x-auto text-xs">
                <table className="w-full text-left">
                  <thead className="bg-stone-50 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                    <tr>
                      <th className="p-3">Month</th>
                      <th className="p-3">Completed Stays</th>
                      <th className="p-3">Gross Value</th>
                      <th className="p-3">Guest Service Fee</th>
                      <th className="p-3">Platform Host Share (10%)</th>
                      <th className="p-3">Reconciliation Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {revenueChartData.map((row, idx) => (
                      <tr key={idx} className="hover:bg-stone-50">
                        <td className="p-3 font-bold text-stone-900">{row.month}</td>
                        <td className="p-3 font-mono">{12 + idx * 4} stays</td>
                        <td className="p-3 font-semibold text-stone-900">{formatPrice(row.revenue)}</td>
                        <td className="p-3 font-bold text-emerald-700">₹0 (100% Free)</td>
                        <td className="p-3 font-bold text-[#2D5016]">{formatPrice(row.commission)}</td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-[#2D5016]">
                            Reconciled
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 7: OWNER PAYOUTS                                      */}
        {/* ========================================================= */}
        {activeTab === 'payouts' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
                  Homestay Host Settlements & UPI Payouts
                </h1>
                <p className="text-xs text-stone-500 mt-1">
                  Manage host remittances for 100% upfront remote properties & 10% advance reconciliation
                </p>
              </div>
            </div>

            <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden">
              <div className="overflow-x-auto text-xs">
                <table className="w-full text-left">
                  <thead className="bg-stone-50 border-b border-stone-200 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                    <tr>
                      <th className="p-4">Payout ID</th>
                      <th className="p-4">Homestay & Host</th>
                      <th className="p-4">Stay Dates</th>
                      <th className="p-4">Stay Amount</th>
                      <th className="p-4">Platform Collected</th>
                      <th className="p-4">Cosyfy Fee</th>
                      <th className="p-4">Net Remittance</th>
                      <th className="p-4">Payout Status</th>
                      <th className="p-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {payouts.map((p) => (
                      <tr key={p.id} className="hover:bg-stone-50/80 transition-colors">
                        <td className="p-4 font-mono font-bold text-stone-900">{p.id}</td>
                        <td className="p-4">
                          <strong className="text-stone-900 block">{p.propertyName}</strong>
                          <span className="text-[11px] text-stone-500">
                            {p.ownerName} ({p.ownerUpi})
                          </span>
                        </td>
                        <td className="p-4 text-stone-600">{p.stayDates}</td>
                        <td className="p-4 font-semibold text-stone-900">{formatPrice(p.totalStayAmount)}</td>
                        <td className="p-4 font-semibold text-stone-800">
                          {formatPrice(p.advanceCollectedByPlatform)}
                        </td>
                        <td className="p-4 font-bold text-[#2D5016]">
                          {formatPrice(p.platformCommission)}
                        </td>
                        <td className="p-4 font-extrabold text-[#C84B31]">
                          {formatPrice(p.netPayoutAmount)}
                        </td>
                        <td className="p-4">
                          <span
                            className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                              p.payoutStatus === 'Processed'
                                ? 'bg-emerald-100 text-[#2D5016]'
                                : p.payoutStatus === 'Pending'
                                ? 'bg-amber-100 text-amber-800 animate-pulse'
                                : 'bg-stone-100 text-stone-700'
                            }`}
                          >
                            {p.payoutStatus}
                          </span>
                        </td>
                        <td className="p-4 text-right">
                          {p.payoutStatus === 'Pending' ? (
                            <button
                              onClick={() => handleMarkPayoutPaid(p.id)}
                              className="px-3 py-1.5 rounded-xl bg-[#2D5016] text-white font-bold text-[11px] shadow-xs hover:bg-[#1f380f]"
                            >
                              Mark as Paid
                            </button>
                          ) : (
                            <span className="text-[11px] text-stone-400 font-semibold">Settled</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 8: PLATFORM SETTINGS                                  */}
        {/* ========================================================= */}
        {activeTab === 'settings' && (
          <div className="space-y-6 animate-in fade-in max-w-3xl">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
                Platform Configuration
              </h1>
              <p className="text-xs text-stone-500 mt-1">
                Configure commission structure, live payment credentials, and operational policies
              </p>
            </div>

            {settingsSaved && (
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-[#2D5016] font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>Configuration changes saved successfully!</span>
              </div>
            )}

            <form onSubmit={handleSaveSettings} className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/90 shadow-sm space-y-5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Platform Host Commission (%)
                  </label>
                  <input
                    type="number"
                    value={settings.platformCommissionPercent}
                    onChange={(e) =>
                      setSettings({ ...settings, platformCommissionPercent: Number(e.target.value) })
                    }
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                  />
                  <span className="text-[10px] text-stone-400">Zero service fee to guests is hardcoded.</span>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    WhatsApp Concierge Phone
                  </label>
                  <input
                    type="text"
                    value={settings.supportWhatsapp}
                    onChange={(e) =>
                      setSettings({ ...settings, supportWhatsapp: e.target.value })
                    }
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">
                  Razorpay Key ID
                </label>
                <input
                  type="text"
                  value={settings.razorpayKeyId}
                  onChange={(e) =>
                    setSettings({ ...settings, razorpayKeyId: e.target.value })
                  }
                  placeholder="rzp_live_..."
                  className="w-full p-2.5 rounded-xl border border-stone-300 font-mono text-[11px]"
                />
                <span className="text-[10px] text-stone-400">
                  When populated, checkout instantly upgrades from Demo Sandbox to Live Gateway.
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2 border-t border-stone-100">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Standard Property Refund Window (Days)
                  </label>
                  <input
                    type="number"
                    value={settings.defaultCancellationRefundStandardDays}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        defaultCancellationRefundStandardDays: Number(e.target.value),
                      })
                    }
                    className="w-full p-2.5 rounded-xl border border-stone-300"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Remote Property Refund Window (Days)
                  </label>
                  <input
                    type="number"
                    value={settings.defaultCancellationRefundRemoteDays}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        defaultCancellationRefundRemoteDays: Number(e.target.value),
                      })
                    }
                    className="w-full p-2.5 rounded-xl border border-stone-300"
                  />
                </div>
              </div>

              <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
                <label className="flex items-center gap-2 font-semibold text-stone-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.autoAssignLeads}
                    onChange={(e) =>
                      setSettings({ ...settings, autoAssignLeads: e.target.checked })
                    }
                  />
                  <span>Round-robin automatic lead assignment to concierge employees</span>
                </label>
              </div>

              <div className="flex justify-end pt-4">
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-[#2D5016] text-white font-bold text-xs shadow-md hover:bg-[#1f380f]"
                >
                  Save Platform Settings
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 9: AUDIT LOG                                          */}
        {/* ========================================================= */}
        {activeTab === 'audit' && (
          <div className="space-y-6 animate-in fade-in">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
                System Audit Trail & Security Timeline
              </h1>
              <p className="text-xs text-stone-500 mt-1">
                Immutable record of administrative actions, booking approvals, status updates, and logins
              </p>
            </div>

            <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm p-6 space-y-4">
              <div className="divide-y divide-stone-100 text-xs">
                {auditLogs.map((log) => (
                  <div key={log.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] font-bold text-stone-400">
                          {new Date(log.timestamp).toLocaleString('en-IN')}
                        </span>
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-stone-100 text-stone-700">
                          {log.action}
                        </span>
                      </div>
                      <p className="text-stone-800 font-medium">{log.details}</p>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="font-bold text-stone-900 block">{log.userName}</span>
                      <span className="text-[10px] text-purple-700 font-semibold uppercase">
                        {log.userRole.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
