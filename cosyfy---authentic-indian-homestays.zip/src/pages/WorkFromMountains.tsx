import React, { useState } from 'react';
import {
  Wifi,
  Laptop,
  Signal,
  Zap,
  Volume2,
  MapPin,
  MessageCircle,
  Calculator,
  ChevronDown,
  Sparkles,
  Quote,
  Star,
} from 'lucide-react';
import { useProperties } from '../hooks/useProperties';
import { PropertyCard } from '../components/common/PropertyCard';
import { PropertyGridSkeleton } from '../components/common/LoadingSkeleton';
import { WFM_BENEFITS, WFM_FAQS } from '../data/staticData';
import { getWhatsAppUrl, formatPrice } from '../utils';

export const WorkFromMountains: React.FC = () => {
  const { allProperties, loading } = useProperties({ wfhReady: true });
  const wfhProperties = allProperties.filter((p) => p.wfhReady);

  const [weeks, setWeeks] = useState<number>(2);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  // Pricing calculator estimate: average ~₹1,800/night for long stay
  const estimatedNightlyRate = 1800;
  const totalDays = weeks * 7;
  const estimatedTotal = totalDays * estimatedNightlyRate;
  const estimatedSavings = Math.round(estimatedTotal * 0.25); // 25% long stay discount

  const whatsappNum = import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210';
  const whatsappUrl = getWhatsAppUrl(
    whatsappNum,
    `Hi Cosyfy! I'm planning a mountain workation for ${weeks} weeks. Can you recommend high-speed WiFi homestays with power backup?`
  );

  const verifiedChecklist = [
    { title: 'WiFi Speed Verified', detail: 'Tested at 80–150+ Mbps with dual fiber backups', icon: Wifi },
    { title: 'Network Carrier Coverage', detail: 'Airtel & Jio 5G tested on-site for hotspot tethering', icon: Signal },
    { title: 'Ergonomic Desk & Chair', detail: 'Sturdy wooden table, comfortable chair & natural light', icon: Laptop },
    { title: 'Inverter Power Backup', detail: 'Dedicated battery backup keeping routers live during rain', icon: Zap },
    { title: 'Peaceful Noise Levels', detail: 'Far away from highway trucks and loud commercial bazaars', icon: Volume2 },
    { title: 'Access to Towns', detail: 'Within 15–30 mins of pharmacies, cafes, and taxi stands', icon: MapPin },
  ];

  return (
    <div className="space-y-20 pb-20">
      {/* 1. Dark Green Hero */}
      <section className="bg-[#2D5016] text-white py-24 sm:py-32 relative overflow-hidden">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6 relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md text-xs font-semibold text-emerald-300">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Dedicated Long-Stay Mountain Workations</span>
          </div>

          <h1 className="text-3xl sm:text-5xl md:text-6xl font-bold font-display tracking-tight text-white leading-tight">
            Your office has terrible views. <br />
            <span className="text-amber-200 italic font-serif">We fixed that.</span>
          </h1>

          <p className="max-w-2xl mx-auto text-base sm:text-lg text-stone-200 leading-relaxed">
            Trade concrete cubicles and city smog for pine-covered hills, crisp Himalayan morning chai, and verified high-speed fiber internet.
          </p>

          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-8 py-4 rounded-full bg-[#C84B31] hover:bg-[#AF3E25] text-white font-bold text-sm shadow-xl transition-all duration-200 hover:scale-105 flex items-center gap-2"
            >
              <MessageCircle className="w-5 h-5 fill-white" />
              <span>Find My Mountain Office</span>
            </a>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
        {/* 2. Why WFH From a Homestay (Benefits Grid) */}
        <section className="space-y-12">
          <div className="text-center max-w-3xl mx-auto space-y-2">
            <h2 className="text-3xl sm:text-4xl font-bold text-[#1A1A1A] font-display">
              Why Remote Workers Choose Cosyfy
            </h2>
            <p className="text-sm sm:text-base text-stone-600">
              Unlike generic hostels with loud dorms or overpriced luxury resorts, our homestays offer the comfort of home with the focus of a private retreat.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {WFM_BENEFITS.map((b) => (
              <div
                key={b.title}
                className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-sm hover:shadow-lg transition-all space-y-3"
              >
                <div className="w-12 h-12 rounded-2xl bg-[#2D5016]/10 text-[#2D5016] flex items-center justify-center font-bold">
                  ✓
                </div>
                <h3 className="text-lg font-bold text-[#1A1A1A] font-display">
                  {b.title}
                </h3>
                <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                  {b.desc}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* 3. What We Verify for WFH Properties */}
        <section className="bg-stone-100/70 rounded-3xl p-8 sm:p-12 border border-stone-200 space-y-8">
          <div className="max-w-2xl space-y-2">
            <span className="text-xs font-bold uppercase tracking-widest text-[#2D5016]">
              Zero Guesswork Guarantee
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#1A1A1A] font-display">
              What We Test Before Approving WFH Stays
            </h2>
            <p className="text-xs sm:text-sm text-stone-600">
              A mountain workation fails if the internet cuts out during a production release. Here is our physical checklist:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {verifiedChecklist.map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.title}
                  className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex items-start gap-3.5"
                >
                  <div className="p-2.5 rounded-xl bg-[#2D5016]/10 text-[#2D5016] shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-stone-900">{item.title}</h4>
                    <p className="text-[11px] sm:text-xs text-stone-500 mt-1 leading-snug">
                      {item.detail}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* 4. Remote Worker Testimonial from Bir Billing */}
        <section className="bg-white rounded-3xl p-8 sm:p-12 border border-stone-200 shadow-sm relative">
          <Quote className="w-12 h-12 text-[#2D5016]/10 absolute top-8 right-8" />
          <div className="max-w-3xl space-y-6">
            <div className="flex gap-1 text-amber-400">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star key={s} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>

            <p className="text-base sm:text-xl text-stone-800 italic leading-relaxed font-serif">
              &ldquo;I spent 3 weeks working out of a Cosyfy orchard homestay in Naggar. Shipped a major frontend release without a single zoom disconnect. Every morning Uncle brought black cardamom chai and warm parathas made with home churned butter. My rent was lower than my Bengaluru apartment.&rdquo;
            </p>

            <div className="flex items-center gap-4 pt-2">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80"
                alt="Devika"
                className="w-12 h-12 rounded-full object-cover border-2 border-[#2D5016]"
              />
              <div>
                <h4 className="text-sm font-bold text-stone-900">Devika Nair</h4>
                <p className="text-xs text-stone-500">
                  Lead Software Architect • Remote Worker from Bir Billing & Naggar
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* 5. WFH Property Cards */}
        <section className="space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold text-[#1A1A1A] font-display">
                Featured WFH Mountain Stays
              </h2>
              <p className="text-xs sm:text-sm text-stone-600 mt-1">
                All properties include speed badges, dedicated workspace, and power backup.
              </p>
            </div>
          </div>

          {loading ? (
            <PropertyGridSkeleton count={3} />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {wfhProperties.map((p) => (
                <PropertyCard key={p.id} property={p} showWfmHighlight={true} />
              ))}
            </div>
          )}
        </section>

        {/* 6. Pricing Calculator Section */}
        <section className="bg-white rounded-3xl p-8 sm:p-12 border border-stone-200/90 shadow-lg grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <div className="space-y-4">
            <span className="text-xs font-bold uppercase tracking-widest text-[#C84B31]">
              Transparent Workation Calculator
            </span>
            <h2 className="text-2xl sm:text-4xl font-bold text-stone-900 font-display">
              Calculate Your Mountain Stay
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
              Longer stays unlock exclusive host discounts. Pay a modest advance deposit to reserve; balance paid directly to your host on arrival. No hidden guest fees.
            </p>

            <div className="space-y-3 pt-4">
              <label className="block text-xs font-bold text-stone-700">
                Number of Weeks: <strong className="text-[#2D5016] text-base">{weeks} Weeks ({totalDays} Days)</strong>
              </label>
              <input
                type="range"
                min={1}
                max={8}
                value={weeks}
                onChange={(e) => setWeeks(Number(e.target.value))}
                className="w-full accent-[#2D5016] cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-stone-400">
                <span>1 Week (7d)</span>
                <span>4 Weeks (1 month)</span>
                <span>8 Weeks (2 months)</span>
              </div>
            </div>
          </div>

          {/* Calculator Output Card */}
          <div className="bg-[#FAF7F2] rounded-2xl p-6 sm:p-8 border border-stone-200 space-y-5">
            <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider flex items-center gap-2">
              <Calculator className="w-4 h-4 text-[#2D5016]" />
              <span>Estimated Stay Breakdown</span>
            </h3>

            <div className="space-y-2.5 text-xs text-stone-700">
              <div className="flex justify-between">
                <span>Duration</span>
                <strong>{totalDays} Nights</strong>
              </div>
              <div className="flex justify-between">
                <span>Estimated Nightly Rate</span>
                <strong>~{formatPrice(estimatedNightlyRate)}/night</strong>
              </div>
              <div className="flex justify-between text-[#2D5016]">
                <span>Long-Stay Host Savings</span>
                <strong>Save ~{formatPrice(estimatedSavings)}</strong>
              </div>
              <div className="flex justify-between text-[#2D5016]">
                <span>Cosyfy Platform Fee</span>
                <strong>₹0 (Zero Fee)</strong>
              </div>
              <div className="border-t border-stone-200 pt-3 flex justify-between text-base font-bold text-stone-900">
                <span>Estimated Total</span>
                <span>{formatPrice(estimatedTotal)}</span>
              </div>
            </div>

            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3.5 rounded-xl bg-[#2D5016] hover:bg-[#1F380F] text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>Check Exact Availability for {weeks} Weeks</span>
            </a>
          </div>
        </section>

        {/* 7. FAQ Accordion */}
        <section id="faq" className="max-w-3xl mx-auto space-y-6">
          <div className="text-center space-y-2">
            <h2 className="text-2xl sm:text-3xl font-bold text-stone-900 font-display">
              Frequently Asked Questions
            </h2>
            <p className="text-xs sm:text-sm text-stone-600">
              Everything you need to know before leaving the city behind.
            </p>
          </div>

          <div className="space-y-3">
            {WFM_FAQS.map((faq, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-stone-200 overflow-hidden"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                  className="w-full p-5 text-left font-bold text-sm text-stone-900 flex items-center justify-between gap-4"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-stone-500 transition-transform ${
                      openFaq === idx ? 'rotate-180 text-[#2D5016]' : ''
                    }`}
                  />
                </button>
                {openFaq === idx && (
                  <div className="px-5 pb-5 text-xs sm:text-sm text-stone-600 leading-relaxed border-t border-stone-100 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
