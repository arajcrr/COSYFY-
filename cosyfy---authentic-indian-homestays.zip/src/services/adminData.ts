/**
 * Admin Panel Data Store and State Management
 * Provides persistence and operations for Bookings, Customers/Leads, Properties,
 * Owner Payouts, Financials, and Settings across Super Admin, Admin, and Employee panels.
 */

import { INITIAL_PROPERTIES as staticProperties } from '../data/staticData';

export interface AdminBooking {
  id: string; // CSF-001 format
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  propertyName: string;
  propertyLocation: string;
  propertyId: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  totalAmount: number;
  commission: number; // Cosyfy host commission earnings
  advancePaid: number;
  remainingDue: number;
  paymentStatus: 'paid_10_percent' | 'paid_full' | 'pending' | 'refunded';
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  assignedEmployee: string;
  assignedEmployeeId: string;
  createdAt: string;
  notes?: string;
  isRemote?: boolean;
}

export interface AdminCustomer {
  id: string; // CUST-101 format
  name: string;
  phone: string;
  email: string;
  leadStatus: 'New Lead' | 'Contacted' | 'Follow-up Due' | 'Proposal Sent' | 'Converted' | 'Lost';
  destinationInterested: string;
  budgetPerNight: number;
  requestedCheckIn: string;
  nights: number;
  source: 'Meta Ads' | 'Instagram' | 'WhatsApp' | 'Google Search' | 'Referral';
  assignedEmployee: string;
  assignedEmployeeId: string;
  lastContacted: string;
  nextFollowUp: string; // YYYY-MM-DD
  notes: string[];
  totalBookings: number;
}

export interface OwnerPayout {
  id: string;
  propertyId: string;
  propertyName: string;
  ownerName: string;
  ownerPhone: string;
  ownerUpi: string;
  bookingId: string;
  stayDates: string;
  totalStayAmount: number;
  advanceCollectedByPlatform: number;
  collectedByHostDirectly: number;
  platformCommission: number;
  netPayoutAmount: number; // positive = platform owes owner; negative = owner owes platform
  payoutStatus: 'Pending' | 'Processed' | 'Settled on Arrival';
  payoutDate?: string;
}

export interface PlatformSettings {
  platformCommissionPercent: number;
  supportPhone: string;
  supportWhatsapp: string;
  supportHours: string;
  razorpayKeyId: string;
  razorpayLiveMode: boolean;
  maintenanceMode: boolean;
  autoAssignLeads: boolean;
  emailAlerts: boolean;
  defaultCancellationRefundStandardDays: number;
  defaultCancellationRefundRemoteDays: number;
}

const STORAGE_KEYS = {
  BOOKINGS: 'cosyfy_admin_bookings',
  CUSTOMERS: 'cosyfy_admin_customers',
  PAYOUTS: 'cosyfy_admin_payouts',
  SETTINGS: 'cosyfy_admin_settings',
  PROPERTIES: 'cosyfy_admin_properties',
};

// Initial Seed Bookings
const INITIAL_BOOKINGS: AdminBooking[] = [
  {
    id: 'CSF-2024-9128',
    customerName: 'Rahul Sharma',
    customerPhone: '+91 98765 43210',
    customerEmail: 'rahul.sharma@gmail.com',
    propertyName: 'Chandi Apple Orchard Retreat',
    propertyLocation: 'Naggar, Himachal Pradesh',
    propertyId: 'prop-chandi-apple-retreat',
    checkIn: '2025-05-10',
    checkOut: '2025-05-15',
    nights: 5,
    totalAmount: 14000,
    commission: 1400, // 10% host fee
    advancePaid: 1400,
    remainingDue: 12600,
    paymentStatus: 'paid_10_percent',
    status: 'confirmed',
    assignedEmployee: 'Rohan Verma',
    assignedEmployeeId: 'EMP-CS-003',
    createdAt: '2025-04-12T14:30:00Z',
    notes: 'Requested vegan meals and high-speed fiber desk. Verified with host Chandi Ram.',
    isRemote: false,
  },
  {
    id: 'CSF-2024-9129',
    customerName: 'Priya Iyer',
    customerPhone: '+91 98450 11223',
    customerEmail: 'priya.iyer@outlook.com',
    propertyName: 'Tirthan Riverside Stone Cottage',
    propertyLocation: 'Jibhi, Himachal Pradesh',
    propertyId: 'prop-tirthan-river-cottage',
    checkIn: '2025-05-18',
    checkOut: '2025-05-22',
    nights: 4,
    totalAmount: 14000,
    commission: 1400,
    advancePaid: 14000,
    remainingDue: 0,
    paymentStatus: 'paid_full',
    status: 'confirmed',
    assignedEmployee: 'Ananya Deshmukh',
    assignedEmployeeId: 'EMP-CS-004',
    createdAt: '2025-04-13T09:15:00Z',
    notes: 'Remote property full payment verified. Host Mahesh arranged fly fishing kit.',
    isRemote: true,
  },
  {
    id: 'CSF-2024-9130',
    customerName: 'Vikram Malhotra',
    customerPhone: '+91 98111 88990',
    customerEmail: 'v.malhotra@techcorp.in',
    propertyName: 'Coorg Heritage Plantation Bungalow',
    propertyLocation: 'Madikeri, Karnataka',
    propertyId: 'prop-coorg-plantation-bungalow',
    checkIn: '2025-06-01',
    checkOut: '2025-06-05',
    nights: 4,
    totalAmount: 18000,
    commission: 1800,
    advancePaid: 1800,
    remainingDue: 16200,
    paymentStatus: 'paid_10_percent',
    status: 'pending',
    assignedEmployee: 'Rohan Verma',
    assignedEmployeeId: 'EMP-CS-003',
    createdAt: '2025-04-13T11:00:00Z',
    notes: 'Family of 4 requesting estate coffee walk. Awaiting host confirmation on extra cot.',
    isRemote: false,
  },
  {
    id: 'CSF-2024-9131',
    customerName: 'Aarav Mehta',
    customerPhone: '+91 99200 44556',
    customerEmail: 'aarav.m@gmail.com',
    propertyName: 'Casa Rio Portuguese Villa',
    propertyLocation: 'Aldona, North Goa',
    propertyId: 'prop-casa-rio-goa',
    checkIn: '2025-05-25',
    checkOut: '2025-05-29',
    nights: 4,
    totalAmount: 20800,
    commission: 2080,
    advancePaid: 2080,
    remainingDue: 18720,
    paymentStatus: 'paid_10_percent',
    status: 'confirmed',
    assignedEmployee: 'Vikram Sengupta',
    assignedEmployeeId: 'EMP-CS-005',
    createdAt: '2025-04-10T16:20:00Z',
    notes: 'Workation stay. Requested private workstation by veranda.',
    isRemote: false,
  },
  {
    id: 'CSF-2024-9132',
    customerName: 'Sneha Kulkarni',
    customerPhone: '+91 97654 33221',
    customerEmail: 'sneha.k@pune.ac.in',
    propertyName: 'Landour Heritage Deodar Cottage',
    propertyLocation: 'Mussoorie, Uttarakhand',
    propertyId: 'prop-landour-cottage',
    checkIn: '2025-06-10',
    checkOut: '2025-06-14',
    nights: 4,
    totalAmount: 15200,
    commission: 1520,
    advancePaid: 15200,
    remainingDue: 0,
    paymentStatus: 'paid_full',
    status: 'pending',
    assignedEmployee: 'Rohan Verma',
    assignedEmployeeId: 'EMP-CS-003',
    createdAt: '2025-04-13T12:45:00Z',
    notes: 'Remote hill ridge location. Host verifying firewood availability for fireplace.',
    isRemote: true,
  },
  {
    id: 'CSF-2024-9133',
    customerName: 'Devansh Roy',
    customerPhone: '+91 98300 77889',
    customerEmail: 'devansh.roy@kolkata.in',
    propertyName: 'Bhimtal Pine Forest Farmhouse',
    propertyLocation: 'Bhimtal, Uttarakhand',
    propertyId: 'prop-bhimtal-farmhouse',
    checkIn: '2025-05-02',
    checkOut: '2025-05-05',
    nights: 3,
    totalAmount: 8400,
    commission: 840,
    advancePaid: 840,
    remainingDue: 7560,
    paymentStatus: 'paid_10_percent',
    status: 'completed',
    assignedEmployee: 'Ananya Deshmukh',
    assignedEmployeeId: 'EMP-CS-004',
    createdAt: '2025-03-25T10:00:00Z',
    notes: 'Guest gave 5-star WhatsApp review praising homecooked Kumaoni dinner.',
    isRemote: false,
  },
  {
    id: 'CSF-2024-9134',
    customerName: 'Kavita Nair',
    customerPhone: '+91 94470 12345',
    customerEmail: 'kavita.nair@kochi.in',
    propertyName: 'Chandi Apple Orchard Retreat',
    propertyLocation: 'Naggar, Himachal Pradesh',
    propertyId: 'prop-chandi-apple-retreat',
    checkIn: '2025-06-20',
    checkOut: '2025-06-27',
    nights: 7,
    totalAmount: 19600,
    commission: 1960,
    advancePaid: 1960,
    remainingDue: 17640,
    paymentStatus: 'paid_10_percent',
    status: 'pending',
    assignedEmployee: 'Rohan Verma',
    assignedEmployeeId: 'EMP-CS-003',
    createdAt: '2025-04-13T08:30:00Z',
    notes: 'Requested 7-night workation rate. Verified 120 Mbps fiber connection.',
    isRemote: false,
  },
  {
    id: 'CSF-2024-9135',
    customerName: 'Arjun Singhania',
    customerPhone: '+91 98200 66778',
    customerEmail: 'arjun.singh@mumbai.in',
    propertyName: 'Coorg Heritage Plantation Bungalow',
    propertyLocation: 'Madikeri, Karnataka',
    propertyId: 'prop-coorg-plantation-bungalow',
    checkIn: '2025-04-20',
    checkOut: '2025-04-22',
    nights: 2,
    totalAmount: 9000,
    commission: 900,
    advancePaid: 900,
    remainingDue: 0,
    paymentStatus: 'refunded',
    status: 'cancelled',
    assignedEmployee: 'Vikram Sengupta',
    assignedEmployeeId: 'EMP-CS-005',
    createdAt: '2025-04-01T15:20:00Z',
    notes: 'Cancelled 14 days prior. Full refund of ₹900 processed to original card.',
    isRemote: false,
  },
];

// Initial Seed Customers / Leads
const INITIAL_CUSTOMERS: AdminCustomer[] = [
  {
    id: 'CUST-101',
    name: 'Rahul Sharma',
    phone: '+91 98765 43210',
    email: 'rahul.sharma@gmail.com',
    leadStatus: 'Converted',
    destinationInterested: 'Himachal Pradesh (Naggar)',
    budgetPerNight: 3000,
    requestedCheckIn: '2025-05-10',
    nights: 5,
    source: 'Google Search',
    assignedEmployee: 'Rohan Verma',
    assignedEmployeeId: 'EMP-CS-003',
    lastContacted: '2025-04-12',
    nextFollowUp: '2025-05-09',
    notes: ['Booked CSF-2024-9128. Wants local apple cider and guided hike to Rumsu.'],
    totalBookings: 1,
  },
  {
    id: 'CUST-102',
    name: 'Priya Iyer',
    phone: '+91 98450 11223',
    email: 'priya.iyer@outlook.com',
    leadStatus: 'Converted',
    destinationInterested: 'Tirthan Valley, Jibhi',
    budgetPerNight: 3500,
    requestedCheckIn: '2025-05-18',
    nights: 4,
    source: 'Instagram',
    assignedEmployee: 'Ananya Deshmukh',
    assignedEmployeeId: 'EMP-CS-004',
    lastContacted: '2025-04-13',
    nextFollowUp: '2025-05-17',
    notes: ['Paid full upfront for remote riverside stay.'],
    totalBookings: 1,
  },
  {
    id: 'CUST-103',
    name: 'Deepak Chawla',
    phone: '+91 98101 22334',
    email: 'deepak.c@delhi.in',
    leadStatus: 'Follow-up Due',
    destinationInterested: 'Mussoorie / Landour',
    budgetPerNight: 4000,
    requestedCheckIn: '2025-05-24',
    nights: 3,
    source: 'Meta Ads',
    assignedEmployee: 'Rohan Verma',
    assignedEmployeeId: 'EMP-CS-003',
    lastContacted: '2025-04-09',
    nextFollowUp: '2025-04-14', // Overdue or due today
    notes: ['Looking for secluded writer retreat with mountain view. Sent Landour options.'],
    totalBookings: 0,
  },
  {
    id: 'CUST-104',
    name: 'Meera Nambiar',
    phone: '+91 94460 55667',
    email: 'meera.n@bangalore.in',
    leadStatus: 'Proposal Sent',
    destinationInterested: 'Coorg Coffee Estates',
    budgetPerNight: 4500,
    requestedCheckIn: '2025-06-05',
    nights: 3,
    source: 'WhatsApp',
    assignedEmployee: 'Rohan Verma',
    assignedEmployeeId: 'EMP-CS-003',
    lastContacted: '2025-04-13',
    nextFollowUp: '2025-04-15',
    notes: ['Sent quote for Coorg Bungalow with authentic Kodava breakfast.'],
    totalBookings: 0,
  },
  {
    id: 'CUST-105',
    name: 'Siddharth Roy',
    phone: '+91 98311 99001',
    email: 'siddharth.r@kolkata.in',
    leadStatus: 'New Lead',
    destinationInterested: 'Goa (Aldona village)',
    budgetPerNight: 5500,
    requestedCheckIn: '2025-06-15',
    nights: 4,
    source: 'Instagram',
    assignedEmployee: 'Vikram Sengupta',
    assignedEmployeeId: 'EMP-CS-005',
    lastContacted: '2025-04-13',
    nextFollowUp: '2025-04-13',
    notes: ['Enquired about Casa Rio Portuguese Villa for creative sprint.'],
    totalBookings: 0,
  },
  {
    id: 'CUST-106',
    name: 'Tanya Bhardwaj',
    phone: '+91 98118 77665',
    email: 'tanya.b@gurgaon.in',
    leadStatus: 'Contacted',
    destinationInterested: 'Bhimtal / Nainital',
    budgetPerNight: 3000,
    requestedCheckIn: '2025-05-30',
    nights: 3,
    source: 'Meta Ads',
    assignedEmployee: 'Ananya Deshmukh',
    assignedEmployeeId: 'EMP-CS-004',
    lastContacted: '2025-04-11',
    nextFollowUp: '2025-04-14',
    notes: ['Prefers quiet lakeside property with dog-friendly host.'],
    totalBookings: 0,
  },
  {
    id: 'CUST-107',
    name: 'Aditya Hegde',
    phone: '+91 98800 33445',
    email: 'aditya.h@bangalore.in',
    leadStatus: 'Lost',
    destinationInterested: 'Jibhi Valley',
    budgetPerNight: 2000,
    requestedCheckIn: '2025-04-15',
    nights: 2,
    source: 'Referral',
    assignedEmployee: 'Rohan Verma',
    assignedEmployeeId: 'EMP-CS-003',
    lastContacted: '2025-04-05',
    nextFollowUp: '2025-04-06',
    notes: ['Dates clashed with full occupancy at Tirthan Cottage. Recommended off-season.'],
    totalBookings: 0,
  },
];

// Initial Seed Owner Payouts
const INITIAL_PAYOUTS: OwnerPayout[] = [
  {
    id: 'PAY-801',
    propertyId: 'prop-chandi-apple-retreat',
    propertyName: 'Chandi Apple Orchard Retreat',
    ownerName: 'Chandi Ram & Family',
    ownerPhone: '+91 98160 54321',
    ownerUpi: 'chandiram@okhdfcbank',
    bookingId: 'CSF-2024-9128',
    stayDates: '10 May - 15 May 2025',
    totalStayAmount: 14000,
    advanceCollectedByPlatform: 1400,
    collectedByHostDirectly: 12600,
    platformCommission: 1400,
    netPayoutAmount: 0, // platform advance covers commission perfectly
    payoutStatus: 'Settled on Arrival',
    payoutDate: '2025-05-10',
  },
  {
    id: 'PAY-802',
    propertyId: 'prop-tirthan-river-cottage',
    propertyName: 'Tirthan Riverside Stone Cottage',
    ownerName: 'Mahesh Thakur',
    ownerPhone: '+91 98162 11223',
    ownerUpi: 'mahesh.thakur@upi',
    bookingId: 'CSF-2024-9129',
    stayDates: '18 May - 22 May 2025',
    totalStayAmount: 14000,
    advanceCollectedByPlatform: 14000, // 100% full remote payment
    collectedByHostDirectly: 0,
    platformCommission: 1400,
    netPayoutAmount: 12600, // Platform remits 90% directly to host
    payoutStatus: 'Pending',
  },
  {
    id: 'PAY-803',
    propertyId: 'prop-landour-cottage',
    propertyName: 'Landour Heritage Deodar Cottage',
    ownerName: 'Colonel Ranjit Singh',
    ownerPhone: '+91 98970 88776',
    ownerUpi: 'ranjit.singh@sbi',
    bookingId: 'CSF-2024-9132',
    stayDates: '10 Jun - 14 Jun 2025',
    totalStayAmount: 15200,
    advanceCollectedByPlatform: 15200, // Remote property full payment
    collectedByHostDirectly: 0,
    platformCommission: 1520,
    netPayoutAmount: 13680,
    payoutStatus: 'Pending',
  },
  {
    id: 'PAY-804',
    propertyId: 'prop-bhimtal-farmhouse',
    propertyName: 'Bhimtal Pine Forest Farmhouse',
    ownerName: 'Kamla Joshi',
    ownerPhone: '+91 94120 44556',
    ownerUpi: 'kamla.joshi@barodampay',
    bookingId: 'CSF-2024-9133',
    stayDates: '02 May - 05 May 2025',
    totalStayAmount: 8400,
    advanceCollectedByPlatform: 840,
    collectedByHostDirectly: 7560,
    platformCommission: 840,
    netPayoutAmount: 0,
    payoutStatus: 'Settled on Arrival',
    payoutDate: '2025-05-02',
  },
];

// Initial Settings
const DEFAULT_SETTINGS: PlatformSettings = {
  platformCommissionPercent: 10,
  supportPhone: '+91 98765 43210',
  supportWhatsapp: '+91 98765 43210',
  supportHours: '7:00 AM - 10:00 PM IST',
  razorpayKeyId: import.meta.env.VITE_RAZORPAY_KEY_ID || '',
  razorpayLiveMode: Boolean(import.meta.env.VITE_RAZORPAY_KEY_ID),
  maintenanceMode: false,
  autoAssignLeads: true,
  emailAlerts: true,
  defaultCancellationRefundStandardDays: 7,
  defaultCancellationRefundRemoteDays: 15,
};

// Data Store Accessors
export function getAdminBookings(): AdminBooking[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BOOKINGS);
    if (raw) return JSON.parse(raw);
  } catch {}
  saveAdminBookings(INITIAL_BOOKINGS);
  return INITIAL_BOOKINGS;
}

export function saveAdminBookings(bookings: AdminBooking[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));
  } catch (e) {
    console.error(e);
  }
}

export function updateAdminBooking(id: string, updates: Partial<AdminBooking>): AdminBooking[] {
  const current = getAdminBookings();
  const updated = current.map((b) => (b.id === id ? { ...b, ...updates } : b));
  saveAdminBookings(updated);
  return updated;
}

export function getAdminCustomers(): AdminCustomer[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
    if (raw) return JSON.parse(raw);
  } catch {}
  saveAdminCustomers(INITIAL_CUSTOMERS);
  return INITIAL_CUSTOMERS;
}

export function saveAdminCustomers(customers: AdminCustomer[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
  } catch (e) {
    console.error(e);
  }
}

export function updateAdminCustomer(id: string, updates: Partial<AdminCustomer>): AdminCustomer[] {
  const current = getAdminCustomers();
  const updated = current.map((c) => (c.id === id ? { ...c, ...updates } : c));
  saveAdminCustomers(updated);
  return updated;
}

export function getOwnerPayouts(): OwnerPayout[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PAYOUTS);
    if (raw) return JSON.parse(raw);
  } catch {}
  saveOwnerPayouts(INITIAL_PAYOUTS);
  return INITIAL_PAYOUTS;
}

export function saveOwnerPayouts(payouts: OwnerPayout[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.PAYOUTS, JSON.stringify(payouts));
  } catch (e) {
    console.error(e);
  }
}

export function getPlatformSettings(): PlatformSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (raw) return JSON.parse(raw);
  } catch {}
  return DEFAULT_SETTINGS;
}

export function savePlatformSettings(settings: PlatformSettings): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error(e);
  }
}

export interface AdminPropertyItem {
  id: string; // CSF-001 format
  slug: string;
  name: string;
  state: string;
  district: string;
  location: string;
  ownerName: string;
  ownerWhatsapp: string;
  ownerPhone?: string;
  ownerEmail?: string;
  ownerAadhaar?: string;
  ownerPan?: string;
  businessType?: string;
  businessGstNumber?: string;
  isGstRegistered?: boolean;
  bankAccountHolder?: string;
  bankAccountNumber?: string;
  bankIfsc?: string;
  upiId?: string;
  propertyType?: string;
  tagline?: string;
  nearestTown?: string;
  googleMapsUrl?: string;
  directionsAir?: string;
  directionsTrain?: string;
  directionsRoad?: string;
  totalRooms?: number;
  maxGuests?: number;
  totalBathrooms?: number;
  kitchenAccess?: string;
  wifiSpeedMbps?: number;
  powerBackupHours?: number;
  mobileNetworks?: string[];
  weeklyDiscountPercent?: number;
  monthlyDiscountPercent?: number;
  extraGuestCharge?: number;
  childPolicy?: string;
  galleryImages?: string[];
  videoTourUrl?: string;
  virtualTour360Url?: string;
  checkInTime?: string;
  checkOutTime?: string;
  smokingAllowed?: boolean;
  alcoholAllowed?: boolean;
  quietHours?: string;
  cancellationPolicy?: string;
  documents?: {
    aadhaarDoc?: string;
    propertyProof?: string;
    businessRegDoc?: string;
    gstDoc?: string;
    cancelledCheque?: string;
  };
  weekdayPrice: number;
  weekendPrice: number;
  commissionPercent: number;
  isActive: boolean;
  isAirbnbListed: boolean;
  isWfhReady: boolean;
  isRemoteProperty: boolean;
  enquiriesThisMonth: number;
  bookingsThisMonth: number;
  mainImage: string;
  description: string;
  amenities: string[];
}

export function getAdminProperties(): AdminPropertyItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PROPERTIES);
    if (raw) return JSON.parse(raw);
  } catch {}

  const initialList: AdminPropertyItem[] = staticProperties.map((p, idx) => {
    const parts = p.location.split(',').map((s) => s.trim());
    const district = parts[0] || 'Shimla';
    const state = parts[1] || 'Himachal Pradesh';
    return {
      id: `CSF-${String(idx + 1).padStart(3, '0')}`,
      slug: p.id,
      name: p.name,
      state,
      district,
      location: p.location,
      ownerName: p.host.name,
      ownerWhatsapp: '+91 98160 54321',
      weekdayPrice: p.weekdayPrice,
      weekendPrice: p.weekendPrice,
      commissionPercent: 10,
      isActive: true,
      isAirbnbListed: idx % 2 === 0,
      isWfhReady: Boolean(p.wfhReady),
      isRemoteProperty: Boolean(p.remoteProperty),
      enquiriesThisMonth: 18 + (idx * 5) % 20,
      bookingsThisMonth: 4 + (idx * 2) % 6,
      mainImage: p.mainImage,
      description: p.description,
      amenities: [...p.amenities],
    };
  });

  saveAdminProperties(initialList);
  return initialList;
}

export function saveAdminProperties(props: AdminPropertyItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.PROPERTIES, JSON.stringify(props));
  } catch (e) {
    console.error(e);
  }
}

// ================= PROPERTY LEADS (Public Host Submissions) =================

export interface PropertyLead {
  id: string; // e.g. PL-101
  ownerName: string;
  mobile: string;
  whatsapp: string;
  email: string;
  propertyName: string;
  propertyType: string;
  state: string;
  district: string;
  approxLocation: string;
  roomsCount: number;
  priceRange: string;
  otherPlatforms: string[];
  description: string;
  bestTimeToCall: string;
  source: string;
  status: 'New' | 'Contacted' | 'Under Review' | 'Onboarded' | 'Declined';
  submittedAt: string;
  notes?: string;
  assignedTo?: string;
}

const INITIAL_PROPERTY_LEADS: PropertyLead[] = [
  {
    id: 'PL-101',
    ownerName: 'Virender Negi',
    mobile: '+91 98162 33445',
    whatsapp: '+91 98162 33445',
    email: 'virender.kinnaur@gmail.com',
    propertyName: 'Kinnaur Kailash View Homestay',
    propertyType: 'Homestay',
    state: 'Himachal Pradesh',
    district: 'Kinnaur (Kalpa)',
    approxLocation: 'Near Roghi Village, Upper Kalpa',
    roomsCount: 4,
    priceRange: '₹2000-4000',
    otherPlatforms: ['Airbnb'],
    description: 'Traditional deodar wood cottage overlooking the sacred Kinner Kailash peak. Apple orchard in front with high-speed fiber internet and homecooked Kinnauri food.',
    bestTimeToCall: 'Morning 9-12',
    source: 'Instagram',
    status: 'New',
    submittedAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    notes: 'Called briefly, host is keen on workation guests for 1-month stays.',
    assignedTo: 'Rohan Verma',
  },
  {
    id: 'PL-102',
    ownerName: 'Sunita Bisht',
    mobile: '+91 94115 88990',
    whatsapp: '+91 94115 88990',
    email: 'sunita.mukteshwar@outlook.com',
    propertyName: 'Mukteshwar Cloud Valley Villa',
    propertyType: 'Villa',
    state: 'Uttarakhand',
    district: 'Nainital (Mukteshwar)',
    approxLocation: 'Sargakhet, Mukteshwar Ridge',
    roomsCount: 3,
    priceRange: '₹4000-8000',
    otherPlatforms: ['MakeMyTrip', 'Airbnb'],
    description: '3-bedroom stone villa with private lawn, panoramic Trishul peak views, dedicated study room with ergonomic chairs for tech professionals.',
    bestTimeToCall: 'Evening 4-8',
    source: 'Friend or Relative',
    status: 'Contacted',
    submittedAt: new Date(Date.now() - 3600000 * 28).toISOString(),
    notes: 'Interested in zero-listing fee model. Waiting for electricity bill doc.',
    assignedTo: 'Sneha Kapur',
  },
  {
    id: 'PL-103',
    ownerName: 'George Joseph',
    mobile: '+91 98471 22334',
    whatsapp: '+91 98471 22334',
    email: 'george.wayanad@gmail.com',
    propertyName: 'Meppadi Coffee Estate Stay',
    propertyType: 'Farm Stay',
    state: 'Kerala',
    district: 'Wayanad',
    approxLocation: 'Meppadi, Near Chembra Peak Trail',
    roomsCount: 5,
    priceRange: '₹2000-4000',
    otherPlatforms: ['Booking.com'],
    description: 'Active 12-acre Arabica coffee plantation homestay. Stream flowing through property, Kerala homecooked meals by host family.',
    bestTimeToCall: 'Afternoon 12-4',
    source: 'Google Search',
    status: 'Under Review',
    submittedAt: new Date(Date.now() - 3600000 * 72).toISOString(),
    notes: 'WiFi speed verified at 120 Mbps. High rating potential.',
    assignedTo: 'Rohan Verma',
  },
];

const PROPERTY_LEADS_KEY = 'cosyfy_admin_property_leads';

export function getPropertyLeads(): PropertyLead[] {
  try {
    const raw = localStorage.getItem(PROPERTY_LEADS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  savePropertyLeads(INITIAL_PROPERTY_LEADS);
  return INITIAL_PROPERTY_LEADS;
}

export function savePropertyLeads(leads: PropertyLead[]): void {
  try {
    localStorage.setItem(PROPERTY_LEADS_KEY, JSON.stringify(leads));
  } catch (e) {
    console.error(e);
  }
}

export function addPropertyLead(lead: Omit<PropertyLead, 'id' | 'submittedAt' | 'status'> & { status?: PropertyLead['status'] }): PropertyLead {
  const existing = getPropertyLeads();
  const newLead: PropertyLead = {
    ...lead,
    id: `PL-${100 + existing.length + 1}`,
    status: lead.status || 'New',
    submittedAt: new Date().toISOString(),
  };
  const updated = [newLead, ...existing];
  savePropertyLeads(updated);
  return newLead;
}

export function updatePropertyLead(id: string, updates: Partial<PropertyLead>): PropertyLead[] {
  const current = getPropertyLeads();
  const updated = current.map((item) => (item.id === id ? { ...item, ...updates } : item));
  savePropertyLeads(updated);
  return updated;
}

