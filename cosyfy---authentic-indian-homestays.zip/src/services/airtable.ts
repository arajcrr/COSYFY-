import axios from 'axios';
import { Property, Booking, Customer, FilterState } from '../types';
import { INITIAL_PROPERTIES } from '../data/staticData';

const AIRTABLE_API_KEY = import.meta.env.VITE_AIRTABLE_API_KEY;
const AIRTABLE_BASE_ID = import.meta.env.VITE_AIRTABLE_BASE_ID;
const PROPERTIES_TABLE_ID = import.meta.env.VITE_PROPERTIES_TABLE_ID || 'tblProperties';
const CUSTOMERS_TABLE_ID = import.meta.env.VITE_CUSTOMERS_TABLE_ID || 'tblCustomers';
const BOOKINGS_TABLE_ID = import.meta.env.VITE_BOOKINGS_TABLE_ID || 'tblBookings';

// Cache configuration
interface PropertyCache {
  data: Property[];
  timestamp: number;
}
let cachedProperties: PropertyCache | null = null;
const CACHE_DURATION_MS = 5 * 60 * 1000; // 5 minutes

const airtableClient = axios.create({
  baseURL: `https://api.airtable.com/v0/${AIRTABLE_BASE_ID}`,
  headers: {
    Authorization: `Bearer ${AIRTABLE_API_KEY}`,
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

/**
 * Normalizes Airtable record fields to our strict Property type
 */
function normalizeAirtableRecord(record: any): Property {
  const f = record.fields;
  return {
    id: record.id,
    name: f['Property Name'] || f['Name'] || 'Indian Homestay',
    tagline: f['Tagline'] || '',
    destination: f['Destination'] || f['City'] || 'Manali',
    region: f['Region'] || 'Hills',
    state: f['State'] || 'Himachal Pradesh',
    location: f['Location'] || `${f['Destination'] || 'Manali'}, ${f['State'] || 'Himachal Pradesh'}`,
    address: f['Address'] || '',
    googleMapsUrl: f['Google Maps URL'] || '',
    mapEmbedUrl: f['Map Embed URL'] || '',
    weekdayPrice: Number(f['Weekday Price'] || f['Price Per Night'] || 2500),
    weekendPrice: Number(f['Weekend Price'] || f['Weekday Price'] || 3000),
    cleaningFee: Number(f['Cleaning Fee'] || 0),
    maxGuests: Number(f['Max Guests'] || 4),
    bedrooms: Number(f['Bedrooms'] || 2),
    bathrooms: Number(f['Bathrooms'] || 2),
    mainImage:
      Array.isArray(f['Photos']) && f['Photos'].length > 0
        ? f['Photos'][0].url
        : f['Main Image'] || INITIAL_PROPERTIES[0].mainImage,
    images:
      Array.isArray(f['Photos']) && f['Photos'].length > 0
        ? f['Photos'].map((p: any) => p.url)
        : [INITIAL_PROPERTIES[0].mainImage],
    videoUrl: f['Video URL'] || '',
    description: f['Description'] || '',
    surroundingArea: f['Surrounding Area'] || '',
    distances: {
      railway: f['Distance Railway'] || '',
      airport: f['Distance Airport'] || '',
      busStand: f['Distance Bus'] || '',
    },
    nearbyAttractions: f['Nearby Attractions']
      ? String(f['Nearby Attractions']).split(',').map((s) => s.trim())
      : [],
    amenities: Array.isArray(f['Amenities']) ? f['Amenities'] : ['WiFi', 'Meals', 'Mountain View'],
    wfhReady: Boolean(f['WFH Ready']),
    wifiSpeedMbps: Number(f['WiFi Speed Mbps'] || 100),
    powerBackup: Boolean(f['Power Backup']),
    networkCoverage: f['Network Coverage'] || 'Airtel & Jio 5G',
    notOnAirbnb: Boolean(f['Not On Airbnb']),
    featured: Boolean(f['Featured']),
    rating: Number(f['Rating'] || 4.9),
    reviewCount: Number(f['Review Count'] || 12),
    host: {
      name: f['Host Name'] || 'Local Family',
      memberSince: f['Host Member Since'] || '2023',
      responseTime: f['Host Response Time'] || 'Under 1 hour',
      bio: f['Host Bio'] || 'Authentic local hosts happy to share native culture.',
      avatar: f['Host Avatar'] || '',
    },
    houseRules: {
      checkInTime: f['Check In Time'] || '12:00 PM',
      checkOutTime: f['Check Out Time'] || '11:00 AM',
      policies: f['House Policies'] ? String(f['House Policies']).split('\n') : ['Zero hidden fees'],
    },
    isActive: f['Active'] !== false,
    remoteProperty: Boolean(f['Remote Property'] || f['remoteProperty']),
  };
}

/**
 * Fetch all properties from Airtable with in-memory caching and fallback
 */
export async function fetchAllProperties(forceRefresh = false): Promise<Property[]> {
  const now = Date.now();
  if (!forceRefresh && cachedProperties && now - cachedProperties.timestamp < CACHE_DURATION_MS) {
    return cachedProperties.data;
  }

  if (!AIRTABLE_API_KEY || !AIRTABLE_BASE_ID) {
    // Graceful fallback to verified built-in homestays
    cachedProperties = { data: INITIAL_PROPERTIES, timestamp: now };
    return INITIAL_PROPERTIES;
  }

  try {
    const res = await airtableClient.get(`/${PROPERTIES_TABLE_ID}`, {
      params: {
        filterByFormula: "NOT({Active} = 0)",
      },
    });

    if (res.data && res.data.records && res.data.records.length > 0) {
      const records = res.data.records.map(normalizeAirtableRecord);
      cachedProperties = { data: records, timestamp: now };
      return records;
    }

    return INITIAL_PROPERTIES;
  } catch (error) {
    console.warn('Airtable API request failed, falling back to local dataset:', error);
    return INITIAL_PROPERTIES;
  }
}

/**
 * Fetch a single property by its ID
 */
export async function fetchPropertyById(id: string): Promise<Property | null> {
  const all = await fetchAllProperties();
  const match = all.find((p) => p.id === id);
  if (match) return match;

  if (AIRTABLE_API_KEY && AIRTABLE_BASE_ID) {
    try {
      const res = await airtableClient.get(`/${PROPERTIES_TABLE_ID}/${id}`);
      if (res.data) {
        return normalizeAirtableRecord(res.data);
      }
    } catch (e) {
      console.warn(`Failed to fetch individual property ${id} from Airtable:`, e);
    }
  }

  return INITIAL_PROPERTIES.find((p) => p.id === id) || null;
}

/**
 * Filter properties client-side or server-side
 */
export function filterProperties(properties: Property[], filters: Partial<FilterState>): Property[] {
  return properties.filter((p) => {
    if (filters.destination && filters.destination.trim() !== '') {
      const q = filters.destination.toLowerCase().trim();
      const inDest = p.destination.toLowerCase().includes(q);
      const inLoc = p.location.toLowerCase().includes(q);
      const inName = p.name.toLowerCase().includes(q);
      const inState = p.state.toLowerCase().includes(q);
      if (!inDest && !inLoc && !inName && !inState) return false;
    }

    if (filters.region && filters.region !== 'All') {
      if (p.region !== filters.region) return false;
    }

    if (filters.priceRange) {
      const [min, max] = filters.priceRange;
      if (p.weekdayPrice < min || p.weekdayPrice > max) return false;
    }

    if (filters.guests && filters.guests > 1) {
      if (p.maxGuests < filters.guests) return false;
    }

    if (filters.wfhReady && !p.wfhReady) return false;
    if (filters.notOnAirbnb && !p.notOnAirbnb) return false;

    if (filters.amenities && filters.amenities.length > 0) {
      const hasAll = filters.amenities.every((a) => p.amenities.includes(a));
      if (!hasAll) return false;
    }

    return true;
  });
}

/**
 * Creates customer record in Airtable
 */
export async function createAirtableCustomer(customer: Customer): Promise<string | null> {
  if (!AIRTABLE_API_KEY || !AIRTABLE_BASE_ID) return 'mock-cust-id';

  try {
    const res = await airtableClient.post(`/${CUSTOMERS_TABLE_ID}`, {
      fields: {
        'Full Name': customer.fullName,
        'Phone Number': customer.phone,
        'WhatsApp Number': customer.whatsapp || customer.phone,
        Email: customer.email,
        City: customer.city || '',
        'Created At': new Date().toISOString(),
      },
    });
    return res.data?.id || null;
  } catch (error) {
    console.error('Failed to create Airtable customer:', error);
    return null;
  }
}

/**
 * Creates booking record in Airtable
 */
export async function createAirtableBooking(booking: Booking): Promise<string | null> {
  if (!AIRTABLE_API_KEY || !AIRTABLE_BASE_ID) {
    return 'local-airtable-mock';
  }

  try {
    const res = await airtableClient.post(`/${BOOKINGS_TABLE_ID}`, {
      fields: {
        'Booking Reference': booking.bookingReference,
        'Property Name': booking.propertyName,
        'Property Location': booking.propertyLocation,
        'Guest Name': booking.guestName,
        'Phone Number': booking.guestPhone,
        Email: booking.guestEmail,
        'Check-In': booking.checkIn,
        'Check-Out': booking.checkOut,
        Adults: booking.adults,
        Children: booking.children,
        Nights: booking.nights,
        'Total Price': booking.totalPrice,
        'Advance Deposit': booking.advanceDeposit,
        Status: booking.status,
        'Group Type': booking.groupType,
        'Dietary Preference': booking.dietary,
        'Special Requests': booking.specialRequests || '',
        'Arrival Time': booking.arrivalTime || '',
        Source: booking.source || 'Website',
      },
    });
    return res.data?.id || null;
  } catch (error) {
    console.error('Failed to create Airtable booking:', error);
    return null;
  }
}

/**
 * Updates booking status in Airtable
 */
export async function updateAirtableBookingStatus(bookingId: string, status: string): Promise<boolean> {
  if (!AIRTABLE_API_KEY || !AIRTABLE_BASE_ID) return true;

  try {
    await airtableClient.patch(`/${BOOKINGS_TABLE_ID}/${bookingId}`, {
      fields: { Status: status },
    });
    return true;
  } catch (error) {
    console.error('Failed to update Airtable booking status:', error);
    return false;
  }
}
