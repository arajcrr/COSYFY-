/**
 * Authentication and Role-Based Access Control System
 * Supports Multi-Tier Admin Roles: Super Admin, Admin, Employee
 */

export enum UserRole {
  SUPER_ADMIN = 'super_admin',
  ADMIN = 'admin',
  EMPLOYEE = 'employee',
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  employeeId?: string;
  assignedLeads?: string[];
  createdAt: string;
  isActive: boolean;
  phone?: string;
  department?: string;
  avatar?: string;
}

export interface AuthSession {
  token: string;
  user: User;
  expiresAt: number; // timestamp in milliseconds
}

const AUTH_STORAGE_KEY = 'cosyfy_auth_session';
const TOKEN_EXPIRY_HOURS = 24;

// Default demo credentials configured with environment variable overrides
export const DEMO_CREDENTIALS = {
  superAdmin: {
    email: (import.meta.env.VITE_SUPERADMIN_EMAIL || 'superadmin@cosyfy.in').toLowerCase().trim(),
    password: import.meta.env.VITE_SUPERADMIN_PASSWORD || 'superadmin123',
    user: {
      id: 'usr_super_01',
      name: 'Avnish Raj (Super Admin)',
      email: (import.meta.env.VITE_SUPERADMIN_EMAIL || 'superadmin@cosyfy.in').toLowerCase().trim(),
      role: UserRole.SUPER_ADMIN,
      employeeId: 'EMP-SA-001',
      createdAt: '2023-01-15T09:00:00.000Z',
      isActive: true,
      phone: '+91 98765 00001',
      department: 'Executive Leadership',
    } as User,
  },
  admin: {
    email: (import.meta.env.VITE_ADMIN_EMAIL || 'admin@cosyfy.in').toLowerCase().trim(),
    password: import.meta.env.VITE_ADMIN_PASSWORD || 'admin123',
    user: {
      id: 'usr_admin_02',
      name: 'Priya Sharma (Operations Head)',
      email: (import.meta.env.VITE_ADMIN_EMAIL || 'admin@cosyfy.in').toLowerCase().trim(),
      role: UserRole.ADMIN,
      employeeId: 'EMP-AD-002',
      createdAt: '2023-04-10T10:30:00.000Z',
      isActive: true,
      phone: '+91 98765 00002',
      department: 'Operations & Host Relations',
    } as User,
  },
  employee: {
    email: (import.meta.env.VITE_EMPLOYEE_EMAIL || 'employee@cosyfy.in').toLowerCase().trim(),
    password: import.meta.env.VITE_EMPLOYEE_PASSWORD || 'employee123',
    user: {
      id: 'usr_emp_03',
      name: 'Rohan Verma (Travel Concierge)',
      email: (import.meta.env.VITE_EMPLOYEE_EMAIL || 'employee@cosyfy.in').toLowerCase().trim(),
      role: UserRole.EMPLOYEE,
      employeeId: 'EMP-CS-003',
      assignedLeads: ['lead_101', 'lead_104', 'lead_109'],
      createdAt: '2023-08-20T11:15:00.000Z',
      isActive: true,
      phone: '+91 98765 00003',
      department: 'Customer Success & Bookings',
    } as User,
  },
};

/**
 * Generate a simulated JWT token string with embedded claims
 */
function createJwtToken(user: User, expiresAt: number): string {
  const header = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const payload = btoa(
    JSON.stringify({
      sub: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      employeeId: user.employeeId,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(expiresAt / 1000),
    })
  );
  const signature = btoa(`sig_${Math.random().toString(36).substring(2, 12)}`);
  return `${header}.${payload}.${signature}`;
}

/**
 * Get destination dashboard path based on role
 */
export function getRedirectPathForRole(role: UserRole): string {
  switch (role) {
    case UserRole.SUPER_ADMIN:
      return '/superadmin';
    case UserRole.ADMIN:
      return '/admin';
    case UserRole.EMPLOYEE:
      return '/employee';
    default:
      return '/';
  }
}

/**
 * Attempt authentication with email and password
 * Automatically detects role based on credentials
 */
export async function authenticateUser(
  emailInput: string,
  passwordInput: string
): Promise<{ user: User; token: string; redirectPath: string }> {
  // Artificial brief network delay for authentic feel
  await new Promise((resolve) => setTimeout(resolve, 600));

  const cleanEmail = emailInput.trim().toLowerCase();
  const cleanPass = passwordInput.trim();

  let matchedUser: User | null = null;

  if (
    cleanEmail === DEMO_CREDENTIALS.superAdmin.email &&
    cleanPass === DEMO_CREDENTIALS.superAdmin.password
  ) {
    matchedUser = DEMO_CREDENTIALS.superAdmin.user;
  } else if (
    cleanEmail === DEMO_CREDENTIALS.admin.email &&
    cleanPass === DEMO_CREDENTIALS.admin.password
  ) {
    matchedUser = DEMO_CREDENTIALS.admin.user;
  } else if (
    cleanEmail === DEMO_CREDENTIALS.employee.email &&
    cleanPass === DEMO_CREDENTIALS.employee.password
  ) {
    matchedUser = DEMO_CREDENTIALS.employee.user;
  } else {
    // Check local employees database if created via admin UI
    const savedEmployees = getStoredEmployees();
    const foundEmp = savedEmployees.find(
      (e) => e.email.toLowerCase() === cleanEmail && e.isActive
    );
    if (foundEmp && cleanPass === 'password123') {
      matchedUser = foundEmp;
    }
  }

  if (!matchedUser) {
    throw new Error('Invalid credentials. Please check your email and password.');
  }

  if (!matchedUser.isActive) {
    throw new Error('This account has been deactivated. Please contact your Super Administrator.');
  }

  const expiresAt = Date.now() + TOKEN_EXPIRY_HOURS * 60 * 60 * 1000;
  const token = createJwtToken(matchedUser, expiresAt);

  const session: AuthSession = {
    token,
    user: matchedUser,
    expiresAt,
  };

  try {
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(session));
  } catch (err) {
    console.error('Failed to store session in localStorage:', err);
  }

  logAuditAction(
    matchedUser.id,
    matchedUser.name,
    matchedUser.role,
    'USER_LOGIN',
    `Successful login to ${getRedirectPathForRole(matchedUser.role)} portal`
  );

  return {
    user: matchedUser,
    token,
    redirectPath: getRedirectPathForRole(matchedUser.role),
  };
}

/**
 * Retrieve current active session from localStorage with expiration check
 */
export function getActiveSession(): AuthSession | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(AUTH_STORAGE_KEY);
    if (!raw) return null;

    const session: AuthSession = JSON.parse(raw);
    if (Date.now() > session.expiresAt) {
      // Token has expired (24 hours reached)
      logoutUser();
      return null;
    }
    return session;
  } catch {
    return null;
  }
}

/**
 * Log out and clear stored session
 */
export function logoutUser(): void {
  const session = getActiveSession();
  if (session) {
    logAuditAction(
      session.user.id,
      session.user.name,
      session.user.role,
      'USER_LOGOUT',
      'User logged out from administrative portal'
    );
  }
  localStorage.removeItem(AUTH_STORAGE_KEY);
}

/**
 * Mock Audit Log Storage
 */
export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: string;
  details: string;
}

const AUDIT_STORAGE_KEY = 'cosyfy_audit_logs';

export function getAuditLogs(): AuditLogEntry[] {
  try {
    const raw = localStorage.getItem(AUDIT_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}

  const defaults: AuditLogEntry[] = [
    {
      id: 'log_01',
      timestamp: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
      userId: DEMO_CREDENTIALS.superAdmin.user.id,
      userName: DEMO_CREDENTIALS.superAdmin.user.name,
      userRole: UserRole.SUPER_ADMIN,
      action: 'PLATFORM_SETTINGS_UPDATE',
      details: 'Updated Razorpay commission margin to 0% guest fee model',
    },
    {
      id: 'log_02',
      timestamp: new Date(Date.now() - 95 * 60 * 1000).toISOString(),
      userId: DEMO_CREDENTIALS.admin.user.id,
      userName: DEMO_CREDENTIALS.admin.user.name,
      userRole: UserRole.ADMIN,
      action: 'BOOKING_APPROVED',
      details: 'Approved booking CSF-2024-9128 (Chandi Apple Retreat)',
    },
    {
      id: 'log_03',
      timestamp: new Date(Date.now() - 180 * 60 * 1000).toISOString(),
      userId: DEMO_CREDENTIALS.employee.user.id,
      userName: DEMO_CREDENTIALS.employee.user.name,
      userRole: UserRole.EMPLOYEE,
      action: 'LEAD_CONTACTED',
      details: 'Sent WhatsApp availability proposal to lead Priya Nair for Coorg stay',
    },
  ];
  try {
    localStorage.setItem(AUDIT_STORAGE_KEY, JSON.stringify(defaults));
  } catch {}
  return defaults;
}

export function logAuditAction(
  userId: string,
  userName: string,
  userRole: UserRole,
  action: string,
  details: string
): void {
  try {
    const logs = getAuditLogs();
    const newLog: AuditLogEntry = {
      id: `log_${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId,
      userName,
      userRole,
      action,
      details,
    };
    localStorage.setItem(AUDIT_STORAGE_KEY, JSON.stringify([newLog, ...logs.slice(0, 99)]));
  } catch (e) {
    console.error(e);
  }
}

export function logAuditEvent(action: string, details: string, metadata?: any): void {
  const session = getActiveSession();
  const userId = session?.user.id || 'system';
  const userName = session?.user.name || 'Public Host Portal';
  const userRole = session?.user.role || UserRole.SUPER_ADMIN;
  logAuditAction(
    userId,
    userName,
    userRole,
    action,
    metadata ? `${details} | ${JSON.stringify(metadata)}` : details
  );
}

/**
 * Employees Management Storage
 */
const EMPLOYEES_STORAGE_KEY = 'cosyfy_employees_list';

export function getStoredEmployees(): User[] {
  try {
    const raw = localStorage.getItem(EMPLOYEES_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}

  const initialList: User[] = [
    DEMO_CREDENTIALS.superAdmin.user,
    DEMO_CREDENTIALS.admin.user,
    DEMO_CREDENTIALS.employee.user,
    {
      id: 'usr_emp_04',
      name: 'Ananya Deshmukh',
      email: 'ananya@cosyfy.in',
      role: UserRole.EMPLOYEE,
      employeeId: 'EMP-CS-004',
      assignedLeads: ['lead_102', 'lead_108'],
      createdAt: '2023-09-01T10:00:00.000Z',
      isActive: true,
      phone: '+91 98765 00004',
      department: 'Guest Relations',
    },
    {
      id: 'usr_emp_05',
      name: 'Vikram Sengupta',
      email: 'vikram@cosyfy.in',
      role: UserRole.EMPLOYEE,
      employeeId: 'EMP-CS-005',
      assignedLeads: ['lead_103'],
      createdAt: '2023-11-15T09:30:00.000Z',
      isActive: true,
      phone: '+91 98765 00005',
      department: 'Host Onboarding',
    },
  ];

  try {
    localStorage.setItem(EMPLOYEES_STORAGE_KEY, JSON.stringify(initialList));
  } catch {}
  return initialList;
}

export function saveStoredEmployees(employees: User[]): void {
  try {
    localStorage.setItem(EMPLOYEES_STORAGE_KEY, JSON.stringify(employees));
  } catch (e) {
    console.error(e);
  }
}
