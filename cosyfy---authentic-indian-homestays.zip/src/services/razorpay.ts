/**
 * Razorpay Payment Integration Service
 * Automatically switches between Live Razorpay Checkout (when VITE_RAZORPAY_KEY_ID is present)
 * and High-Fidelity Demo Sandbox Mode.
 */

declare global {
  interface Window {
    Razorpay: any;
  }
}

export interface RazorpayCheckoutOptions {
  amount: number; // in INR rupees
  propertyName: string;
  guestName: string;
  guestEmail: string;
  guestPhone: string;
  onSuccess: (paymentId: string) => void;
  onFailure?: (error: any) => void;
  onDismiss?: () => void;
}

export function isRazorpayLive(): boolean {
  const key = import.meta.env.VITE_RAZORPAY_KEY_ID;
  return Boolean(key && key.trim().length > 0 && !key.includes('placeholder'));
}

export function loadRazorpayScript(): Promise<boolean> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined') return resolve(false);
    if (window.Razorpay) return resolve(true);

    const existingScript = document.getElementById('razorpay-checkout-script');
    if (existingScript) return resolve(true);

    const script = document.createElement('script');
    script.id = 'razorpay-checkout-script';
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    script.onload = () => resolve(true);
    script.onerror = () => {
      console.warn('Failed to load Razorpay checkout script.');
      resolve(false);
    };
    document.body.appendChild(script);
  });
}

export async function openLiveRazorpayCheckout(options: RazorpayCheckoutOptions): Promise<boolean> {
  const loaded = await loadRazorpayScript();
  if (!loaded || !window.Razorpay) {
    console.warn('Razorpay SDK not loaded, falling back to demo modal');
    return false;
  }

  const keyId = import.meta.env.VITE_RAZORPAY_KEY_ID;
  const logoUrl = import.meta.env.VITE_LOGO_URL || `${window.location.origin}/cosyfy-logo.svg`;

  const rzpOptions = {
    key: keyId,
    amount: Math.round(options.amount * 100), // convert to paise
    currency: 'INR',
    name: 'COSYFY Homestays',
    description: `Advance Deposit for ${options.propertyName}`,
    image: logoUrl,
    prefill: {
      name: options.guestName,
      email: options.guestEmail,
      contact: options.guestPhone.startsWith('+91') ? options.guestPhone : `+91${options.guestPhone}`,
    },
    theme: {
      color: '#C84B31',
    },
    handler: function (response: { razorpay_payment_id: string }) {
      if (response && response.razorpay_payment_id) {
        options.onSuccess(response.razorpay_payment_id);
      } else {
        options.onSuccess(`pay_live_${Math.random().toString(36).substring(2, 9).toUpperCase()}`);
      }
    },
    modal: {
      ondismiss: function () {
        if (options.onDismiss) {
          options.onDismiss();
        }
      },
    },
  };

  try {
    const rzp = new window.Razorpay(rzpOptions);
    rzp.on('payment.failed', function (response: any) {
      if (options.onFailure) {
        options.onFailure(response.error);
      }
    });
    rzp.open();
    return true;
  } catch (err) {
    console.error('Error opening Razorpay checkout:', err);
    return false;
  }
}
