import axios from 'axios';
import { Booking, Enquiry } from '../types';

const MAKE_WEBHOOK_URL = import.meta.env.VITE_MAKE_WEBHOOK_URL;

async function postWithRetry(url: string, payload: any, retries = 3, delayMs = 1000): Promise<boolean> {
  if (!url) {
    // If webhook is not configured yet, succeed silently
    return true;
  }

  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      await axios.post(url, payload, {
        headers: { 'Content-Type': 'application/json' },
        timeout: 8000,
      });
      return true;
    } catch (err) {
      console.warn(`Make.com webhook attempt ${attempt} failed:`, err);
      if (attempt < retries) {
        await new Promise((res) => setTimeout(res, delayMs * attempt));
      }
    }
  }
  return false;
}

/**
 * Triggers Make.com automation workflow for a new booking request
 */
export async function sendBookingWebhook(booking: Booking): Promise<void> {
  const payload = {
    event: 'booking.created',
    timestamp: new Date().toISOString(),
    bookingReference: booking.bookingReference,
    propertyName: booking.propertyName,
    propertyLocation: booking.propertyLocation,
    checkIn: booking.checkIn,
    checkOut: booking.checkOut,
    nights: booking.nights,
    adults: booking.adults,
    children: booking.children,
    totalPrice: booking.totalPrice,
    advanceDeposit: booking.advanceDeposit,
    guest: {
      name: booking.guestName,
      phone: booking.guestPhone,
      whatsapp: booking.guestWhatsapp || booking.guestPhone,
      email: booking.guestEmail,
      city: booking.guestCity,
      groupType: booking.groupType,
      dietary: booking.dietary,
      arrivalTime: booking.arrivalTime,
      specialRequests: booking.specialRequests,
    },
    status: booking.status,
  };

  try {
    await postWithRetry(MAKE_WEBHOOK_URL, payload);
  } catch (error) {
    // Fail silently so the user journey is not interrupted
    console.error('Silent catch for booking webhook error:', error);
  }
}

/**
 * Triggers Make.com automation workflow for a contact/inquiry form
 */
export async function sendEnquiryWebhook(enquiry: Enquiry): Promise<void> {
  const payload = {
    event: 'enquiry.received',
    timestamp: new Date().toISOString(),
    name: enquiry.name,
    phone: enquiry.phone,
    email: enquiry.email,
    message: enquiry.message,
  };

  try {
    await postWithRetry(MAKE_WEBHOOK_URL, payload);
  } catch (error) {
    console.error('Silent catch for enquiry webhook error:', error);
  }
}
