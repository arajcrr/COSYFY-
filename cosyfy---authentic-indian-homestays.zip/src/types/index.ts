export type Region = 'All' | 'Hills' | 'Beach' | 'Heritage' | 'Forest' | 'Desert' | 'Village';

export type Amenity =
  | 'WiFi'
  | 'AC'
  | 'Heater'
  | 'Meals'
  | 'Parking'
  | 'Pet Friendly'
  | 'Mountain View'
  | 'Bonfire'
  | 'Work Desk'
  | 'Private Bathroom'
  | 'Power Backup'
  | 'Kitchen Access';

export interface HostInfo {
  name: string;
  memberSince: string;
  responseTime: string;
  bio: string;
  avatar?: string;
  phone?: string;
}

export interface HouseRules {
  checkInTime: string;
  checkOutTime: string;
  policies: string[];
  specialRules?: string[];
}

export interface PropertyReview {
  id: string;
  guestName: string;
  date: string;
  rating: number;
  cleanliness: number;
  hospitality: number;
  location: number;
  value: number;
  text: string;
  hostResponse?: string;
}

export interface Property {
  id: string;
  name: string;
  tagline: string;
  destination: string;
  region: Region;
  state: string;
  location: string;
  address: string;
  mapEmbedUrl?: string;
  googleMapsUrl?: string;
  weekdayPrice: number;
  weekendPrice: number;
  cleaningFee: number;
  maxGuests: number;
  bedrooms: number;
  bathrooms: number;
  mainImage: string;
  images: string[];
  videoUrl?: string;
  description: string;
  surroundingArea: string;
  distances: {
    railway?: string;
    airport?: string;
    busStand?: string;
  };
  nearbyAttractions: string[];
  amenities: Amenity[];
  wfhReady: boolean;
  wifiSpeedMbps?: number;
  powerBackup?: boolean;
  networkCoverage?: string;
  notOnAirbnb: boolean;
  featured: boolean;
  rating: number;
  reviewCount: number;
  host: HostInfo;
  houseRules: HouseRules;
  reviews?: PropertyReview[];
  isActive?: boolean;
  remoteProperty?: boolean;
}

export type BookingStatus = 'pending' | 'contacting_host' | 'confirmed' | 'declined' | 'cancelled';

export interface Booking {
  id: string;
  bookingReference: string;
  userId?: string;
  propertyId: string;
  propertyName: string;
  propertyLocation: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  nights: number;
  pricePerNight: number;
  basePrice: number;
  cleaningFee: number;
  totalPrice: number;
  advanceDeposit: number;
  status: BookingStatus;
  guestName: string;
  guestPhone: string;
  guestWhatsapp?: string;
  guestEmail: string;
  guestCity: string;
  groupType: 'Solo' | 'Couple' | 'Friends' | 'Family';
  dietary: 'Veg' | 'Non-Veg' | 'Vegan' | 'No preference';
  specialRequests?: string;
  arrivalTime?: string;
  source?: string;
  isRemoteProperty?: boolean;
  paymentAmount?: number;
  paymentStatus?: 'pending' | 'advance_paid' | 'full_paid';
  paymentId?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Customer {
  id?: string;
  fullName: string;
  phone: string;
  whatsapp?: string;
  email: string;
  city?: string;
  createdAt?: string;
}

export interface UserProfile {
  id: string;
  email: string;
  fullName: string;
  phone?: string;
  whatsapp?: string;
  city?: string;
  dietaryPreference?: 'Veg' | 'Non-Veg' | 'Vegan' | 'No preference';
  bio?: string;
  role?: 'customer' | 'admin';
  createdAt?: string;
  updatedAt?: string;
}

export interface FilterState {
  destination: string;
  region: Region;
  priceRange: [number, number];
  guests: number;
  amenities: Amenity[];
  wfhReady: boolean;
  notOnAirbnb: boolean;
  sortBy: 'recommended' | 'price-asc' | 'price-desc' | 'rating';
}

export interface AirtableResponse<T> {
  records: Array<{
    id: string;
    fields: T;
    createdTime: string;
  }>;
  offset?: string;
}

export interface Enquiry {
  id?: string;
  name: string;
  phone: string;
  email?: string;
  message: string;
  createdAt?: string;
}
